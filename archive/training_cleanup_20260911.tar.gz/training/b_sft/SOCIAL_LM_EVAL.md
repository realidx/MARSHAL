# 训练前的 LM 决策点审查

> 下文保留 v2 历史记录。当前使用 v3 固定查询数据和 `social-english-native-action-v2` prompt；B/P 均使用英文，先给依据，再调用工具。P 提交完整动作对象，旧 action_index 接口已停用。现行命令与字段见 [SOCIAL_SERVER_RUN.md](SOCIAL_SERVER_RUN.md)。

完整的 Mac 上传、服务器 tmux / vLLM 启动、测试参数和下载命令见 [SOCIAL_SERVER_RUN.md](SOCIAL_SERVER_RUN.md)，已填入此前使用的服务器路径、SSH 端口和模型路径。

2026-09-10。先检查实际输入 → LM B → LM P → 环境 → 后续判断 / 终局，再决定训练。当前没有运行真实 LM 或优化器。

## 数据已补充

新包：`new/local_data/social_generalization_v2/`。原 `social_generalization_v1` 和训练材料保持原样。

- 9 个与现有训练材料拓扑不重合的结构，90 个固定决策点。
- 38 个含可评分、非全可能集合 B 的决策点，分布在 7 个结构中；原来是一个结构中的 4 个点。
- 59 对前后判断：21 maintain、38 update。配对类别比较全量教师判断；模型自选目标的评估还会逐目标重新分类。
- 900 条原生终局轨迹重放、90 个 B 快照、163 个抽样 P 参考值通过独立核对。
- 新增 6 个结构来自预先列出的候选序列，检查了 31 个候选后达到补充配额。按公开证据能否区分偏好筛选，未使用 LM 得分；被选结构保留普通/维持对照，不仅保留信息点。
- 这是 **证据丰富的开发检查**。20 个有信息点仍来自同一结构，因此应逐结构汇报；不能用 90 个相关快照声称广泛迁移。

[逐结构示例及证据](../../new/local_data/social_generalization_v2/REVIEW.md)、`screening.jsonl`、`supplement_plan.json` 保留来源、筛选失败和停止条件。不要混入训练。

## 第一次如何跑

入口 `python -m training.b_sft.social_lm_eval`，使用仓库现有的 vLLM 兼容客户端，`tool_choice=auto`，一次 B 调用后接一次 P 调用。B 工具参数为 `judgments` 列表，项为 player、goal、possible_preferences、favored；P 为当前合法动作列表的零起始 action_index。允许普通文本推理，不强制长度或推理模板，不评分理由，不重试修复答案。

从仓库根目录运行，Python >=3.10，需本仓库原生 BENAC 依赖（包括 numpy）。连接已有、支持 tool-call auto 的推理服务；不启动训练，也不自动启动 vLLM。服务使用鉴权时设置 `BENAC_P_VLLM_API_KEY`，密钥不会写入配置日志。

先跑一个新结构的全部固定点，并从其起点继续到终局：

```bash
python -m training.b_sft.social_lm_eval \
  --data-dir new/local_data/social_generalization_v2 \
  --output-dir outputs/social_review_base_430206 \
  --base-url http://127.0.0.1:8000/v1 \
  --model YOUR_SERVED_MODEL_NAME \
  --source evidence-430206 \
  --continue-game --roots-only \
  --b-max-tokens 512 --p-max-tokens 768
```

这里 model 是推理服务暴露的模型名称。去掉 `--source` 检查全部 90 点。去掉 `--continue-game` 只做固定题（90 点通常对应 180 次模型请求）；保留 `--continue-game --roots-only` 会从 27 个起点的全部兼容世界展开，共 225 条续局，后续 LM 请求数取决于它的动作。第一步 B/P 在同一可见起点的不同世界间复用，后续由 LM 继续决策。

- `--limit N`：只取文件顺序前 N 点，未配齐的 pair 不计；这是截取审查，不是完整指标。
- `--max-worlds N`：只取每点兼容世界前 N 个；默认 0 为全部。截取后的 outcome 不能当成无偏期望收益。
- `--p-rollouts 512 --p-seconds 20`：局部 P 参考比较预算；失败则 mask，不把部分动作比较冒充完整排名。单次教师窗口另有 5 秒 / 10,000 节点限制，整组评分可能略超过时间预算。
- `--timeout 180`：单次模型请求超时。无 tool call、截断、非法索引均明确记录；不偷偷变成 PASS。
- base / 训练后模型必须使用相同数据、工具 schema、token 上限、temperature 和世界选择。默认 temperature=0。

**运行器要求新在线协议数据包。旧 `social_cases_v2` 的 83 个静态精选点还不能直接传入此脚本。**它们使用的历史 / 未来策略假设不同，若要纳入同一在线测试必须另行迁移并验证；脚本主动拒绝静默混用。本次可直接测试的是上述 90 个独立结构决策点。

## 看哪些文件

- `REVIEW.md`：逐点索引，链接到 `review/<id>.json`，适合一起逐例 debug。
- `calls.jsonl`：每次调用立即保存完整 messages、工具 schema、raw message / tool arguments、finish reason、token usage、文本长度和耗时。配置里记录模型、解码与预算。
- `decisions.jsonl`：固定题的实际 B 输入 / 输出、实际 P 输入 / 输出、教师全量 B、分项目评分、全部可用动作参考值；教师部分只写审计文件，不传给模型。
- `pairs.jsonl`：逐目标 formation 后的 maintain/update 检查。没有在前后两端选择目标时，不计 both-exact 成功；另外保留覆盖统计。
- `continuation_decisions.jsonl`、`events.jsonl`：续局中每次决策和每次实际动作即时落盘。记录公开新证据、B 变化、教师不可用原因及动作耗时。
- `episodes.jsonl`：完整真实历史、隐藏世界（仅教师侧）、各玩家实际终局收益，以及轨迹是否可用于训练。非法/缺失 P 停止该续局，收益留空；教师失败后的应急续局标为不可训练。
- `summary.json`：每完成一个固定点更新，包括总体 / 逐结构指标和异常。最终还包含全部已配齐的前后检查。

B 指标分别记录：格式成功、空选择、选择覆盖、有信息目标覆盖、集合 exact、favored exact、错误排除、多保留情况。不能只看“选中题目的准确率”。目标选择有用与否没有唯一 gold，脚本没有假装已经解决这个奖励问题。

P 指标分别记录：合法率、参考值可用率、有区分度的比较、参考最优动作命中和 regret。自身收益同分时另列对其他玩家收益更好的动作及差距。所有并列可接受动作均保留。**参考 regret 不是 LM advantage，终局实际收益单独记录。**

B 原样传给 P，包括错误判断。B 提交失败时，P 收到明确的失败状态和原始输出；不会补教师答案。B→P 原样传递仅证明接线正确，不证明 P 确实利用 B。

倾向评分继续使用已有教师的 margin 约定，模型侧只要求明显倾向 / undetermined；因此应逐例区分“支持集合错误”和“倾向边界分歧”，不能把后者直接称为推理错误。

## 无模型验证与复现

```bash
python -m unittest training.b_sft.test_social_lm_eval \
  training.b_sft.test_online_social training.b_sft.test_social_cases_expand \
  training.b_sft.test_social_cases training.b_sft.test_shared_teacher

python -m training.b_sft.social_lm_eval --dry-run \
  --continue-game --roots-only --output-dir outputs/social_review_dry

python -m training.b_sft.social_holdout_expand \
  --output-dir new/local_data/social_generalization_rebuilt
```

输出目录必须新建。dry-run 只用可见 catalogue 的全可能集合和第一个合法动作，不接 LM、不花推理额度；用于验证日志、环境与评分链路，不能作为真实 base model 结果。
