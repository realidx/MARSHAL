# 固定全量 B 查询与真实终局 rollout

实现：[social_rollout.py](social_rollout.py)。状态：CPU 参考环境和 agent callback 已接通；尚未接 LM 请求、token/log-prob、value head 或 PPO。不是可启动的 GPU 训练入口。

## B 问谁、问什么

`queries_for(public_type_catalogues, ego)` 扫描公开候选目录，对每个非 ego 玩家，列出所有候选中存在不同值的 goal；按 player/goal 排序。每次 B 必须回答整份清单，不能遗漏或自行换题。

清单在 episode 开始时确定，之后不随支持集收缩、动作价值或未来事件改变。已经确定的偏好仍继续询问，因此保留维持判断的训练机会。私有实际类型、教师 Q、哪些 goal 对当前 P 最有用，都不参与选题。

这不代表任意现实任务都能提供公开类型目录；当前仍使用明确的有限候选参考环境。目录本身是任务的公开信息，不能在生成阶段先依据实际最优行动挑出几个隐藏 goal，再声称查询过程没有选择偏差。

示例：当前 fixture 同时隐藏 P1 的 G0/G2，所有 B 都问这两项。运行器另外支持多个伙伴同时具有多个候选配置，不再使用旧 Fixture 的“其他伙伴必须已知”限制；测试包含 P1 两项、P2 一项同时隐藏。

## Agent 接口与实际 prompt 内容

回调签名：`agent(phase, payload)`，phase 为 B 或 P。调用者只收到 payload 的深拷贝，不能通过参数访问当前真实 world、posterior 或教师标签。

B payload 包含自己的偏好、公开状态、pending offer、完整可见行动历史、公开类型目录、声明伙伴模型、固定 queries 和 favored 判定规则。B 返回：

```json
{
  "text":"简短判断说明",
  "answer":[
    {"player":1,"goal":0,"possible_preferences":["want","neutral","avoid"],"favored":"undetermined"},
    {"player":1,"goal":2,"possible_preferences":["want","neutral","avoid"],"favored":"undetermined"}
  ]
}
```

P 收到相同可见环境信息，加上 **这次模型 B 的全部 text/answer**；即使 B 错误也不换成 oracle B。P 以同样的 text/answer 外壳提交原生动作参数，例如 `{"response":"REJECT"}`，不接受 action_index。当前 callback payload 列出完整合法语义动作以验证协议，不筛选“推荐动作”。正式 LM 工具 schema/auto tool-call 适配尚未实现。

B 教师在独立 sidecar 中给所有查询评分，并对查询平均，避免条目多就分数大。P 局部 Q/regret 还没接到此在线接口；不拿环境模拟过程当作已实现的 P 局部优势估计。

## 轨迹怎样前进

1. 从公开合法前缀重放；可以是开局，也可以是非终局残局。若当前是伙伴回合，先执行伙伴响应，直到 ego 或终局。
2. 在前缀相容 world 中采样一个实际隐藏配置，用于环境演化。它不进入 agent payload。
3. 每个实际 ego 决策执行一次 B、一次 P。proposal 和 response 都算真实决策，不省略回应阶段。
4. 参考环境枚举伙伴响应分支，按本局实际 world 选择唯一分支，追加真实公开事件，继续下一次 ego 决策。
5. 只在原生 `state.is_terminal` 为真时计算效用。归一化回报为 `U / max(1, sum(abs(own_preferences)))`，不是最优 Q。

环境内部仍使用声明的 RationalPartner 精确参考计算，且会枚举相容分支；这不是低成本的通用在线环境适配。max_nodes 限制其计算，不能承诺复杂多伙伴状态的吞吐。当前拒绝 linear goals，因为参考伙伴逻辑尚未忠实支持它们。

此阶段采用 **失败即标记不完整**：非法 B/P、调用预算耗尽、环境错误均不产生终局回报，不用 0 冒充终局。计划中的安全回退与对应格式惩罚暂未接入；这些失败轨迹不能直接当作正常 PPO episode 使用。callback 原始输出和环境事件分开存，未来 token mask/old log-prob 仍需实现。

## 本地验证结果

[实际脚本探针记录](../../new/local_data/social_rollout_probe_v1.json) 从 favored fixture 的空历史开始走到终局：

- 4 次真实 ego 决策，8 次 B/P callback，10 个实际行动事件。
- 固定询问 P1.G0/P1.G2，所有 B 都保持相同查询范围。
- 脚本 B 保守地保留原始候选；脚本 P 固定选 PASS/REJECT。这只是协议探针，不是学习成功。
- 实际终局 U=0，归一化回报=0。后续 B 教师平均分为负，说明没有偷偷修正脚本的错误判断。

测试还核对：不同隐藏 world 的相同初始信息产生相同 B payload；错误 B 原样传给 P；多伙伴查询完整；最终历史可以独立重放到相同终局效用；失败和截断没有假终局回报。当前相关测试共 29 项通过。

```bash
python -m training.b_sft.social_rollout \
  --fixture training/b_sft/fixtures/favored_belief_regression.json \
  --output new/local_data/MY_SOCIAL_ROLLOUT.json

python -m unittest training.b_sft.test_social_rollout \
  training.b_sft.test_favored_belief training.b_sft.test_evidence_switch \
  training.b_sft.test_structure_audit training.b_sft.test_decision_corpus
```

输出文件必须不存在。下一步可以在这一固定接口上接 LM 的原生工具调用及完整生成记录，再接 value/PPO；不能直接用旧 run_shared.sh 训练这些 trace。
