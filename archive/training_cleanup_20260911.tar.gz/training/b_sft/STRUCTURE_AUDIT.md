# 少量游戏结构的覆盖与捷径审计

入口：[structure_audit.py](structure_audit.py)。先审计已有 fixture，不重新生成大批游戏、不训练 LM、不修改旧语料。

```bash
python -m training.b_sft.structure_audit \
  --corpus new/local_data/bp_decision_corpus_v1_development \
           new/local_data/bp_decision_corpus_v1_candidates \
  --output-dir new/local_data/MY_NEW_STRUCTURE_AUDIT \
  --max-nodes 3000 --seed-limit 8
```

输出目录必须不存在。逐节点计算并立即落盘 `decisions.jsonl`，终了输出 `summary.json`、`REPORT.md`。节点预算耗尽记 unavailable，不当作无依赖；异常详情保留。当前仅有节点预算，没有硬墙钟终止或自动恢复，失败后保留部分 JSONL，需用新目录重跑。

## 检查什么

1. 对同一根节点的相容隐藏配置分别计算原生参考 Q，核对合法动作顺序一致。
2. 求全部条件的最优动作交集；同时输出最佳固定动作的最坏 regret，以及是否存在最优集合互不相交的条件对。
3. 枚举根动作，推进到下一次真正的 ego 决策或终局，记录 maintain/update。
4. 对仍留有后续决策的信息行动记录 Q、regret 和响应支持集，区分次优信息行动与最优信息行动。
5. 按精确物理结构合并不同角色/偏好/根节点，贪心选覆盖增益最大的设计种子。

范围必须严格解释：

- 共同最优只针对该节点和所检查的教师条件，不证明整局存在与伙伴无关的万能策略。
- 没有共同最优也不证明实际公开证据能辨别这些条件。当前未实现可达证据导致必要行动切换的完整证书。
- 最优信息行动不证明收益来自信息，可能来自 commitment 的直接效果；正净信息价值证书尚缺。
- 单个条件不能检验条件间捷径；报告中的这类格子显示未知。
- `favored` 多元素非平凡倾向、自身目标反事实仍未实现，明确列为缺口。
- 结构哈希忽略 seed/metadata/private_preferences，但不是重命名同构规范化。

`--seed-limit 8` 是上限，不是凑数目标。只从 train/development 选；凡同结构出现在 held-out split 中，就不纳入种子建议。development 是已检查过的设计材料，不能再用它证明泛化。输出是候选建议，未自动写入训练配置或改变任何 split。

## 后续新增的严格见证

已新增 [可达证据切换筛选器与实例](EVIDENCE_SWITCH.md)：在一个新的 3 人原生结构中找到相同当前状态、不同公开历史、最优响应互不相交的正例。下表仍是旧 21 个结构的历史审计，未混入新数据。

## 当前审计结论

结果：[完整报告](../../new/local_data/bp_structure_audit_v2/REPORT.md)，[机器汇总](../../new/local_data/bp_structure_audit_v2/summary.json)。

现有 21 个精确结构、31 个根点全部在本次节点预算内完成审计：

| 结构级覆盖（可重叠） | 结构数 |
|---|---:|
| 至少一个多条件节点存在共同最优动作 | 19 |
| 新证据后、仍可行动时维持集合 | 14 |
| 新证据后、仍可行动时更新集合 | 12 |
| 次优但有信息的行动，且后续还能行动 | 5 |
| 最优且有信息的行动，且后续还能行动 | 5 |
| 已完整检查的多条件节点中无共同最优 | 0 |

按当前覆盖增益，仅建议两个设计种子：3 人 `native-30016-g5-d1`（development），4 人 `native-1030051-g1-d2/d3`（train，同一结构）。第二个目前仅增加 4 人覆盖，不代表具有足够社会判断难度。

因此不把它们称为足够训练的“两局游戏”。原来的 6–8 个结构目标仍是预算：接下来应定向补齐必须利用证据改变行动、倾向性、目标变化及信息净价值的结构，而不是继续堆相同覆盖的随机游戏。

## 验证

```bash
python -m unittest training.b_sft.test_structure_audit training.b_sft.test_decision_corpus
```

检查共同最优与价值敏感的区别、三条件无共同交集但两两有交集、数值并列、held-out 隔离、超预算 mask，以及真实原生 fixture 重放。报告数值是教师审计，不是 LM 能力评估。
