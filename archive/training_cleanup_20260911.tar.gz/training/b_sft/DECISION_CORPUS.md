# 决策分支数据集 v1

入口：`python -m training.b_sft.decision_corpus`。本次改动是数据生成、关联与核验，不是新训练算法；没有启动训练，也没有重写旧的 220 局 MCTS 数据。

## 一条监督链

每个根决策点导出 `B_t` 和 `P_t`，再执行若干合法行动分支，观察伙伴的实际参考响应，停在 ego 的下一次真实决策点，导出 `B_next` 和 `P_next`。终局仍可以评估 B，但不编造下一次 P。

- B 输入：公开规则、ego 目标、候选伙伴类型、声明的伙伴策略、可见历史。输出仍为 `SUBMIT_JUDGMENT({"possible_preferences": [...]})`。
- P 输入：上述信息、当前状态、合法行动及当前证据对应的参考 B。输出为原生 planning tool 的 `action_index`，不要求解释。
- 监督只在 assistant 答案。没有增加概率输出、reasoning target 或第三个条件行为预测模块。
- `*_links.jsonl` 记录行动、证据、前后题目 ID 和 maintain/update。更新指支持集合缩小；维持指集合相同，即使历史已改变。二者都来自独立重放，不由文本模板猜测。
- 分支包含参考最优行动、收益对照行动；如果参考器证实行动能改变后续信息，则同时保留高/低信息行动。这些干预不都作为 P 的正确答案。P 仍按终局收益标注。
- P 可能有多个最优行动：SFT 给一个可复现示范，gold 保留全部最优索引。以后评估必须按集合判分，不能按示范字符串判错。

`certificates.jsonl` 和 `*_gold.jsonl` 中的 Q 值、参考分支权重、依赖证书仅供教师核验，不进入 student prompt。B 不能看到当前正确集合；P 看到参考 B 是明确的条件规划任务。

## 已生成的两批数据

| 数据目录（仓库根目录下） | 来源 | B/P 题数 | 行动分支 | 用途 |
|---|---|---:|---:|---|
| `new/local_data/bp_decision_corpus_v1_development` | 已检查的 10 个原生诊断游戏 | 82（46 B / 36 P） | 36 | 开发与逐题审阅，不作未见测试 |
| `new/local_data/bp_decision_corpus_v1_candidates` | 新生成的 11 个游戏，3/4/5 人 | 95（61 B / 34 P） | 40 | 验证生成流程、检查候选分布 |

开发批包含 14 个 maintain、22 个 update、9 个 belief-sensitive 根 P、6 个行动影响信息的根局面。新生成批包含 32 个 maintain、8 个 update、2 个 belief-sensitive 根 P、1 个行动影响信息的根局面。类别有重叠，不是独立样本数。

新生成批按完整公开游戏哈希分组，忽略查询目标、ego 角色和抽取的私有偏好；同一游戏的根局面和所有分支留在同一 split。3/4 人按哈希分成 train/validation/test；5 人仅进 ood_test。本次分别为 27/16/23/29 题，只有 3/2/2/4 个独立游戏。**这不是足够规模的正式训练集。**

`summary.json` 明确记录缺失类别、实际独立游戏数和 `formal_training_ready: false`。`READY.json` 只表示导出完整并通过一致性检查，不表示实验已准备好。

## 当前边界

这是**参考策略已声明、只有一个伙伴目标偏好未知的二值目标残局**。其他偏好条目提供给学生，参考器使用原生精确残局求解。它不再反推旧 MCTS 的固定随机流，但仍是策略条件化标签，尚未实现对未知策略族的稳健偏好判断。不能把这一步宣称为已解决此前的标签问题。

尚未加入 own-goal-change 配对、未知伙伴策略族、线性目标，也未证明信息增益带来正收益。B→P 证书表示某些判断下行动收益/最优性不同，不要求每次更新都换行动。P→B 证书表示信息不同，不表示高信息行动必然更好。

P 当前训练输入是参考 B。未来使用模型 B 的闭环效果和错误恢复需要单独训练/评估。本次关联文件提供数据基础，尚未实现消费这些关联的联合采样或优化机制。

现有 `train.py` 的编码器只接受 B tool。**不要把混合 B/P 文件直接交给旧训练命令。** B-only 子文件保留原答案接口，但还需正常 tokenizer 长度预检；本轮没有做 GPU 训练或 token 长度验收。

## 复现与扩展

```bash
# 新目录：不会覆盖已有导出。先看采样覆盖，再决定扩展哪些类别。
python -m training.b_sft.decision_corpus \
  --output-dir new/local_data/bp_decision_corpus_next \
  --players 3 4 5 --seed 30050 --seeds-per-player 4 \
  --actions-per-player 2 --goals 7 --max-nodes 2000 \
  --max-fixtures-per-seed 2 --max-arms 4

# 旧诊断材料永远标 development；没有读取旧模型答案来选题。
python -m training.b_sft.decision_corpus \
  --output-dir new/local_data/bp_decision_review_next \
  --fixtures runs/benac_native_endgame/functional-dependency-retry3-20260908-064709/fixtures.json \
  --max-nodes 20000

python -m unittest training.b_sft.test_decision_corpus -v
```

`max-nodes` 是参考搜索节点预算，不是整局墙钟时限。超预算/信息条件不足会记录排除，不能将启发式结果冒充精确标签。生成器仍可能找不到合适决策点；更多 seeds 不保证更多有价值题目。原始候选保留普通和无依赖局面作为对照，尚未自动做类别配额。

## 文件与检查

每个 split 有混合题目、B/P 子集、去答案 prompts、gold 和 links。`attempts.jsonl` 记录接受/排除；manifest 记录参数及限制；checksums 和最后写入的 READY 用于检查完整性。不要在运行中读取尚未出现 READY 的目录。

回归检查覆盖原生重放生成、正确答案接口、教师标签泄漏、跨游戏/跨 split 错接、错误 P 答案、线性目标拒绝及 5 人/旧材料分区规则。回归 fixture 来自已有开发局面，不是独立新测试游戏。
