# 可达证据导致必要行动切换：第一条原生见证

更新：2026-09-10。新代码：[evidence_switch.py](evidence_switch.py)，固定回归样本：[evidence_switch_regression.json](fixtures/evidence_switch_regression.json)。

这次补齐的是“同一当前物理状态下，不同可见历史对应不同支持集，并且最优行动集合不相交”的开发见证。没有训练 LM，也没有证明模型实际使用了自然语言 B。

## 验证器如何筛选

1. 从合法 fixture 的原始先验开始，枚举 ego 的合法干预，并重放声明伙伴模型的所有可行响应分支。
2. 推进到下一次真实 ego 决策，保存完整行动历史。只向前到达节点，不手动把世界集合设为已知真值。
3. 对每个候选历史重新调用原生 replay，检查支持集及物理状态。
4. 仅配对同一个 fixture、相同规则/自身目标、相同当前 commitment、轮次、pending offer 和合法行动列表的节点。
5. 要求支持集不同、完整最优行动集合不相交。共同最优或动作列表不同都不能通过。
6. 对命中的左右两个历史分别重新建立 Fixture、重新算 Q，并逐项验证保存结果。通过才导出 `witness.json` 和两个根节点的 `fixtures.json`。

`attempts.jsonl` 保存每个候选的状态、访问节点数、耗时。`decision_budget` 和 `unavailable` 均不等于“此游戏不可能有见证”；`complete` 也只表示给定搜索深度内队列耗尽。不同物理状态下的动作切换可记录为反例，不能升级为严格见证。

构造器使用 3 人、每人 1 个 commitment 的原生规则，固定四个 goal，变化偏好配置；没有增加专门的信号工具、改伙伴策略或裁剪合法动作。它只提出候选，最终结果由原生搜索验证。此版本没有结构同构规范化、硬墙钟预算或自动断点恢复。

## 找到的游戏

ID：`constructed-switch-94002`。角色 P0；顺序 P0→P1→P2→P2→P1→P0；menu 开启，max_changes=1。每人唯一 commitment 记为 A。

| goal | 满足条件 | P0 自身偏好 | P1 偏好 | P2 偏好 |
|---|---|---:|---:|---:|
| G0 | P0.A、P1.A | -1 | +1 | 0 |
| G1 | P0.A、P2.A | -1 | -1 | +1 |
| G2 | P1.A、P2.A | +1 | 0 | 0 |
| G3 | P0.A、P1.A、P2.A | -1 | 未知：+1/0/-1 | +1 |

只有 P1 对 G3 未知，三个候选原先等权；其他偏好公开。这里仍是条件化参考任务，不代表完整多伙伴未知策略场景。

两段历史：

| 历史 A | 历史 B |
|---|---|
| P0 向 **P1** 提议：P0 承诺 A，接收方不新增 | P0 向 **P2** 提议：P0 承诺 A，接收方不新增 |
| P1 接受 | P2 接受 |
| P1 向 P0 提议：P1 承诺 A，P0 维持 A | P1 向 P0 提议：P1 承诺 A，P0 维持 A |

现在两边都轮到 P0 响应同一个 offer；当前 commitment 均为 P0=[1]、P1=[0]、P2=[0]。最后一条 offer 完全一样，区别在此前公开历史。

在声明的 `RationalPartner` 模型及其 tie-break 下，独立重放得到：

| 项目 | 历史 A | 历史 B |
|---|---|---|
| P1 对 G3 的支持集 | want | want / neutral / avoid |
| 新 B schema 的 favored（语义映射，尚未实现训练） | want | undetermined |
| Q(REJECT) | -2 | -2/3 |
| Q(ACCEPT) | -1 | -1 |
| 唯一最优响应 | **ACCEPT** | **REJECT** |

这些 Q 是信息一致的参考终局期望效用，不是本次抽样的实际 outcome。负数表示在当前已承诺状态下仍需要尽量减少损失。

始终 ACCEPT 在 B 有 1/3 原始效用 regret；始终 REJECT 在 A 有 1 的 regret。当前动作列表和 offer 内容不足以同时选对，必须区分历史条件。这比“某些动作价值会随隐藏类型变化，但始终存在一个共同最优动作”的旧证书更强。

不要把该例解释成“任何现实伙伴接受第一次 offer 都证明 want”。推断依赖明确的参考伙伴模型、其续策与 tie-break。两段历史也包含不同的 ego 干预，证明的是可达历史相关的必要决策差异；并未证明所有影响都只能通过我们这个单一 B 字段表达，更没有证明 LM 已学会其中逻辑。

## 已导出的开发数据

[验证记录与 fixture](../../new/local_data/bp_evidence_switch_verified_v1/summary.json)，[完整见证](../../new/local_data/bp_evidence_switch_verified_v1/witness.json)。第二轮构造搜索尝试了 3 个偏好配置，在第三个命中，耗时不到 1 秒；它们共享一个物理结构，不能算三个独立游戏结构。

将左右历史作为两个根决策点导入现有数据链路后得到 [development 数据汇总](../../new/local_data/bp_evidence_switch_development_v1/summary.json)：**1 个结构，14 条记录（7 B / 7 P），7 个决策点，5 条分支链接**，包括 maintain/update 和后续规划。

两边保持同一 source、同一 development split。此导出仍使用旧 set/action-index 答案格式，没有 favored、没有 PPO，也不自动加入正式训练。`formal_training_ready=false`。

## 复现与测试

从仓库根目录执行，输出目录需不存在：

```bash
python -m training.b_sft.evidence_switch \
  --constructed-seeds 3 --seed 94000 \
  --depth 6 --max-decisions 512 --max-nodes 3000 \
  --output-dir new/local_data/MY_SWITCH_SEARCH

python -m training.b_sft.decision_corpus \
  --fixtures new/local_data/MY_SWITCH_SEARCH/fixtures.json \
  --output-dir new/local_data/MY_SWITCH_DEVELOPMENT --max-nodes 3000

python -m unittest training.b_sft.test_evidence_switch \
  training.b_sft.test_structure_audit training.b_sft.test_decision_corpus
```

若搜索未命中，不产生 `fixtures.json`，不能继续导出命令。还可用 `--corpus DIR ...` 搜索旧语料，但仅使用 train/development，跳过 validation/test/OOD。

下一项数据缺口仍是多元素集合内有依据的 favored，以及自身目标反事实、信息获取的正净价值。当前见证解决了一个缺口，不意味着少量训练结构已经完整。
