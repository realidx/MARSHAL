# B 的集合与倾向：联合隐藏偏好下的第一版教师

实现：[favored_belief.py](favored_belief.py)。固定重放样本：[favored_belief_regression.json](fixtures/favored_belief_regression.json)。这一步新增教师、语义评分和开发样本，不启动 SFT/PPO，也不修改旧集合数据。

## 数据扩展及信息假设

仍用原生 3 人、每人 1 个 commitment、4 个 binary goal 的小结构。将同一伙伴的两个 goal 偏好同时设为未知，每个维度有 want/neutral/avoid，形成 **9 个唯一、等权的笛卡尔积配置**。其他偏好公开，固定项保留至少一个 want。

现有 Fixture 已能处理联合查询，不需要改引擎。新模块明确指定 `assessed_goal`：对联合配置推断后，只投影到其中一个 goal 的边际判断。所有完整配置继续保留用于参考 P 计算，不能用边际集合替换联合信息。

按原生 RationalPartner 的公开行为过滤配置，自己的动作是合法干预，不被当成伙伴类型证据。当前实际抽中的隐藏类型不进入标签。不能重复配置来人为增加某种偏好的支持权重；代码拒绝重复 world，也拒绝直接注入 posterior 或静默转换 linear goal。

模型输出仍只有：

```json
{"possible_preferences":["neutral","avoid"],"favored":"avoid"}
```

不输出计数、概率、概率损失、完整排序。

## 倾向教师怎样判定

对于剩余唯一 joint world，按被询问偏好累计教师侧计数：

- 出现过的偏好组成 possible set。
- 单元素集合直接 favored 该元素。
- 多元素集合，仅当最高计数严格超过第二名的 `robustness_ratio` 倍时选择最高者，否则 `undetermined`。

初始候选 `robustness_ratio=1.25`，是可配置、未调优的保守规则，不是已有实验确定的阈值。它的精确意义是：允许每个剩余 world 的权重独立乘以 [1,1.25] 内任意数，领先项仍保持唯一领先。它**不代表**跨伙伴策略、不同似然模型或任意先验都稳定。

教师内部需要这些计算来决定离散标签；模型不拟合数值概率。开发 prompt 公开先验、伙伴模型与判定规则，避免教师偷偷使用另一套假设。若这个规则只促使模型机械数配置而不迁移，要在后续实验中检验，不能从可计算标签直接推断通用社会判断能力。

该实现是固定参考假设下的第一版，不声称解决完全未知伙伴策略时唯一“正确倾向”的定义。

## 一个真实配对

ID：`favored-joint-95001`。P0 控制自己，P1 的 G0/G2 未知，此题询问 G0。两个合法历史从同一原始先验独立重放，到达相同当前物理状态和合法行动列表。

| 项目 | 历史 A | 历史 B |
|---|---|---|
| 支持集合 | neutral / avoid | neutral / avoid |
| 教师侧相容配置计数 | neutral=1，avoid=2 | neutral=1，avoid=1 |
| 模型应输出 favored | avoid | undetermined |
| P 的原生 Q（相同动作顺序） | [1,1] | [1,-1] |
| 最优索引 | [0,1] | [0] |

两段历史及全部原生行动见 [完整见证](../../new/local_data/bp_favored_development_v1/witness.json)。这是一组不同历史的对照，**不是同一条轨迹先后发生的 update pair**。

旧 set-only 两边的标准答案完全相同；新教师能监督这种区别。另一方面，两边仍有共同最优行动 0，所以不能说偏好倾向必然要求换动作。

P 价值差还可能来自另一个未知 goal 或联合相关性；即使以后找到最优行动切换，也不能直接把影响全部归因于单个 marginal favored。新输出比 set 更丰富，但没有声称充分表达全部 joint belief。

## 评分接口

`score_belief(answer, gold)` 接收结构化 set/favored 答案，采用计划中的候选局部分数：

```
sB = -0.5 * |predicted_set △ gold_set| / 3
     -0.5 * (predicted_favored != gold_favored)
```

这是语义 reward，不是 token CE。集合正确但倾向错误时得 -0.5，完全正确得 0；正确项不需要額外纠偏，后续由 outcome 和 PPO 使用这些信号。

格式非法得 -1，并单独记录 format_valid=false。teacher 不可用时 score=None、mask=false；缺 favored 教师时只保留集合项，不把缺失伪装成 undetermined，也不自动放大剩余项权重。

## 已落盘产物与验证

开发输出：[bp_favored_development_v1](../../new/local_data/bp_favored_development_v1/summary.json)。包含：

- `development.jsonl`：两条 B 答案样本，输出仅 set/favored。
- `development_prompts.jsonl`：去掉目标 completion 的模型输入。
- `development_gold.jsonl`：计数、参考 Q 等教师侧诊断。
- `pair.json`：同集合、不同 favored 的非时间顺序对照链接。
- `witness.json`、`attempts.jsonl`、`summary.json`：重放证据、预算与状态。

两条记录共享 source，均为 development，`training_ready=false`。它们是新 schema 的开发材料，不能直接交给旧 B-only 训练入口。未加入任意新概率输出字段，未训练 value head 或 PPO。

第一轮搜索 24 个配置；第二轮 [64 配置搜索](../../new/local_data/bp_favored_search_v2/summary.json) 在指定深度/节点预算内未找到同集合、不同 favored 且最优集合不相交的见证。它们共享小结构，不能称作 88 个独立游戏；未找到也不是不可能性证明。

## 复现

```bash
python -m training.b_sft.favored_belief \
  --seed 95001 --seeds 1 --max-nodes 3000 \
  --max-decisions 128 --depth 4 --robustness-ratio 1.25 \
  --output-dir new/local_data/MY_FAVORED_DEVELOPMENT

python -m unittest training.b_sft.test_favored_belief \
  training.b_sft.test_evidence_switch \
  training.b_sft.test_structure_audit training.b_sft.test_decision_corpus
```

输出目录须不存在。命中配对之后若继续搜索触及 decision_budget，已独立验证的配对仍有效，但不能声称遍历穷尽。无配对则不输出样本文件。当前没有硬墙钟停止或自动断点恢复。

下一步需要检验倾向对规划的增益，并补自身目标反事实和信息获取净价值；不应因为新增字段已有标准答案，就宣布 B/P 联合训练数据完整。
