# 随机生成、多路径采样与筛选漏斗

实现：[random_funnel.py](random_funnel.py)，结果：[首轮报告](../../new/local_data/random_funnel_v1/REPORT.md)、[完整统计](../../new/local_data/random_funnel_v1/summary.json)。

这次不要求所有训练样本都满足“同状态、最优集合互不相交”的最强条件，也没有改原生游戏规则。原生候选生成器增加独立 `trajectory_seed` 与 `on_event`，同一结构/偏好目录可采不同 ego 路径；默认 trajectory_seed=None 保留旧行为。

## 首轮结果

约 64.26 秒，使用 3/4 人、每人 2 个 commitment、7 个 goal，单伙伴隐藏 1/2 个 goal，每个配置两条随机 ego 路径，伙伴仍按固定 RationalPartner 行动。

| 漏斗阶段 | 数量 |
|---|---:|
| 不同精确结构 | 4 |
| 不同有效偏好查询配置 | 15 |
| 实际启动并完成的轨迹 | 30 |
| 完成轨迹内的全部 ego 决策 | 74 |
| 满足尾部范围、去重后的候选决策 | 29 |
| 无剩余不确定性或无动作选择 | 5 |
| 在抽样行动中未发现有后续决策的信息分支 | 20 |
| 有信息分支且完成终局动作价值验证 | 4 |
| 计算失败 | 0 |

“偏好查询配置”是不同隐藏维度及对应公开类型目录，不是 15 个独立物理结构。每个游戏 seed 目前只生成一个实际偏好矩阵；另外的变化来自候选维度和路径随机性，没有声称对同一结构覆盖了所有真实偏好矩阵。

| 分层 | 候选数 | 通过信息/终局价值验证 |
|---|---:|---:|
| 3 人，1 个隐藏 goal | 12 | 2 |
| 3 人，2 个隐藏 goal | 9 | 2 |
| 4 人，1 个隐藏 goal | 4 | 0 |
| 4 人，2 个隐藏 goal | 4 | 0 |

4 个验证节点都来自同一个物理结构。类别重叠：4 个有次优的信息行动，3 个有最优的信息行动，2 个出现多元素集合内的非平凡 favored。全体候选中另有 6 个具有后续可行动的 maintain 分支。

这支持“随机生成再筛选能命中”的判断，但样本太小，不能用 4/29 预测大规模稳定产率，也不能据此判断 4 人游戏缺少机会。

## 筛选怎样做

1. 随机原生结构与偏好矩阵；选择合法隐藏维度，记录哪些配置因偏好约束被跳过。
2. 从开局跑到终局。ego 用独立随机种子选择原生合法动作，伙伴使用声明策略。记录每条轨迹完成/失败和实际决策数。
3. 当前仅抽取剩余 proposal slots 不超过 `--remaining-turns` 的 ego 节点，默认 3。**轨迹完整不等于筛选覆盖全局早期决策。**
4. 廉价检查剩余不确定性和合法动作数。普通节点保留为对照。
5. 确定性打乱动作、最多检查 `--max-arms` 个，重放到下一 ego 决策或终局，比较全量 B 的 set/favored。
6. 有新判断且后续仍能行动时，计算根节点所有合法动作的终局参考 Q，区分较差信息行动与最优信息行动。

“最优信息行动”可能同时改变 commitment 并直接获得收益，不证明收益来自信息；这里没有颁发信息正净价值证书。严格匹配因果见证仍作为另一类筛选，不是一刀切的门槛。

阶段名中的“廉价”只相对于进一步 Q 验证；生成历史本身就要调用参考伙伴搜索，仍可能较贵。墙钟预算在路径/候选边界检查，不是硬抢占；单次原生调用可能超过剩余时间。节点预算用于计算限制。

## 输出与数据归属

- `events.jsonl`：生成结构、配置启动/跳过、轨迹完成/失败事件。
- `decisions.jsonl`：逐节点所停阶段、理由、采样动作/响应、可用时的 Q 和类别。
- `retained.jsonl`：保留 fixture 及筛选证据；包括普通对照，不只保留正例。
- `fixtures.json`：保留根节点的可重放 fixture，均为 development。
- `summary.json` / `REPORT.md`：结构与轨迹分母、失败阶段和适用限制。

本轮 29 个候选全部保留；失败节点若出现不会伪装成负例。没有覆盖旧数据集或更改 train/test 划分。新样本尚未并入统一数据包，也没有直接导出 PPO/SFT 训练批次。两隐藏 goal 的联合 fixture 不能直接交给旧单查询 decision_corpus 导出器。

## 复现

```bash
python -m training.b_sft.random_funnel \
  --seed 97000 --seeds 2 --players 3 4 \
  --hidden-goals 1 2 --trajectories 2 \
  --actions 2 --goals 7 --query-sets 2 --remaining-turns 3 \
  --max-nodes 1000 --max-arms 8 --seconds 90 \
  --output-dir new/local_data/MY_RANDOM_FUNNEL

python -m unittest training.b_sft.test_random_funnel \
  training.b_sft.test_assemble_dataset training.b_sft.test_social_rollout \
  training.b_sft.test_favored_belief training.b_sft.test_evidence_switch \
  training.b_sft.test_structure_audit training.b_sft.test_decision_corpus
```

相关 37 项测试通过。最终 CLI 另外以一个小结构跑通，检查新增漏斗字段和 fixture 导出。旧默认路径行为、不同路径种子不改变游戏、未完成不算负例、普通对照保留均有测试。

下一轮应扩展独立结构样本，并单独比较更早起点与更多路径的增益；每次只改变一个采样因素。当前结果没有提供“必须修改游戏规则”的证据。
