# 服务器运行命令：训练前社会判断审查

本页命令已更新为 **v3 固定查询数据**，旧 v2 结果保留作历史诊断，不能与新分数直接比较。B 查询来自初始公开候选目录，模型必须逐项回答；公开已知偏好不能替代查询。教师的偏好集合依赖题面声明的有限窗口伙伴规则；只靠原生动作顺序排除类型的点关闭 B 监督，不能把这种排除教成一般理性结论。P 的终局收益独立计算；非终局 Q 明确是参考策略续局价值。

当前 prompt 版本为 `social-english-native-action-v2`：B/P 的题目指令全部使用英文，要求先在普通正文中给出判断依据，再在同一回复中调用工具。P 将完整动作对象直接作为 SUBMIT_ACTION 的参数提交，例如 {"response":"ACCEPT"}；不再提交 action_index。每次调用保存 `reasoning_text` 和 `explanation_status`（present / missing / unavailable）。正文存在不代表理由正确；工具答案与说明是否存在分别统计。此修改在请求构造时生效，无需重建 v3 数据。

新版分别采样 P 规划题与 B 证据题，并保留全部候选、来源、排除依据、动作价值和掩码。当前仍是开发诊断数据；没有接入旧 B-only SFT，也没有实现新的 PPO 训练。旧包不能被新版运行器静默加载执行。

2026-09-11。沿用服务器 `/raid/chenjiahao/mas`、conda 环境 `/raid/chenjiahao/conda_envs/mas`、本地 SSH 密钥 `~/.ssh/id_rsa_dgx2` 和端口 2201。

**环境已确认，按用户要求使用同一个 mas conda。**驱动 470.256.02，实际加载系统 libcuda，driver API 11040；Python 3.11、glibc 2.31、torch 2.5.1+cu118、Transformers 4.57.3、DeepSpeed 0.16.3。cuda-12.6 有 toolkit、cuda-12.9 目录为空，没有发现/加载相应 compat 驱动库；这些目录不让当前进程获得 CUDA 12 运行能力。候选安装为官方 vLLM 0.8.5.post1+cu118 wheel，需将 PyTorch 升为 2.6.0+cu118；不是保持原 torch 不变的安装。见 [同环境安装说明](VLLM_SAME_CONDA.md)。已核对发布文件和依赖，尚未在服务器实际验证 vLLM GPU 运行。之后 RL 中 vLLM 用于 rollout 生成，梯度更新由训练框架负责，训练集成版本还需验证。

本次是 vLLM 推理服务 + CPU 环境/教师/评分脚本。配置均在命令行，运行器自动保存 `run_config.json`，没有额外 YAML/config 文件要填写。旧的 run_shared.sh、torchrun、DeepSpeed JSON、learning rate、batch、epochs、eval/checkpoint interval 均不用于此入口。

## 1. 本地 Mac 上传

同步下面三个目录即可；training/b_sft 整体上传以避免漏掉间接依赖，BENAC src 包含规则、教师依赖和 HTTP 客户端。上传新版包及其完整轨迹；无需上传旧数据或本地 dry-run 结果。rsync 不删除远程额外文件。

```bash
cd /Users/bruce/MARSHAL

ssh -i "$HOME/.ssh/id_rsa_dgx2" -p 2201 chenjiahao@36.102.215.18 \
  'mkdir -p /raid/chenjiahao/mas/training/b_sft /raid/chenjiahao/mas/third_party/negotiation_benchmark/src /raid/chenjiahao/mas/new/local_data/social_generalization_v3'

rsync -avzP --exclude='__pycache__/' --exclude='.pytest_cache/' --exclude='debug/' \
  -e "ssh -i $HOME/.ssh/id_rsa_dgx2 -p 2201" \
  training/b_sft/ \
  chenjiahao@36.102.215.18:/raid/chenjiahao/mas/training/b_sft/

rsync -avzP --exclude='__pycache__/' \
  -e "ssh -i $HOME/.ssh/id_rsa_dgx2 -p 2201" \
  third_party/negotiation_benchmark/src/ \
  chenjiahao@36.102.215.18:/raid/chenjiahao/mas/third_party/negotiation_benchmark/src/

rsync -avzP -e "ssh -i $HOME/.ssh/id_rsa_dgx2 -p 2201" \
  new/local_data/social_generalization_v3/ \
  chenjiahao@36.102.215.18:/raid/chenjiahao/mas/new/local_data/social_generalization_v3/
```

## 2. 登录、tmux 和依赖检查

```bash
ssh -i "$HOME/.ssh/id_rsa_dgx2" -p 2201 chenjiahao@36.102.215.18

tmux new -s social-review

cd /raid/chenjiahao/mas
conda activate /raid/chenjiahao/conda_envs/mas
mkdir -p outputs/logs

python -c 'import sys, numpy, vllm; print(sys.version); print("numpy", numpy.__version__); print("vllm", vllm.__version__)'

python - <<'PY'
from pathlib import Path
from training.b_sft.social_lm_eval import load_pack
summary, points = load_pack(Path('new/local_data/social_generalization_v3'))
print('Checksum/protocol OK:', len(points), 'points;', summary['independent_topologies'], 'structures')
PY

nvidia-smi --query-gpu=index,memory.total,memory.used,memory.free --format=csv
```

预计默认规划样本检查输出 `86 points; 9 structures`；B 证据样本为 46 点。若 mas 中没有 vLLM，仅推理服务窗口改用你之前安装 vLLM 的环境；测试脚本窗口仍可用 mas。不要为此自动升级整个训练环境。服务器实际 vLLM 版本和可用显存尚未远程核实。

## 3. tmux 第一个窗口启动模型服务

下面的 GPU 0 是示例，必须改成你当前分配到的单张 GPU。单卡运行，无八卡分布式通信。0.35 是整张卡显存的预算比例，不是剩余空闲显存的 40%；共享机器上需结合上一步实际空闲显存调整。

```bash
export CUDA_VISIBLE_DEVICES=1

set -o pipefail
VLLM_USE_V1=0 \
VLLM_ATTENTION_BACKEND=XFORMERS \
TRITON_PTXAS_PATH=/home/chenjiahao/cuda-11.8/bin/ptxas \
TRITON_CACHE_DIR=/raid/chenjiahao/mas/.cache/triton_vllm085_cu118 \
python -u -m vllm.entrypoints.openai.api_server \
  --model /raid/chenjiahao/mas/models/Qwen3-4B-Instruct-2507 \
  --served-model-name social-base \
  --host 127.0.0.1 --port 8000 \
  --tensor-parallel-size 1 \
  --dtype bfloat16 \
  --max-model-len 16384 \
  --max-num-seqs 1 \
  --gpu-memory-utilization 0.35 \
  --enforce-eager --disable-frontend-multiprocessing \
  --enable-auto-tool-choice \
  --tool-call-parser hermes \
  2>&1 | tee outputs/logs/social_vllm.log
```

本命令针对 vLLM 0.8.5.post1+cu118。V0 环境变量直接绑定本次进程，不依赖另一个 tmux 窗口的 export；关闭 frontend multiprocessing 以让 V0 初始化错误直接显示。这不保证解决未知的 CUDA/依赖错误，但避免只看到 engine 子进程启动失败的包装异常。若日志仍进入 vllm/v1/engine，请先核对实际包版本和完整启动命令。

`hermes` 沿用仓库 Qwen3 命令，也与 [vLLM 的 Qwen 工具调用说明](https://docs.vllm.ai/en/stable/features/tool_calling/)一致。Instruct-2507 这里不配置 Thinking 模型的 reasoning parser。`max-model-len` 包含输入与输出；若服务报告上下文不足，应增加预算并重跑同一配置比较，不截断题目。

服务已在 8000 正确运行时可复用，不要再启动第二个占用相同端口的服务；客户端 `--model` 必须与 `/v1/models` 返回的名称一致。

## 4. 第二个 tmux 窗口运行测试

按 **Ctrl-b，再按 c** 新建窗口，第一个窗口的服务继续运行。

```bash
cd /raid/chenjiahao/mas
conda activate /raid/chenjiahao/conda_envs/mas
export OMP_NUM_THREADS=2
export OPENBLAS_NUM_THREADS=2

curl --fail http://127.0.0.1:8000/v1/models
```

应返回包含 `social-base` 的模型列表。先运行一个结构的固定点，检查固定查询、普通文本说明、工具输出和评分链路。首轮不展开续局。

```bash
set -o pipefail
python -u -m training.b_sft.social_lm_eval \
  --data-dir new/local_data/social_generalization_v3 \
  --output-dir outputs/social_review_reasoning_smoke_0911 \
  --base-url http://127.0.0.1:8000/v1 \
  --model social-base \
  --source evidence-430206 \
  --b-max-tokens 1024 \
  --p-max-tokens 768 \
  --temperature 0 \
  --timeout 180 \
  --p-rollouts 2048 \
  --p-seconds 20 \
  2>&1 | tee outputs/logs/social_review_reasoning_smoke_0911.log
```

确认接口正常后，运行 86 个规划样本：

```bash
set -o pipefail
python -u -m training.b_sft.social_lm_eval \
  --data-dir new/local_data/social_generalization_v3 \
  --output-dir outputs/social_review_reasoning_planning_0911 \
  --base-url http://127.0.0.1:8000/v1 \
  --model social-base \
  --b-max-tokens 1024 \
  --p-max-tokens 768 \
  --temperature 0 \
  --timeout 180 \
  --p-rollouts 2048 \
  --p-seconds 20 \
  2>&1 | tee outputs/logs/social_review_reasoning_planning_0911.log
```

规划样本共 172 次模型请求。B 证据样本须单独运行下面的命令，共 92 次请求；两组有重叠，不能相加当作独立题量。每题仍执行实际 B→P，P 收到模型原始 B。若另行使用 `--continue-game --roots-only`，会增加实际续局调用；这不是 B→P 因果实验。

```bash
set -o pipefail
python -u -m training.b_sft.social_lm_eval \
  --data-dir new/local_data/social_generalization_v3 \
  --cohort belief \
  --output-dir outputs/social_review_reasoning_belief_0911 \
  --base-url http://127.0.0.1:8000/v1 \
  --model social-base \
  --b-max-tokens 1024 --p-max-tokens 768 \
  --temperature 0 --timeout 180 \
  --p-rollouts 2048 --p-seconds 20 \
  2>&1 | tee outputs/logs/social_review_reasoning_belief_0911.log
```

优先看 B 的 `B_required_exact_rate`、`B_support_macro_exact_rate`、`B_protocol_errors`；P 看 `planning_discriminating`，再对照 `by_value_basis` 的简单终局结果。推理文字是否存在只由 `B/P_reasoning_present_rate` 报告，不等同于推理正确。

## 5. 参数如何调整

| 参数 | 本轮值 | 含义 |
|---|---:|---|
| CUDA_VISIBLE_DEVICES | 自行指定一张 | 推理服务使用的 GPU |
| gpu-memory-utilization | 0.35 | 按整张 GPU 容量计算的预算，需适应共享显存 |
| max-model-len | 16384 | 每次请求的输入与输出总 token 上限 |
| max-num-seqs | 1 | 服务并发序列上限；当前审查脚本按次序请求 |
| b-max-tokens / p-max-tokens | 1024 / 768 | 各自输出预算，包含普通文本与工具调用；不是强制推理长度 |
| temperature | 0 | 首轮固定解码；base/训练后模型使用相同设置 |
| p-rollouts / p-seconds | 2048 / 20 | 教师对候选动作的后续比较预算；超出则评分留空 |
| timeout | 180 | 单次模型请求最多等待的秒数 |
| source | evidence-430206 | 指定结构；删除该参数则检查全部结构 |
| continue-game + roots-only | 首轮不启用 | 固定题全部检查，仅从结构起点展开续局 |

没有手动 config 文件；每次运行自动写 `run_config.json`，包含这些参数、数据及实现的哈希。输出目录必须是新的；重新跑时将输出名改为 `_r2`，不要复用已有目录。

## 6. 途中查看、断线重连与下载

另一个终端可查看：

```bash
tail -f /raid/chenjiahao/mas/outputs/logs/social_review_reasoning_smoke_0911.log
```

`calls.jsonl` 每次模型请求完成后保存，`events.jsonl` 每次实际动作完成后保存；`summary.json` 每完成一个固定点及该点请求的续局后更新。`REVIEW.md` 在正常结束时生成，逐点 JSON 提前写在 `review/`。

按 **Ctrl-b，再按 d** 离开 tmux。SSH 断开后重新登录，再执行：

```bash
tmux attach -t social-review
```

下载在 **Mac** 执行；下载整个结果目录，保留 config、原始调用、评分和轨迹：

```bash
cd /Users/bruce/MARSHAL
mkdir -p training/b_sft/debug/social_review_reasoning_smoke_0911

rsync -avzP -e "ssh -i $HOME/.ssh/id_rsa_dgx2 -p 2201" \
  chenjiahao@36.102.215.18:/raid/chenjiahao/mas/outputs/social_review_reasoning_smoke_0911/ \
  training/b_sft/debug/social_review_reasoning_smoke_0911/
```

全量结果将两端目录名换成 `social_review_reasoning_planning_0911` 或 `social_review_reasoning_belief_0911`。优先看 REVIEW.md / summary.json；具体问题看 review/<id>.json 和 calls.jsonl。旧 83 点静态包不适用这个在线入口。

## 并行加速：多个 GPU 副本

运行器新增 `--workers`、`--base-urls` 和 `--cohort both`。独立进程分别回放环境、调用模型及评分；每个进程固定使用一个端点，只有主进程写共享日志。同一题始终先 B 后 P，续局按原来的回合顺序执行；不同题及其续局可并行。相同端点分配多个 worker 时，需要提高该服务的 `--max-num-seqs` 并检查显存。

`both` 对 104 个唯一决策点调用 208 次模型，重叠的 28 个点仅运行一次。`summary.json.by_cohort.belief` 和 `.planning` 分别保留 46 / 86 点的指标，不把合并总体当作某一个分组的分数。选择 `--limit` 时分组统计仅涵盖实际选中的点。

以下示例为全部重启：先停止本任务现有的 social-base 服务，再将 GPU 0–7 映射到端口 8000–8007。假设这八张卡均已分配给你；按实际分配修改 `gpu_ids`。原 GPU 1 / 端口 8000 的实例也必须先停止，以免同一张卡重复加载。使用当前已验证的单卡环境参数，不启用多卡 tensor parallel。

先按本页上传命令重新同步 `training/b_sft/`；此次无需重新上传数据。以下在服务器的 mas 环境运行：

```bash
cd /raid/chenjiahao/mas
conda activate /raid/chenjiahao/conda_envs/mas
mkdir -p outputs/logs

gpu_ids=(2 3 4 5 6 7)
port=8000
for gpu_id in "${gpu_ids[@]}"; do
  nohup env CUDA_VISIBLE_DEVICES="$gpu_id" \
    VLLM_USE_V1=0 VLLM_ATTENTION_BACKEND=XFORMERS \
    TRITON_PTXAS_PATH=/home/chenjiahao/cuda-11.8/bin/ptxas \
    TRITON_CACHE_DIR="/raid/chenjiahao/mas/.cache/triton_vllm085_gpu_${gpu_id}" \
    OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2 \
    python -u -m vllm.entrypoints.openai.api_server \
      --model /raid/chenjiahao/mas/models/Qwen3-4B-Instruct-2507 \
      --served-model-name social-base \
      --host 127.0.0.1 --port "$port" \
      --tensor-parallel-size 1 --dtype bfloat16 \
      --max-model-len 16384 --max-num-seqs 1 \
      --gpu-memory-utilization 0.35 \
      --enforce-eager --disable-frontend-multiprocessing \
      --enable-auto-tool-choice --tool-call-parser hermes \
      > "outputs/logs/social_vllm_${port}.log" 2>&1 &
  echo "$!" > "outputs/logs/social_vllm_${port}.pid"
  port=$((port + 1))
done
```

等待各服务启动后检查；每个端口都应返回 `social-base`：

```bash
for port in 8000 8001 8002 8003 8004 8005 8006 8007; do
  curl --fail --max-time 5 "http://127.0.0.1:${port}/v1/models"
done
```

开始新的合并测试，输出目录必须不存在：

```bash
export OMP_NUM_THREADS=2
export OPENBLAS_NUM_THREADS=2
set -o pipefail
python -u -m training.b_sft.social_lm_eval \
  --data-dir new/local_data/social_generalization_v3 \
  --cohort both --workers 6 \
  --base-urls \
    http://127.0.0.1:8000/v1 http://127.0.0.1:8001/v1 \
    http://127.0.0.1:8002/v1 http://127.0.0.1:8003/v1 \
    http://127.0.0.1:8004/v1 http://127.0.0.1:8005/v1 \
  --model social-base \
  --output-dir outputs/social_reasoning_parallel6_r1 \
  --b-max-tokens 1024 --p-max-tokens 768 \
  --temperature 0 --timeout 180 \
  --p-rollouts 2048 --p-seconds 20 \
  2>&1 | tee outputs/logs/social_reasoning_parallel8_r1.log
```

可先加入 `--limit 8` 并换一个 smoke 输出目录。只有四张卡时，使用四个端点和 `--workers 4`。已有旧测试结果不会自动恢复或复用，勿覆盖旧目录。以后添加 `--continue-game --roots-only` 时，不同起点及其续局也会并行；一个起点内部的兼容世界仍按顺序处理，长续局可能产生尾部等待。

若每个完整决策点约 100 秒，则旧两组分开跑约 132 × 100 = 3.7 小时；合并后八个 worker 的理想估计为 104 × 100 / 8 ≈ 22 分钟，实际取决于共享 GPU 负载、CPU 教师耗时及任务长度。更多 GPU 提升总吞吐，不保证单次生成变快。进度日志现在直接显示 B 调用、P 调用及教师评分各自耗时；并行时也应检查教师不可用率，CPU 的墙钟预算仍可能触发。
