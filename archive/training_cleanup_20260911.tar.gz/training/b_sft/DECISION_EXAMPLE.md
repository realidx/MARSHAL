# 一条真实开发样本：native-30040-g6-d2

这是已使用过的开发局面，不是新测试样本。原生规则及完整输入见 development.jsonl；这里仅展示关联如何落盘。

## 根决策点

- 角色：{'you_control': 'P1', 'partner_under_assessment': 'P2', 'assessed_goals': ['G6']}
- 自己的目标：{'player': 'P1', 'by_goal': {'G0': 'want', 'G1': 'want', 'G2': 'avoid', 'G3': 'want', 'G4': 'want', 'G5': 'avoid', 'G6': 'want', 'G7': 'avoid'}}
- 根 B 答案：{'possible_preferences': ['want', 'neutral', 'avoid']}
- 根 P 示范：{'action_index': 9}
- 根 P 全部最优索引：[8, 9, 10, 12]

## 行动后的监督

| 分支 | 行动索引 | 根行动是否最优 | 判断变化 | 后 B | 后 P 全部最优索引 |
|---|---:|---|---|---|---|
| reference_best | 8 | True | maintain | ['want', 'neutral', 'avoid'] | 终局，无 P |
| low_information | 7 | False | maintain | ['want', 'neutral', 'avoid'] | [0, 1] |
| high_information | 11 | False | update | ['want', 'neutral'] | [1] |
| high_information | 11 | False | update | ['avoid'] | [0, 1] |

分支是为获得监督而执行的合法干预；低信息/低收益干预不会因此变成根 P 正确答案。下列证据是参考器生成后又用于构造后续输入的公开行动。

### 分支 1

后 B ID：`native-30040-g6-d2/after_bb1ea78fb7a3/0/belief`

```json
{
  "ego_action": {
    "action": "OFFER",
    "partner_id": 2,
    "proposer_action": [
      1,
      1
    ],
    "partner_action": [
      1,
      0
    ]
  },
  "observed_evidence": [
    {
      "turn_index": 4,
      "player_id": 2,
      "action": {
        "response": "ACCEPT"
      }
    },
    {
      "turn_index": 5,
      "player_id": 0,
      "action": {
        "action": "OFFER",
        "partner_id": 2,
        "proposer_action": [
          1,
          1
        ],
        "partner_action": [
          1,
          1
        ]
      }
    },
    {
      "turn_index": 5,
      "player_id": 2,
      "action": {
        "response": "REJECT"
      }
    }
  ]
}
```

### 分支 2

后 B ID：`native-30040-g6-d2/after_caa9523a010e/0/belief`

```json
{
  "ego_action": {
    "action": "OFFER",
    "partner_id": 2,
    "proposer_action": [
      1,
      0
    ],
    "partner_action": [
      1,
      1
    ]
  },
  "observed_evidence": [
    {
      "turn_index": 4,
      "player_id": 2,
      "action": {
        "response": "ACCEPT"
      }
    },
    {
      "turn_index": 5,
      "player_id": 0,
      "action": {
        "action": "OFFER",
        "partner_id": 1,
        "proposer_action": [
          1,
          1
        ],
        "partner_action": [
          1,
          0
        ]
      }
    }
  ]
}
```

### 分支 3

后 B ID：`native-30040-g6-d2/after_655f72f82fc2/0/belief`

```json
{
  "ego_action": {
    "action": "MENU",
    "partner_id": 2,
    "offers": [
      {
        "partner_id": 2,
        "proposer_action": [
          1,
          0
        ],
        "partner_action": [
          1,
          1
        ]
      },
      {
        "partner_id": 2,
        "proposer_action": [
          1,
          1
        ],
        "partner_action": [
          1,
          1
        ]
      }
    ]
  },
  "observed_evidence": [
    {
      "turn_index": 4,
      "player_id": 2,
      "action": {
        "response": "CHOOSE_2"
      }
    },
    {
      "turn_index": 5,
      "player_id": 0,
      "action": {
        "action": "OFFER",
        "partner_id": 1,
        "proposer_action": [
          1,
          1
        ],
        "partner_action": [
          1,
          1
        ]
      }
    }
  ]
}
```

### 分支 4

后 B ID：`native-30040-g6-d2/after_655f72f82fc2/1/belief`

```json
{
  "ego_action": {
    "action": "MENU",
    "partner_id": 2,
    "offers": [
      {
        "partner_id": 2,
        "proposer_action": [
          1,
          0
        ],
        "partner_action": [
          1,
          1
        ]
      },
      {
        "partner_id": 2,
        "proposer_action": [
          1,
          1
        ],
        "partner_action": [
          1,
          1
        ]
      }
    ]
  },
  "observed_evidence": [
    {
      "turn_index": 4,
      "player_id": 2,
      "action": {
        "response": "CHOOSE_1"
      }
    },
    {
      "turn_index": 5,
      "player_id": 0,
      "action": {
        "action": "OFFER",
        "partner_id": 1,
        "proposer_action": [
          1,
          1
        ],
        "partner_action": [
          1,
          0
        ]
      }
    }
  ]
}
```

