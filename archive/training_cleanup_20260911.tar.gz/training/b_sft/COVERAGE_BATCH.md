# 小规模随机社会判断审查包

先看：[4 个互补结构的逐局审查](../../new/local_data/social_reasoning_review_v2/REVIEW.md)。总览：[REPORT.md](../../new/local_data/social_reasoning_review_v2/REPORT.md)，完整规则、候选偏好与所有关联节点：[review_selection.json](../../new/local_data/social_reasoning_review_v2/review_selection.json)。

## 采样范围

这次扩展了实际生成器，而非只让单偏好样本换名字：

- 3/4 人。
- 每人 1/2 个 commitment；goal 数覆盖 4、6、7、8。
- single：一个伙伴隐藏一个 goal。
- multi_goal：同一伙伴隐藏两个 goal，独立笛卡尔积 9 个配置。
- multi_partner：两个伙伴分别隐藏一个 goal，独立联合 9 个 world。
- 同一配置两条随机 ego 路径，固定声明伙伴策略，从开局执行到终局。新批次抽取剩余最多 4 个 proposal slots 的实际 ego 决策；不是全游戏早期覆盖。

新增两批共 36 个配置任务、72 条完成轨迹，约 92 秒。再合并上一轮随机漏斗结果，按精确结构与历史去重，最终有 **15 个精确结构哈希、109 个决策记录**，其中 **16 个**通过信息分支与终局价值验证。不是 15 个已经完成同构去重的独立推理结构。

筛选按分级覆盖，不要求每局都有全部情形；普通对照保留。按覆盖增益选出 4 个结构供人工审查，没有为凑 8 个重复取样。

## 覆盖与缺口

| 已验证的覆盖（类别可重叠） | 全库存节点数 |
|---|---:|
| 新证据后 B 改变且还有后续决策 | 16 |
| 历史增加但 B 维持且还有后续决策 | 18 |
| 多元素集合内非平凡 favored | 2 |
| 有信息但次优的行动 | 9 |
| 有信息且为最优的行动 | 10 |

所选 4 个结构合计覆盖三种隐藏方式、3/4 人、1/2 commitment 和上述 goal 数。每个结构的所有候选保存在 JSON，人工可读版只展示一个代表节点。

这些标签只证明声明参考环境下的机会。还没有完成：

- 自身目标改变、伙伴信息不变的反事实证书。
- 信息带来的正净价值证书；最优信息行动的收益可能来自 commitment 本身。
- 本批次的严格同状态必要行动切换检查；那类证书仍是独立诊断，不是普通节点门槛。
- 完整早期决策覆盖、三个伙伴同时隐藏偏好、linear goal、未见伙伴策略。

因此审查包 `training_ready=false`，不是宣称 social reasoning 已覆盖完毕，也没有训练 LM/PPO。旧统一数据包及原 train/test 不变。

## 合并检查发现并修复的问题

多伙伴独立隐藏可能使某个 goal 在所有玩家处同时取 neutral，即使各个玩家单独看都合法。这违反原生成器要求的 goal 偏好约束。

合并校验发现一个此类配置，排除了它的 2 条记录，原因保存于 [exclusions.jsonl](../../new/local_data/social_reasoning_review_v2/exclusions.jsonl)。`make_game` 现在生成时就检查所有独立候选是否可能形成全 neutral goal；同时验证每个唯一候选仍有至少一个 want。没有通过删除某些 joint world 偷偷引入玩家间相关性。

原始批次与 `social_reasoning_review_v1` 留作溯源；人工审查使用 **review_v2**。

## 代码与预算

[coverage_batch.py](coverage_batch.py) 负责参数网格、原生生成、随机路径、分级筛选和审查选择。`random_funnel.screen` 改用支持多伙伴目录的公共构建接口，绕开旧单目标 Fixture 的限制，但不改变原生伙伴策略和信息边界。

每个配置由独立 worker 进程执行，默认 12 秒硬超时，总批次默认 150 秒。超时记为未完成，不算低价值；已完整写出的 JSONL 记录保留，末尾被中断的半条记录不算成功。没有自动恢复功能，重复运行使用新目录。当前两批 worker 全部正常结束。

```bash
python -m training.b_sft.coverage_batch \
  --seed 98001 --seeds-per-layout 2 --paths 2 \
  --remaining-turns 4 --max-nodes 1000 --max-arms 8 \
  --seconds 150 --job-seconds 12 \
  --output-dir new/local_data/MY_COVERAGE_BATCH

python -m training.b_sft.coverage_batch \
  --merge-batch new/local_data/random_funnel_v1 \
                new/local_data/social_coverage_batch_v1 \
                new/local_data/social_coverage_batch_v2 \
  --review-limit 8 \
  --output-dir new/local_data/MY_REVIEW
```

merger 只接受 development，拒绝把 held-out 样本混入选种。`selected_fixtures.json` 是原生可重放场景，不是旧 B-only SFT 输入，多伙伴样本也不能交给旧单查询导出器。

下一步应先逐局审查这 4 个结构，判断公开证据、B 标签和行动代价是否符合我们要训练的社会判断；按发现的问题补样本，不继续无目标地扩大数量。
