# 修复后的在线数据

固定查询协议：social-fixed-queries-v1。原始数据不变，教师标签在线重算。

```json
{
  "decisions": 86,
  "independent_topologies": 9,
  "phase": {
    "proposal": 42,
    "response": 44
  },
  "response_targets": {
    "accept": 14,
    "tie": 24,
    "null": 2,
    "reject": 4
  },
  "remaining_proposal_turns": {
    "2": 44,
    "3": 12,
    "1": 28,
    "4": 2
  },
  "menu_decisions": 9,
  "nonterminal_decisions": 54,
  "discriminating_P": 47,
  "B_supervision_basis": {
    "no_exclusion": 61,
    "native_order_sensitive": 3,
    "prosocial_rule_conditioned": 9,
    "strict_self_value": 13
  },
  "B_targets": 163,
  "B_supports": {
    "want/neutral/avoid": 130,
    "neutral/avoid": 8,
    "avoid": 5,
    "want": 6,
    "want/neutral": 14
  },
  "B_favored": {
    "undetermined": 148,
    "avoid": 6,
    "want": 9
  },
  "by_topology": {
    "0360639f3f7706db6c99b704fb1d53b20256d3b45bf883268245686b19d7c610": 16,
    "0e37c1c61a170a3af91ce6f262aeee29c40c0bdd3c86ebd4bbc8dd123f1b5407": 15,
    "2389e988ca935f3069deabbd432d57f776e9f28cc87bbc9872bd0d212547b99b": 7,
    "2de3cbe229c42132f3559344fbaad429d557c64c33cdc8cbcde1097930aee239": 3,
    "3477e97e2eba0539b34dacb9a561337493c0c19e4cadf65a471e97dc9e49eef4": 3,
    "6e3f45629c4f4b38931c94bac2046928b780f2d177e6a333e8ff1cb5ec654ff8": 10,
    "a033e166617555c024ab47a8bd78566756022f446becddfef117f9e7e0754625": 7,
    "b0fc2031ef33ebabb40e6f3e75ae8a9f2136b68e815dcb940c431f914adcc3e8": 7,
    "e097bdc4abf6a5cca7baa19f62e7e8ec5088c59e49c30fdf18c5652b1fc869e6": 18
  }
}
```

逐项监督依据见 questions.jsonl 的 supervision；全部候选及完整轨迹保留，缺标签不填零。
本包为开发数据；静态旧标签未复制，现有 B-only SFT 入口不消费本包。
