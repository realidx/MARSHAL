# 修复后的在线数据

固定查询协议：social-fixed-queries-v1。原始数据不变，教师标签在线重算。

```json
{
  "decisions": 48,
  "independent_topologies": 4,
  "phase": {
    "proposal": 30,
    "response": 18
  },
  "response_targets": {
    "reject": 6,
    "tie": 5,
    "accept": 7
  },
  "remaining_proposal_turns": {
    "3": 25,
    "1": 10,
    "4": 3,
    "2": 9,
    "5": 1
  },
  "menu_decisions": 16,
  "nonterminal_decisions": 40,
  "discriminating_P": 41,
  "B_supervision_basis": {
    "no_exclusion": 37,
    "prosocial_rule_conditioned": 3,
    "strict_self_value": 8
  },
  "B_targets": 97,
  "B_supports": {
    "want/neutral/avoid": 79,
    "want": 4,
    "neutral/avoid": 4,
    "want/avoid": 4,
    "avoid": 6
  },
  "B_favored": {
    "undetermined": 81,
    "want": 8,
    "avoid": 8
  },
  "by_topology": {
    "2cb77f3348d1d402843af0fccf7027980fca2ec16439874ba3d7ef6fd3e9f7d3": 18,
    "673aa51971acc9f5848842514cccf25267aaf61227f222805981669ad11cddce": 3,
    "773b3c95c882afba6847e673089b93cb88ab8b2bc8b68994bce954a446beaefa": 14,
    "bbe759c9c15b535b618bae75ce5a00681b25b8b338bfb1713c7420ffd0505b74": 13
  }
}
```

逐项监督依据见 questions.jsonl 的 supervision；全部候选及完整轨迹保留，缺标签不填零。
本包为开发数据；静态旧标签未复制，现有 B-only SFT 入口不消费本包。
