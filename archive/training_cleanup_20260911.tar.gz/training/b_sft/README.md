# B-only SFT：共享八张 A100 / ZeRO-3

**训练前 LM 审查入口见 [SOCIAL_LM_EVAL.md](SOCIAL_LM_EVAL.md)**：独立结构开发包已扩充到 9 个结构、90 个点，其中 38 个点有可评分的 B 收缩证据。新测试脚本记录实际 B/P 输入输出、目标覆盖、评分、动作、终局和耗时，使用 tool-call auto；37 项测试及 90 点 / 225 条续局 dry-run 通过，尚未调用真实 LM。新脚本仅接受在线协议包，旧 83 点静态材料需迁移后再接入。

**在线动作与泛化检查见 [ONLINE_SOCIAL.md](ONLINE_SOCIAL.md)**：合法的非教师动作可继续到终局，按实际历史重算 B/P，错误 B 原样交给 P；新增 3 个独立结构、20 个决策点的开发泛化集。30 项相关测试通过，尚未接入 LM/PPO 训练。

**最新小规模社会判断样本见 [SOCIAL_CASES.md](SOCIAL_CASES.md)**：已扩充到 83 个精选决策点，补上合作尝试与反馈的正例、多项/多伙伴隐藏、补偿性接受和等待更好机会的对照；另有两条延迟收益路线。B 自选关注对象，P 接收模型 B；不要求每个 B 点都改变行动，不生成理由监督。审查包与旧 SFT 数据分开。

**当前教师入口见 [SHARED_TEACHER.md](SHARED_TEACHER.md)**：所有玩家使用同一有限窗口机制，自身收益同分时帮助其他玩家。原四局已在全部 24 个隐藏世界组合中重新运行并验证 B/P 一致性；历史 `RationalPartner` 不再代表这个新机制。

**最新四局审查见 [DATASET_REVIEW.md](DATASET_REVIEW.md)**：发现部分 B 收缩依赖教师同分选法，部分信息行动无规划区分度；已补目标变化对照、奖励屏蔽标记和 113 条统一记录。仍缺不带局部同分敏感标记的 B→P 行动切换对照，尚非训练就绪。

**小规模随机审查包见 [COVERAGE_BATCH.md](COVERAGE_BATCH.md)**：3/4 人、不同 commitment/goal、多伙伴隐藏偏好；已选出 4 个互补结构并生成逐局可读报告。

**随机生成筛选实验见 [RANDOM_FUNNEL.md](RANDOM_FUNNEL.md)**：多路径独立采样与阶段漏斗，首轮已发现信息/终局价值机会，普通对照与计算缺失分开处理。

**统一开发数据集见 [UNIFIED_DATASET.md](UNIFIED_DATASET.md)**：现有数据已统一重放，含完整样本报告、参考轨迹、固定全量 B 查询和原生 P 标签；仍非正式训练就绪。

**全量 B 查询与终局闭环见 [SOCIAL_ROLLOUT.md](SOCIAL_ROLLOUT.md)**：CPU callback 运行器已验证 B→P→环境到真实终局；尚未接 LM/PPO。

**新 B 倾向教师见 [FAVORED_BELIEF.md](FAVORED_BELIEF.md)**：联合隐藏配置下的 set/favored 标签与局部评分，已导出同集合、不同倾向的开发对照；尚未证明倾向单独带来规划改善。

**首个严格证据切换样本见 [EVIDENCE_SWITCH.md](EVIDENCE_SWITCH.md)**：相同当前状态与 offer，不同合法历史要求不同最优响应；已重放验证并导出开发数据。

**结构级数据审计见 [STRUCTURE_AUDIT.md](STRUCTURE_AUDIT.md)**：检查共同最优动作、信息行动代价与覆盖缺口，提供少量设计种子建议；不改变原有训练/测试划分。

**完整的新训练计划见 [SOCIAL_REASONING_TRAINING_PLAN.md](SOCIAL_REASONING_TRAINING_PLAN.md)**：涵盖游戏与决策点筛选、B/P 教师、outcome 主导的 PPO 与 value head，以及一局真实游戏的逐步监督演示。该方案尚待实现；下文仍是旧 SFT 入口。

**新的 B/P 数据方向见 [DECISION_CORPUS.md](DECISION_CORPUS.md)**：已生成可重放的判断—行动—证据—后续判断配对数据，保留答案监督。该数据仍是条件化残局开发版本，混合 B/P 文件不能直接使用下文旧 B-only 训练命令。

**最新正式实验入口见 [ROUND1.md](ROUND1.md)**：3/4 玩家数据、5 玩家 OOD、linear/mixed goals、
完整配对筛选、独立常规保存间隔与 test/OOD 评估。本轮不再安排旧数据 pilot。
下文旧命令保留供当前服务器测试和历史进展核对；运行中的测试不需要更换代码。

独立 Transformers Trainer + DeepSpeed 入口，不加载 ROLL、vLLM 或 reference model。
服务器假设：共享 8×A100，启动前动态检查所选 GPU，必须显式指定 CUDA_VISIBLE_DEVICES。
不假设每卡固定剩余显存，不自动选卡或抢占已有任务。
这是待服务器验证的训练实现，不表示八卡并发显存、吞吐或 checkpoint 恢复已经实测通过。
环境依赖：PyTorch、支持 Qwen3 的 Transformers（接口以 4.57.3 为目标）、Accelerate、
DeepSpeed、safetensors。本轮不安装或更改服务器环境。
默认 fused loss 还需要支持 Qwen3 `skip_logits` 的 liger-kernel；启动时检查能力，
缺失或不兼容会明确报错，不自动安装、不静默退回完整 logits。

## 运行

从仓库根目录执行，所有运行文件和缓存放 `/raid` 自己的工作目录。
下列路径需要替换；训练输入使用已导出的 messages/tools JSONL，不把生成数据加入 Git。

```bash
export HF_HOME=/raid/YOUR_USER/cache/huggingface
export TORCH_EXTENSIONS_DIR=/raid/YOUR_USER/cache/torch_extensions
export TMPDIR=/raid/YOUR_USER/tmp
mkdir -p "$HF_HOME" "$TORCH_EXTENSIONS_DIR" "$TMPDIR"

# 先查看当前资源，再按实际获准共用的 GPU 设置；下面八卡仅为示例。
nvidia-smi
export CUDA_VISIBLE_DEVICES=0,1,2,3,4,5,6,7

bash training/b_sft/run_shared.sh \
  --model /raid/YOUR_USER/models/Qwen3-4B-Instruct-2507 \
  --train-file new/local_data/b_sft_ready_roles_v1/train.jsonl \
  --eval-file new/local_data/b_sft_ready_roles_v1/validation.jsonl \
  --output-dir /raid/YOUR_USER/b_sft/bench_zero3 \
  --mode benchmark --max-steps 20 --loss-backend liger

python -m training.b_sft.summarize /raid/YOUR_USER/b_sft/bench_zero3
```

启动器要求显式 CUDA_VISIBLE_DEVICES（支持编号或完整 GPU UUID），启动前重新查询所选 GPU
的空闲显存和利用率，输出快照，再按所选卡数启动进程。未设置、卡不存在、重复选卡或查询失败均拒绝启动。
可选设置 `B_SFT_MIN_FREE_MIB`，在任一卡低于自定空闲显存门槛时退出；默认不设容量门槛。
该检查不会预留显存，也不证明这些卡获准使用或训练一定能放下；已有忙碌任务允许共存。
旧 `run_8gpu.sh` 保留为转发入口，同样必须显式选卡。

每卡 micro-batch 1、梯度累积默认 2（八卡时全局 batch 16）、BF16、SDPA、激活检查点。
如果选卡数变化，全局 batch = 卡数 × 梯度累积；需要自行调整 `--gradient-accumulation` 保持实验设置。
更少卡意味着每卡 ZeRO 分片更大，必须重新测显存，不能沿用八卡可行性的判断。
全参数更新；不截断、不拼接样本；只监督 assistant completion，padding/input 标签均为 -100。
起步学习率 5e-6，constant schedule、无 warmup、weight decay 0，仅为 pilot 默认值。
正式实验的超参和训练轮数应另行决定。

## LM head / CE 显存优化

### 只评估原始模型

保留成功训练时的 CUDA_VISIBLE_DEVICES、TRITON_PTXAS_PATH 和 TRITON_CACHE_DIR 设置，
使用相同验证集、max-length、loss backend 和并行卡数，以便与训练后 eval_loss 对照：

```bash
bash training/b_sft/run_shared.sh \
  --mode eval \
  --model /raid/YOUR_USER/models/Qwen3-4B-Instruct-2507 \
  --eval-file new/local_data/b_sft_ready_roles_v1/validation.jsonl \
  --output-dir /raid/YOUR_USER/b_sft/eval_original \
  --loss-backend liger
```

eval 不读取训练集、不调用 train/backward/optimizer step、不保存 checkpoint；
DeepSpeed 配置移除 optimizer/scheduler，仅保留 ZeRO-3 模型分片路径。
输出 `eval_results.json`、manifest 和资源日志，终端也打印指标。
必须使用新输出目录；不传 --resume 或 --max-steps。--model 需为普通 HF 模型目录，
不能直接填未经合并的 ZeRO checkpoint。此模式不是生成式 B 集合评估。

默认 `--loss-backend liger` 使用 Transformers 官方 `use_liger_kernel` 接口，
仅启用 `fused_linear_cross_entropy`，显式关闭 RoPE、RMSNorm、SwiGLU 和普通 CE 替换。
Trainer 原有 causal loss 的 token 计数、梯度累积和分布式归一化路径保持不变；
不删除 FP32 数值计算，不冻结参数，也不改变数据标签。
训练及 loss-only 验证均传 `skip_logits=True`，避免验证重新生成完整 logits。
这不是 TRL 的过滤有效 token + chunked_nll 实现，不声称只处理 26–30 个有效位置。

普通对照使用 `--loss-backend standard`，在另一个新目录从相同原始模型起跑。
不要在同一 Python 进程中切换后端；Liger 补丁可能修改进程内模型实现。
loss 后端进入 resume signature，不允许跨后端恢复；旧版没有该字段的运行也需新开目录。
manifest 记录 backend、patch 函数和相关包版本。导出权重仍是普通 Qwen 权重，不要求推理启用 Liger。

服务器上可先运行小模型数值验收（使用一张获准使用的 GPU）：

```bash
CUDA_VISIBLE_DEVICES=YOUR_GPU python -m pytest training/b_sft/test_liger_cuda.py -q
```

它比较相同权重的标准/fused loss 与全部参数梯度，覆盖不同有效 token 数的两个累积 microbatch，
并断言训练和 eval 均不返回 logits。它不替代真实 ZeRO-3 多卡集成测试。
本地无兼容 CUDA/Liger 环境时该测试跳过，不能视作数值验收通过。

benchmark 和正式训练使用同一个入口、loss 和保存路径。benchmark 重复最长的 16 条真实训练样本，
右侧 masked padding 到 4096，运行真实反向和 optimizer 更新；默认 20 个 optimizer steps。
这覆盖 4K 张量长度，不等于真实 4K 有效上下文（SDPA 可能利用 padding 优化），不能据此声称所有
4K 长上下文均已验证。benchmark 权重仅用于工程验证；正式训练从原始模型重新开始。

比较 optimizer CPU offload 时使用新的 output-dir，并添加：

```bash
--deepspeed training/b_sft/configs/zero3_shared_optimizer_offload.json
```

两份配置只差 optimizer offload。通信 bucket 和预取各 500 万元素，限制持久/活跃参数，
关闭 overlap_comm；这些是节省峰值的起步值，不是显存硬配额。模块计算仍可能临时聚合超出阈值。
默认无参数 offload。不能保证给另一任务保留 3GiB，也不会自动终止或更改其他任务。

## 保存和恢复验证

默认每 20 步及最后一步保存完整 Trainer/ZeRO checkpoint，最多保留两份。
模型权重不在 GPU 上合并；保存包含 optimizer/scheduler/RNG 状态，可恢复训练。
首次基准结束后，使用完全相同的 model、数据、配置、seed 和并行卡数，显式恢复：

```bash
# 在上面的启动命令中保留同一 output-dir，并改为：
--mode benchmark --max-steps 22 \
--resume /raid/YOUR_USER/b_sft/bench_zero3/checkpoint-20
```

max-steps 是累计步数，22 表示从第 20 步再更新两步。检查日志步数/optimizer/RNG 加载和 loss 有限。
入口拒绝数据、模板、并行配置或主要训练超参不一致的恢复；保留原运行目录中的 manifest。
不要跨无 offload/offload 配置续训做性能比较；两组应从同一原始模型独立起跑。
短基准还必须在服务器确认参数确实更新、保存/恢复成功，而非仅看启动成功。

正式训练把 `--mode` 改为 `train --epochs 1`，不传 max-steps，使用新目录与原始模型。
验证阶段仅计算 loss，不生成文本；语义 B 评估使用后续独立推理和现有 b_eval。

## CPU 导出

训练完成后执行（仅加载可信的自己生成的 checkpoint）：

```bash
python -m training.b_sft.export \
  --checkpoint /raid/YOUR_USER/b_sft/bench_zero3/checkpoint-22 \
  --output-dir /raid/YOUR_USER/b_sft/export_bench
```

导出程序显式禁用 CUDA，使用 DeepSpeed 官方 CPU 合并函数，输出分片 FP32 safetensors，
并复制 tokenizer/config。约 4B 参数的 FP32 权重约 16GB，合并需要额外 RAM 和磁盘空间。
推理加载时明确选择 BF16；服务器还需验证导出模型能加载、生成合法工具调用。

## 监测与验收

- `gpu_resources.jsonl`：每约 5 秒采集所有 GPU 总占用、空闲显存、利用率，以及各进程显存；
  包含 UUID，可关联 CUDA_VISIBLE_DEVICES 的物理卡。采样可能漏掉瞬时峰值。
- `rank_N_steps.jsonl`：每个训练进程 PID、optimizer step 耗时、PyTorch 峰值 allocated/reserved、
  进程 RSS/HWM。allocator 不包含全部 NCCL/CUDA 显存。
  benchmark 还记录 q_proj 局部分片采样值的变化量；非零证明采样权重发生更新，
  全零时需要进一步检查，不能仅靠 loss 有限认定更新正确。
- `train_results.json`：端到端训练速度；汇总工具的 step 速度排除保存和评估耗时。
- `run_manifest_*.json`：启动参数、数据哈希、实际模板哈希、DS 配置、参数量。

先确认短基准及恢复/导出通过，再看现有任务的资源波动与我们的吞吐。
八卡同步会受最慢卡牵制；100% GPU 利用率下共享运行不保证比独占单卡快。
本程序不设置显存隔离，不自动切换 offload，不修改现有任务。

## 本地验证范围

`python -m pytest training/b_sft/test_data.py -q` 覆盖 loss mask、padding、超长拒绝、
token 边界、标签校验、划分重叠、恢复一致性和统计口径。
已使用本地官方 Qwen tokenizer/template 对现有 849 条样本运行同一编码逻辑：
最长 3385 tokens，监督目标 26–30 tokens，全部通过。
这次检查使用 Jinja/tokenizers 适配器；未在本地执行 Transformers/DeepSpeed CUDA 集成训练。

参考：[Transformers DeepSpeed 集成](https://github.com/huggingface/transformers/blob/main/docs/source/en/deepspeed.md)、
[DeepSpeed CPU checkpoint 合并](https://deepspeed.readthedocs.io/en/stable/model-checkpointing.html)。
Liger 接口参考：[Transformers kernels](https://huggingface.co/docs/transformers/kernels)、
[Qwen3 fused forward](https://github.com/linkedin/Liger-Kernel/blob/main/src/liger_kernel/transformers/model/qwen3.py)。



cd /raid/chenjiahao/mas
conda activate /raid/chenjiahao/conda_envs/mas

# 上传独立训练入口、配置及说明
rsync -avzP \
  --exclude='__pycache__/' \
  --exclude='.pytest_cache/' \
  -e "ssh -i $HOME/.ssh/id_rsa_dgx2 -p 2201" \
  training/b_sft/ \
  chenjiahao@36.102.215.18:/raid/chenjiahao/mas/training/b_sft/

# 上传训练集和验证集
rsync -avzP \
  -e "ssh -i $HOME/.ssh/id_rsa_dgx2 -p 2201" \
  new/local_data/b_sft_ready_roles_v1/ \
  chenjiahao@36.102.215.18:/raid/chenjiahao/mas/new/local_data/b_sft_ready_roles_v1/

# 前后配对索引，供 maintain/update 评分使用
rsync -avzP \
  -e "ssh -i $HOME/.ssh/id_rsa_dgx2 -p 2201" \
  new/local_data/b_independent_focal_roles_v1/update_pairs.jsonl \
  chenjiahao@36.102.215.18:/raid/chenjiahao/mas/new/local_data/b_sft_ready_roles_v1/update_pairs.jsonl


export TRITON_PTXAS_PATH=/home/chenjiahao/cuda-11.8/bin/ptxas
export TRITON_CACHE_DIR=/raid/chenjiahao/mas/.cache/triton_b_sft_semantic_v1

python - <<'PY'
from triton.backends.nvidia.compiler import _path_to_binary
print(_path_to_binary("ptxas"))
PY

nvidia-smi

export CUDA_VISIBLE_DEVICES=0,1,2,3,4,5,6,7

python -m pytest \
  training/b_sft/test_semantic.py \
  training/b_sft/test_trainer_semantic.py -q

bash training/b_sft/run_8gpu.sh \
  --model /raid/chenjiahao/mas/models/Qwen3-4B-Instruct-2507 \
  --train-file new/local_data/b_sft_ready_roles_v1/train.jsonl \
  --eval-file new/local_data/b_sft_ready_roles_v1/validation.jsonl \
  --output-dir /raid/chenjiahao/mas/outputs/smoke_8gpu_offload_expand \
  --mode benchmark \
  --max-steps 20 \
  --deepspeed training/b_sft/configs/zero3_shared_optimizer_offload.json \
  --loss-backend liger

bash training/b_sft/run_shared.sh \
  --mode eval \
  --model /raid/chenjiahao/mas/models/Qwen3-4B-Instruct-2507 \
  --eval-file new/local_data/b_sft_ready_roles_v1/validation.jsonl \
  --output-dir /raid/chenjiahao/mas/runs/eval_original \
  --loss-backend liger




bash training/b_sft/run_shared.sh \
  --mode train \
  --semantic-eval \
  --model /raid/chenjiahao/mas/models/Qwen3-4B-Instruct-2507 \
  --train-file new/local_data/b_sft_ready_roles_v1/train.jsonl \
  --eval-file new/local_data/b_sft_ready_roles_v1/validation.jsonl \
  --pairs-file new/local_data/b_sft_ready_roles_v1/update_pairs.jsonl \
  --output-dir /raid/chenjiahao/mas/outputs/b_sft_semantic_smoke_v1 \
  --deepspeed training/b_sft/configs/zero3_shared_optimizer_offload.json \
  --loss-backend liger \
  --gradient-accumulation 2 \
  --learning-rate 5e-6 \
  --max-steps 2 \
  --semantic-eval-steps 1 \
  --early-stopping-patience 0 \
  --generation-max-new-tokens 128 \
  --train-probe-size 32
---

## 进展交接记录（2026-09-09；供下一轮 SFT 设计使用）

本节追加记录实际进展。上方用户保存的 command 保持原样。前文关于“尚未实测”的说明属于
实现阶段状态；最新已验证范围以下文为准。远程结果来自用户回传日志，尚未拉取全部远程产物。

### 研究目标与当前边界

- 研究主线仍为 Diagnose → Post-train → Solve → Transfer，关注 partner belief（B）和
  partner-conditioned planning（P）。当前先解决 B，尚未做 B/P 混训或 outcome RL。
- B 输出公开历史和固定伙伴策略下所有仍然可能的 want/neutral/avoid 语义集合。
  金标不是伙伴实际私有偏好，也不是概率、Q 或单一偏好的强制分类；歧义集合是合法监督。
- 当前工程使用 Qwen3-4B-Instruct-2507，原生 SUBMIT_JUDGMENT 工具调用。
  输入允许 brief reasoning，但本批数据没有 reasoning 监督目标，仅监督 assistant 工具调用。
- 正式 Diagnose 最新完整能力缺陷及修复效应仍未得到新的正式结果验证；这轮 SFT 基准不替代它。

### 数据背景（供设计参考，不应把工程基准当正式训练）

完整生成与核验记录见 [B 数据报告](../../new/b_only_training_data.md)。

- 14 个源游戏，覆盖四玩家、2/3 commitments、12/16 goals、4/6 rounds 两种配置。
- 每玩家 6 个背景 × 两个独立 queried goal 的 3×3 偏好，共 54 候选行。
  已消除“识别背景即可推出被查询偏好”的捷径，但仍是有限先验，不是完整原生偏好空间。
- 固定 MCTS oracle 策略下，1,316 个去重 B 问题和 987 对判断更新已核验。
  精确集合标签是相对于该固定有限策略而言，不意味着 MCTS 是精确最优求解器。
- 最终 849 条：train 610 / validation 113 / test 126；按源游戏与目标拓扑隔离。
  各划分包含全部七种非空集合，训练源覆盖 P0–P3。
- 官方 tokenizer 检查最长序列 3,385 tokens，监督目标仅 26–30 tokens。
- 生成游戏、JSONL 和运行记录留在 Git 外；服务器只需独立 training/b_sft 目录、所需数据和模型。
- 自然轨迹仍容易较早消除不确定性，跨伙伴策略泛化未验证。

### 已实现的训练入口

`train.py` 有三种模式：benchmark / train / eval。默认 loss backend 为 liger，
standard 保留完整 logits 路径用于对照；未实现 PyTorch 过滤有效位置的 chunked CE 后端。

- 全参数 BF16 SFT，ZeRO-3、SDPA、gradient checkpointing。
- 每卡 micro-batch 1，默认梯度累积 2，八卡时全局 batch 16；默认 learning rate 5e-6，
  constant schedule，无 warmup、weight decay 0、max_grad_norm 1。它们只是 pilot 参数，
  正式 SFT 的学习率、轮数、样本混合和选择规则尚未冻结。
- 严格验证 chat template 的 prompt/completion 及 token 边界；只对 completion 计算 loss，
  prompt/padding 为 -100；动态 padding，拒绝截断，不做 packing。
- Liger 只开启 fused_linear_cross_entropy，不替换 RoPE/RMSNorm/SwiGLU 等其他算子。
  训练和 loss-only 验证显式 skip_logits=True，避免验证回到完整 logits 路径。
  保留 Trainer 的 token 计数、梯度累积与分布式归一化路径。
- 独立无 offload 与 optimizer CPU offload 配置；上方用户保存的成功基准 command 使用
  `zero3_shared_optimizer_offload.json`，因此不能把本轮结果当成无 offload 配置也已通过。
- 记录资源、每 rank 步耗时/allocator 峰值、参数采样更新、模板/数据指纹与依赖版本。
- checkpoint 保存 ZeRO 分片，不在 GPU 上聚合完整模型；CPU 导出程序已实现。
- eval 不读取训练集、不调用训练或 optimizer step、不保存 checkpoint；输出 eval_results.json。
- 最近本地测试：27 passed / 1 CUDA test skipped。远程 CUDA 数值测试随后由用户实际执行并通过。

### 共享服务器资源与实际兼容修复

资源假设是“共享 8×A100-SXM4-40GB”，不能假设每卡固定空闲 16GB。
必须显式指定 CUDA_VISIBLE_DEVICES，启动器动态查询所选 GPU 后按卡数启动。
不自动选卡、抢占或终止其他任务；检查只是一时快照，不是资源预留。
改变卡数需要重新考虑分片显存和全局 batch。

服务器快照：双路 EPYC 7742，128 物理核，约 1TiB RAM；当时 available 928GiB。
根目录空间紧张，环境/缓存/输出应放 /raid。八卡通过 NVLink 互联。

实测软件组合：

| 项目 | 用户回传结果 |
|---|---|
| NVIDIA driver | 470.256.02 |
| PyTorch | 2.5.1+cu118 |
| torch CUDA | 11.8 |
| Triton | 3.1.0 |
| liger-kernel | 0.6.4 |
| GPU capability | (8, 0) |
| Triton 原默认 ptxas | Triton 包内 CUDA 12.4 ptxas |

最初 Liger 报 `Triton Error [CUDA]: device kernel image is invalid`。
通过给本进程设置 `TRITON_PTXAS_PATH=/home/chenjiahao/cuda-11.8/bin/ptxas`，
并使用新的独立 TRITON_CACHE_DIR，单卡实际 CUDA 测试通过，随后完整训练基准也通过。
这支持工具链/驱动兼容问题的判断；没有升级共享服务器驱动或重装 PyTorch。
服务器 mas 环境最初缺少 pytest，用户安装后执行了测试。

`test_liger_cuda.py` 用小 Qwen3 比较标准/fused loss 及所有参数梯度，包含两个不同有效标签数的
microbatch 累积，并检查训练和 eval 均不返回 logits。测试在设定数值容差内通过，
不是逐 bit 相同，也不等同于对所有多卡配置完成数值验证。
Pydantic deprecated warning 没有使该测试失败。

### 实际完成的 20 步工程基准

benchmark 取最长的 16 条不同训练样本，重复为 64 条，并右侧 masked padding 到 4096。
八卡全局 batch 16，每 epoch 4 个 optimizer steps；20 步对应该重复数据的 5 epochs。
这不是在全部 610 条训练样本上完成 5 epochs，也不是正式 B-SFT 实验。

用户回传训练日志：

| 指标 | 结果 |
|---|---:|
| 完成 optimizer steps | 20 |
| train_runtime | 1067.4917 秒（约 17 分 47 秒） |
| train_samples_per_second | 0.300 |
| train_steps_per_second | 0.019 |
| train_loss（日志汇总） | 0.1548590959 |
| 开始几步 loss | 1.4853 → 0.7952 → 0.3658 |
| 后期打印 loss | 0.0（显示舍入，不应认定精确为零） |

完整训练没有再次出现已知内核错误或 OOM。训练结束执行了分片 checkpoint 保存路径，
随后验证循环完成。`stage3_gather_16bit_weights_on_model_save=false` 的多 rank 提示是预期行为。
仅凭这些日志不宣称 checkpoint 恢复/CPU 导出/重新加载已经验证。

出现过 allocator cache flush 警告，说明显存压力仍在，可能影响性能；
没有据此添加每步 empty_cache，也没有证据量化 Liger 此次实际节省多少显存。
各 rank 资源日志尚待进一步分析，不能把本轮速度外推为独占八卡性能。

### 原始模型与 20 步模型的验证 loss 对照

用户主动选择跳过恢复两步和导出，先评估原始模型。因此新增 --mode eval，
复用同一验证集、编码和 loss 路径评估原始 Qwen。

| 指标 | 原始 Qwen | 20 步工程基准后 |
|---|---:|---:|
| eval_loss | 1.3312（终端显示精度） | 0.6362407207489014 |
| eval_runtime | 66.96 秒 | 46.24 秒 |
| eval_samples_per_second | 1.687 | 2.444 |
| eval_steps_per_second | 0.224 | 0.324 |

验证集为 113 条，相对 loss 下降约 52.2%。在模板、验证输入和 loss 配置一致的前提下，
这是持出验证序列预测改善的证据，不只是训练 loss 下降。
两个耗时不可直接解释为训练后模型更快：执行阶段、准备路径和共享负载可能不同。

**不能据此宣称 B 集合判断准确率、证据推断能力或跨环境迁移已经提升。**
工具调用格式 token 和语义标签 token 都进入 loss，可能存在格式学习或输出先验学习。
当前还没有两个模型的生成式 B 准确率对照。

### 下一轮对话需要设计的 SFT 与评估

用户希望下一轮具体设计 SFT，不继续把恢复/导出工程检查作为讨论前置。
已实现恢复与导出，但用户尚未执行，不能在后续文档中标成完成。
训练后若需要生成式评估，仍须安排 checkpoint-20 的实际加载方式；不需要先恢复到 22 步。

首要任务：对原始模型和 checkpoint-20 做相同条件下的生成式 B 验证评估。
现有 `benac_p.b_eval` 可评分，两个模型的预测生成与对照报告尚未实现完整流程。

1. 相同 prompt/tools/解码配置，每题首个输出保留原始响应；重试结果不能掩盖首答格式失败。
2. 分开报告格式成功率、集合 exact match、错误排除和额外保留，按金标集合大小和源游戏分组。
   格式失败计入总体失败，并另报有效输出中的语义指标。
3. 使用观测前后配对：要求两个端点都正确；有信息才缩小，无信息应保留，不能只看输出变化。
   本轮共有 987 对核验更新，但选中语料未包含所有端点，配对评估必须检查端点可用性。
4. 做逐题表：ID / 金标 / 原始输出 / 训练后输出 / 错误类型 / 配对 ID。
   审查“错变对、对变错、都错”，按源游戏考虑相关性，不把同源问题全当独立样本。
5. 用一致编号重命名、显示顺序变化检查表面捷径；这不替代未见游戏结构、伙伴策略和环境 transfer。
6. 先用 validation 诊断设计；test 不参与调参，训练设置冻结后再做最终评估。

根据错误结构再决定训练调整：格式与语义 loss 的分项记录、歧义集合配比、
证据更新配对样本、错误排除案例等；不凭总 loss 下降就增加训练轮数。
不要简单奖励大集合，也不要把真实伙伴偏好或 outcome 上涨替代 B 语义监督。
正式 B-SFT 应从原始模型新开运行，不能把此反复拟合 16 条的工程基准当正式训练起点。
后续 B→P 效应需要固定独立 P checkpoint 做判断替换，避免共享模型参数变化混淆归因。

---

## 第一轮：集合答案 SFT + 中途生成式验证（2026-09-09 新增）

本节是新增运行路径。保持现有集合答案监督，不添加概率或 reasoning 目标，不更换伙伴策略。
先用现有 **610 train / 113 validation、四玩家** 数据验证闭环；本次未生成此前讨论的
3/4 玩家约 3,000 条新版语料，也没有用五玩家 OOD/test 调参。
本地测试不代表服务器 ZeRO-3 生成已通过；新生成路径先运行下面的两步验收。

### 上传

在本机仓库根目录运行；远程数据目录沿用先前已存在的目录。除训练入口外，需要额外上传配对索引。
配对索引只用于评分，不进入模型输入。训练、验证 JSONL 继续使用原文件。

```bash
rsync -avzP --exclude='__pycache__/' --exclude='.pytest_cache/' \
  -e "ssh -i $HOME/.ssh/id_rsa_dgx2 -p 2201" \
  training/b_sft/ \
  chenjiahao@36.102.215.18:/raid/chenjiahao/mas/training/b_sft/

rsync -avzP -e "ssh -i $HOME/.ssh/id_rsa_dgx2 -p 2201" \
  new/local_data/b_independent_focal_roles_v1/update_pairs.jsonl \
  chenjiahao@36.102.215.18:/raid/chenjiahao/mas/new/local_data/b_sft_ready_roles_v1/update_pairs.jsonl
```

### 服务器两步验收

沿用已成功运行的 mas 环境、CUDA_VISIBLE_DEVICES、CUDA 11.8 ptxas 与独立 Triton cache 设置。
CUDA_VISIBLE_DEVICES 必须由使用者按当前获准使用的 GPU 显式设置，启动器不会自动挑卡。
以下配置在八卡时全局 batch 为 16。先检查当前资源；这里不重复安装服务器依赖。

```bash
cd /raid/chenjiahao/mas
conda activate /raid/chenjiahao/conda_envs/mas
nvidia-smi

python -m pytest training/b_sft/test_semantic.py training/b_sft/test_trainer_semantic.py -q
# 用一张获准使用的 GPU 运行已有 test_liger_cuda.py；新测试增加了生成后继续 backward。

bash training/b_sft/run_shared.sh \
  --mode train --semantic-eval \
  --model /raid/chenjiahao/mas/models/Qwen3-4B-Instruct-2507 \
  --train-file new/local_data/b_sft_ready_roles_v1/train.jsonl \
  --eval-file new/local_data/b_sft_ready_roles_v1/validation.jsonl \
  --pairs-file new/local_data/b_sft_ready_roles_v1/update_pairs.jsonl \
  --output-dir /raid/chenjiahao/mas/outputs/b_sft_semantic_smoke_v1 \
  --deepspeed training/b_sft/configs/zero3_shared_optimizer_offload.json \
  --loss-backend liger --gradient-accumulation 2 --learning-rate 5e-6 \
  --max-steps 2 --semantic-eval-steps 1 --early-stopping-patience 0 \
  --generation-max-new-tokens 128 --train-probe-size 32

python -m training.b_sft.report /raid/chenjiahao/mas/outputs/b_sft_semantic_smoke_v1
```

验收看 step 0/1/2 均有 validation 的 metrics、questions、pairs 和首答 predictions；
step 2 checkpoint 内有 `semantic_selection.json`；生成后可以继续训练，不发生 OOM/多卡卡死。
原始模型格式或语义失败属于测量结果，不要求两步后准确率达到某个值。
生成阶段仍需要所有 rank 工作。推理一次只保留最后位置的 logits、使用 KV cache，
不在 GPU 合并完整权重，不把每个输入位置的词表 logits 都物化。

### 正式 pilot：从原始模型新开目录

两步验收完成后运行。使用全部 610 条，最多两轮；八卡全局 batch 16 时一轮约 39 步，
默认每约四分之一轮即 **10 步** 验证一次，最后一步也验证。原始模型 step 0 自动评估。

```bash
bash training/b_sft/run_shared.sh \
  --mode train --semantic-eval --epochs 2 \
  --model /raid/chenjiahao/mas/models/Qwen3-4B-Instruct-2507 \
  --train-file new/local_data/b_sft_ready_roles_v1/train.jsonl \
  --eval-file new/local_data/b_sft_ready_roles_v1/validation.jsonl \
  --pairs-file new/local_data/b_sft_ready_roles_v1/update_pairs.jsonl \
  --output-dir /raid/chenjiahao/mas/outputs/b_sft_pilot_lr5e6_v1 \
  --deepspeed training/b_sft/configs/zero3_shared_optimizer_offload.json \
  --loss-backend liger --gradient-accumulation 2 --learning-rate 5e-6 \
  --eval-every-fraction 0.25 --early-stopping-patience 3 \
  --generation-max-new-tokens 128 --train-probe-size 32

python -m training.b_sft.report /raid/chenjiahao/mas/outputs/b_sft_pilot_lr5e6_v1
```

第二组只改 `--learning-rate 2e-6` 和一个新的 output-dir，从同一原始模型重新开始。
保持数据、seed、batch、解码一致。现在不同时搜索更多超参数。
生成 prompt 加 max-new-tokens 必须不超过 max-length；超限直接拒绝，绝不截断历史。

### 选择与停止

- 选择指标：validation 按源游戏平均的集合 exact match。格式/截断/缺失计整体失败。
- 原始模型也是候选；只有严格提升才替换，同分保留更早的点。
- 连续三次验证不提升则停止，`--early-stopping-patience 0` 可关闭停止。
- 每个评估后的训练 step 都保存 checkpoint；原有 `--save-steps` 还可额外保存恢复点。
- 利用 Trainer 的 best checkpoint 保护，最多保留两份（最佳和最新；无改进时保留最近两份）。
  `selection.json` 指向最终选中的模型；未超过原始模型时直接指向原始模型目录。
- 不在训练结束自动加载最佳权重；训练末尾的 eval_results.json 对应最后权重。
  各步语义结果与 loss 在该步的报告中。导出/后续推理必须使用 selection.json 的路径。
- 每份 checkpoint 有 early-stopping 状态。恢复读取该 checkpoint 的状态和原始模型首答，
  检查数据、模板、配对文件、解码、间隔、patience 等配置指纹；已 early-stop 的运行不能继续。
  被选择的最佳 checkpoint 必须仍在。恢复时保留原目录布局，且只允许从最新完整 checkpoint
  恢复，避免在同一个报告目录中分叉训练历史。

当前 validation 只有两个源游戏，选择曲线只用于 pilot，不能据此声称稳健泛化。
现有 validation 共有 76 对完整配对：40 maintain / 36 update。未进入最终语料的端点
会计为 unavailable；不补造答案。train probe 固定按源轮转选取，不按模型错误挑选，
只作拟合诊断，不参与停止或选择，可能不覆盖全部配对。

### Debug 产物

```text
selection.json                         选中的模型 / 分数 / patience 状态
semantic_curve.jsonl                   各步验证与训练 probe 指标、loss、epoch、耗时
semantic_report.md                     report 命令生成的可读学习曲线
validation_generation_prompts.jsonl    实际渲染的 prompt 与 token IDs，无金标
train_probe_generation_prompts.jsonl   固定训练诊断题输入
semantic/step-000000/validation/        原始模型首答
semantic/step-000010/validation/
    metrics.json                       格式、集合、按游戏/集合大小、形成与配对指标
    predictions.jsonl                  原始首答、生成 token IDs、截断标记、解析答案
    questions.jsonl / questions.csv    金标/预测/原始模型预测/错变对或对变错/排除与保留
    pairs.jsonl / pairs.csv            新事件、前后金标/预测、maintain/update、两端正确性
semantic/step-000010/train_probe/       同格式的训练诊断结果
checkpoint-10/semantic_selection.json  可恢复的选择状态
```

配对正确率使用全部可用配对为分母，同时另报两端合法输出中的正确率。
维持要求两端都正确，不奖励“一直输出同一个错误集合”。概率不在输出与评分中。
模型输入保持现有模板：它允许简短文字后工具调用；解析器接受此前缀并保留原始文本，
不把它当作 reasoning 监督。单次输出必须只有一个合法 SUBMIT_JUDGMENT 调用，
不修复 JSON、不重试、不用重试覆盖首答失败。解码固定 greedy、单 beam、最多 128 新 tokens。
前后报告中的金标、计数与配对元数据不进入生成 prompt。

只评估原始或已 CPU 导出的 HF 模型，也可用 `--mode eval --semantic-eval --pairs-file ...`。
不读训练集、不 early-stop、不保存 checkpoint。不要将未合并的 ZeRO checkpoint 当 HF 模型加载。
最终 test 不用于调参；本入口的 eval-file 仍应是 validation。

### 验证范围与实现参考

本地基础测试覆盖解析失败、gold 隔离、跨 rank 等轮次、集合/配对指标、基线比较、
选择同分规则、patience 恢复、RNG/模型状态恢复。另有真实 HF Trainer 小模型测试，
验证 early-stop 和最佳 checkpoint 不被清理；缺少 Transformers/Accelerate 时跳过。
CUDA 测试验证 Liger 生成后还能进行 fused loss/backward；本机无 CUDA 时跳过。
这两类测试都不能替代共享服务器上的真实 ZeRO-3 两步验收。

实现按 [Transformers 4.57.3 Trainer](https://github.com/huggingface/transformers/blob/v4.57.3/src/transformers/trainer.py)
的保存/rotation 机制与 [Liger 0.6.4 Qwen3 forward](https://github.com/linkedin/Liger-Kernel/blob/v0.6.4/src/liger_kernel/transformers/model/qwen3.py)
的 `logits_to_keep=1, skip_logits=False` 生成路径核对。

本次本地结果：在 `/tmp` 隔离依赖环境使用 Transformers 4.57.3 / Accelerate 1.10.1，
设置 `USE_TF=0` 后全目录测试 **39 passed / 1 CUDA skipped**。真实 CPU 小 Qwen3 验证了
Trainer 的保存/最佳点保护/提前停止，以及 last-position logits 生成后继续 backward。
723 条现有 train/validation 样本通过官方模板输入隔离、金标解析与生成预算检查，
最长 prompt 3,359 tokens，加 128 tokens 不超过 4,096。服务器环境未修改，尚未运行新路径的
ZeRO-3 两步验收，不把这些 CPU 检查标成多卡 CUDA 已验证。
