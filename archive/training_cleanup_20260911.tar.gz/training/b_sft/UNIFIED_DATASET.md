# 第一版统一开发数据集

入口：[完整数据报告](../../new/local_data/social_dataset_development_v1/REPORT.md)、[逐项样本与完整参考轨迹](../../new/local_data/social_dataset_development_v1/EXAMPLES.md)。组装代码：[assemble_dataset.py](assemble_dataset.py)。

## 这次做了什么

把原来的单偏好 B/P 语料、必要行动切换见证、多偏好 favored 见证放入同一个 schema。不是拼接旧答案：对每个合法历史重新重放，重新生成全量隐藏查询的 set/favored，并把 P 标签统一为原生动作和参考终局 Q。

- 22 个精确物理结构，30 个角色/自身偏好/候选目录场景。
- 111 个决策记录，其中 37 个是终局诊断，不作为在线 B/P 调用；其余 74 个均有参考 P 标签。
- 76 条真实历史延伸链接、2 条跨历史对照链接。连续链接按查询计 46 maintain、30 update；对照不冒充时间更新。
- 18 条参考教师 episode 全部到达真实终局。每个 train/development 根起点只采一条 seed=0 轨迹，不穷尽所有隐藏 world；它们不是 LM on-policy rollout。
- 108 个记录仅有一个隐藏查询，3 个有两个查询。没有已组装的多伙伴同时隐藏偏好样本组。
- 本次无重放排除项。教师计算失败的接口仍保留显式 unavailable/mask，不补假标签。

所有现有结构都保留作审查库存；没有按“6–8 个核心结构”自动筛掉普通对照。数据规模包含终局诊断与开发见证，不能把 111 当作可直接喂给旧 SFT 的训练行数。

## 文件契约

`games.jsonl` 定义场景：结构、ego、自身偏好、公开候选目录和 split。`decisions.jsonl` 给出该场景的可见历史与输入；固定查询范围，P 运行时从模型 B 接收判断，静态输入不填 oracle B。

`gold.jsonl` 独立保存教师 B 与 P。B 有 player/goal、set/favored、教师内部计数；P 有每个原生动作的 Q、全部最优动作和 available 标志。终局节点另有真实效用，P 不可用。

`links.jsonl` 明确区分 temporal/contrast。`episodes.jsonl` 的 `policy=reference_teacher_not_LM` 标明示范来源；其中 B 由参考教师输出，不能拿来冒充“模型 B 驱动 P”的实测结果。训练时的模型轨迹、终局 outcome、旧 value 与 advantage 仍需在线收集。

`summary.json` 给出覆盖、缺口与源文件摘要；`checksums.json` 验证内容；`READY.json` 仅表示组装和校验完成，`training_ready=false`。当前没有 tokenizer 编码、训练 masks、LM log-prob、PPO advantage 或可直接启动的训练入口。

## 划分保留

| split | 结构数 | 决策记录数 |
|---|---:|---:|
| development | 11 | 52 |
| train | 3 | 15 |
| validation | 2 | 10 |
| test | 2 | 15 |
| ood_test | 4 | 19 |

新的两个见证共享一个物理结构，始终放 development。旧 train/validation/test/OOD 原样保留，不把看过的测试局移入训练。它们规模很小且已接受过开发检查，不能当作全新的盲测结果。按精确结构哈希检查泄露，尚不识别重命名同构。

## 仍缺什么

有些是正式开训门槛，有些是后续研究问题：

- 数据覆盖：自身目标反事实、信息获取正净价值、多伙伴隐藏偏好、linear goals。
- 假设范围：目前为固定有限候选、固定 RationalPartner，尚无未见策略泛化验证。
- 待检验效用：favored 的独立规划增益未建立，不能据此宣称该字段必然有效。
- 评估设计：需建立足量独立、未参与挑样的新验证/测试结构。
- 训练接口：新格式不能使用旧 B-only run_shared.sh；还需 LM/PPO 适配。

现在可以先看 EXAMPLES.md，逐局确认输入、答案及动作价值，再决定补什么；不必继续盲目扩大随机游戏数。

## 复现

在仓库根目录执行，输出目录必须不存在：

```bash
python -m training.b_sft.assemble_dataset \
  --corpus new/local_data/bp_decision_corpus_v1_development \
           new/local_data/bp_decision_corpus_v1_candidates \
  --witness training/b_sft/fixtures/evidence_switch_regression.json \
            training/b_sft/fixtures/favored_belief_regression.json \
  --max-nodes 3000 \
  --output-dir new/local_data/MY_UNIFIED_DEVELOPMENT

python -m unittest training.b_sft.test_assemble_dataset \
  training.b_sft.test_social_rollout training.b_sft.test_favored_belief \
  training.b_sft.test_evidence_switch training.b_sft.test_structure_audit \
  training.b_sft.test_decision_corpus
```

相关 33 项测试通过，并用最终验证器检查整个 111 节点数据包。验证包括固定全量查询、教师输入隔离、原生动作与最优标签一致、时间链接合法性、分区隔离和真实终局轨迹。当前脚本尚无自动断点恢复。
