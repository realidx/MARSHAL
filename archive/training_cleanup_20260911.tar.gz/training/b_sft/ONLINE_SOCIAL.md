# 在线动作与独立结构检查

最新补充与真实 LM 测试命令见 [SOCIAL_LM_EVAL.md](SOCIAL_LM_EVAL.md)：`social_generalization_v2` 有 9 个独立结构、90 点、38 个有信息 B 点。以下 3 结构 / 20 点数字是保留的 v1 审查记录。LM 客户端与详细日志已实现，真实 LM 和 PPO 运行尚未进行。

2026-09-10。第 1–2 项实现完成：这是环境与评分适配器、开发泛化数据，尚未接入真实 LM 或 PPO 更新。

## 1. 偏离教师动作后如何继续

入口：[online_social.py](online_social.py)。

- `step(..., kind='learner')` 只检查原生合法性。合法动作即使不是教师选择，也照常执行；不根据该动作排除伙伴类型。
- 每个 learner 动作之后，从真实新状态和现有候选世界重建共同伙伴窗口。伙伴行为及后续 B 都由这个新窗口产生，不沿用旧分支的标签。
- 伙伴仍按同一有限信息集机制行动，自身收益优先，自身同分时帮助其他人。实际世界只用于环境选取当前伙伴自己的私有偏好，以及计算真实终局收益。
- B 由实际伙伴证据更新；无区分力的行为维持判断。因原生同分排序而形成的脆弱证据，关闭 B 局部评分。
- 合法伙伴动作若在声明策略下没有任何兼容类型，不拒绝环境动作，也不重置先验假装得到了新后验；将后验和局部监督标为不可用。
- 教师超预算时，不伪造标签。为了诊断流程能走完，使用固定 PASS/REJECT 到终局，整条轨迹 `usable_for_training=false`。这不是正式伙伴策略，也不进入训练。

**旧标签不能直接用于新协议。**新版本为 `online-social-interventions-v1`。旧静态标签的未来假设与“LM 每次行动后重建窗口”不同；在线评分一律重新计算。
构造的公开固定前缀用 `prefix` 传入。已观察的在线历史用带 actor/kind 的 `replay_events(..., protocol=VERSION)` 重放；旧 `raw.history` 或旧协议直接报错，避免把有信息的历史误当成无信息的场景设置。

### B、P 和 outcome 分开记录

`score_b` 只评分模型自行选择的合法隐藏偏好维度，重复项、格式错误与未选择项目分别处理。模型选择的目标是否有用没有唯一 gold target。

`run_episode` 将模型 B **原样传给 P**。即使 B 错误或格式不合要求，也不会用教师答案替换。

`p_reference_values` 可选地将每个当前合法动作放入新在线协议，随后使用参考 learner 与相同伙伴机制玩到终局，并对当前可能世界求期望。它给出的局部量是相对最佳参考动作的 regret，**不是当前 LM 的 on-policy advantage**。
任何分支计算失败或超出预算，整组动作排名留空，不把算完的一部分冒充全部比较。计算有 rollout 数量和时间预算；单个正在进行的求解还受其自身秒数上限约束。

最终 outcome 永远来自实际走到终局后的原生效用，和参考未来分开保存。

```python
result = run_episode(
    raw, public_setup_prefix, environment_world,
    b_callback, p_callback,
    score_p=True, turns=2, max_nodes=10000, seconds=5,
)
# callbacks 只收到可见上下文；p_callback 的上下文含实际 model_beliefs。
# 学习器应排除 usable_for_training=False 的诊断轨迹，遵守 B/P mask。
```

### 验证

[在线审计结果](../../new/local_data/online_social_audit_v1/summary.json)：在信息合作例子中，测试全部 7 个合法首步、两个私有世界，共 14 条完整后续；另用始终选首/末合法动作的脚本和故意错误的 B 跑了 4 条完整轨迹，核对 B 不被修复、learner 动作不筛除世界，以及终局收益。
另外测试非法动作原子性、版本化重放、教师超预算、合法但不相容的伙伴动作和 P 评分预算。相关 30 项单元测试通过。

## 2. 独立结构泛化检查集

入口：[social_holdout.py](social_holdout.py)。数据位于 `new/local_data/social_generalization_v1/`，与 83 点开发训练材料物理分开。

| 结构 | 玩家 | 每人 commitment | goal | 隐藏方式 |
|---|---:|---:|---:|---|
| heldout-three | 3 | 2 | 5 | 单项 |
| heldout-four-small | 4 | 1 | 5 | 两个伙伴 |
| heldout-four | 4 | 2 | 6 | 同一伙伴两项 |

固定三个起点：无 commitment、一个 commitment、两个 commitment。设置动作公开且独立于私有类型；后续 learner 首步按预先固定的合法动作索引覆盖，不按教师价值挑选。
种子和最终生成规则在算标签前写入 `frozen_recipes.json`；没有根据 LM 得分重选游戏，平局和无区分力的情况也保留。

去重忽略 seed、偏好、轮次顺序、menu 变化，并穷举玩家/动作重命名、忽略 goal 编号。三个目标结构互不相同，也与现有八组材料的目标结构不重合；仅换名字或时限不能通过这个检查。

当前有 **20 个去重决策点、11 对前后判断（7 maintain / 4 update）**。252 条全世界/分支轨迹是验证覆盖量，不能当成 252 个独立测试样本。
独立审计直接重放原生状态，按完整公共历史匹配世界，核对了 20 个 B 快照和 47 个已采样参考 P 值。

### 如何解释之后的模型结果

- 在同一组输入、同一解码设置上比较 base 和训练后模型。
- 按结构汇总，再分别报告有信息的 B、maintain/update、有效 P 比较与真实终局收益；不要只看所有问题的平均正确率。
- B 是自由选目标，必须同时报告选了哪些目标、覆盖多少，以及是否选择了具有区分力的目标；只选简单项的高正确率不能算学会 B。
- 当前仅 **4 个决策点含非全可能集合的 B**，且来自一个结构。因此能发现明显失败，不能据此证明广泛的 B 更新迁移。其他点用于形成/维持与 P 检查，不用重复它们充大样本数。
- 这是 development generalization，不是最后的独立论文测试集。不得混入训练；后续若据此调整设计，最终结论还需要新测试集。

文件：`questions.jsonl` 含教师侧标签；`B_inputs.jsonl` / `P_contexts.jsonl` 不含标签；`pairs.jsonl` 为前后配对；`trajectories.jsonl` 保留验证轨迹；`summary.json` 和 `checksums.json` 为审计与完整性信息。

## 复现

```bash
python -m unittest training.b_sft.test_online_social \
  training.b_sft.test_social_cases_expand training.b_sft.test_social_cases \
  training.b_sft.test_shared_teacher

python -m training.b_sft.online_social_audit \
  --output-dir new/local_data/online_social_audit_v2

python -m training.b_sft.social_holdout \
  --training-pack new/local_data/social_cases_v2 \
  --output-dir new/local_data/social_generalization_v2
```

输出目录必须新建。下一步先用真实 LM 做固定点及完整续局审查，再接训练更新；长程伙伴响应验证仍单独待办。
