# 第一轮正式实验：v2 数据与训练入口

本页取代旧 README 中“用 610 条旧数据跑 pilot”的下一步建议。
不改正在运行的服务器测试，不从该测试的权重接着训练。以下命令由用户在当前测试结束后执行。
正式训练、数据批量生成、最终测试都是独立操作；本次代码开发不启动服务器训练。

## 时间优先的训练配置（当前推荐）

SSH 断线恢复：训练应在新建的 `tmux new -s b_sft_round1` 会话内启动，重新设置 conda、
CUDA_VISIBLE_DEVICES 和 CUDA/Triton 环境。用 Ctrl-B 再 D 离开，重连后 `tmux attach -t b_sft_round1`。
不要进入或关闭其他任务的 tmux 会话。

若断线前只有 step-0 基线、没有完整 checkpoint，可从原始权重重新训练并复用基线：
原命令改为全新的 output-dir，并增加 `--reuse-baseline-run /绝对路径/旧运行目录`。
要求 --skip-eval-loss、--train-probe-size 0、不传 --resume，保持原始模型、数据、验证子集及
generation-max-new-tokens 与旧运行一致。入口核对模型路径、数据哈希、题 ID、prompt 哈希和
强制贪心解码设置；通过后重新写入基线报告并直接训练，不再生成 step-0 答案。
这是复用评估结果，不是恢复未保存的梯度或 optimizer 状态；不要把未保存的训练步计入新运行。
如果已有完整 checkpoint，应先考虑原配置 --resume，而非丢弃权重从头训练。

8 步日志复盘：训练 loss 的快速下降不能替代生成式准确率，完整工具调用中的固定格式 token
也受到监督。157 题固定子集上的“始终输出三个可能值”对照得到 exact=73/157、
maintain=26/43、update=0/37，与用户回传的 step-0 汇总一致。新增 shortcut_diagnostics
直接显示输出集合分布、固定全集合对照，以及 gold 集合小于 3 的题目准确率，无需额外 GPU 推理。
先不据此改变训练标签分布或学习率。为降低断线损失，可将 --save-steps 改为 25，
保持语义评估间隔 100；保存本身有额外 I/O 成本，不会触发额外语义评估。

完整验证集 loss 不参与模型选择，不必每次计算。当前使用以下训练参数覆盖后文旧的完整评估配置：

```text
--skip-eval-loss
--validation-pairs-per-source 2
--train-probe-size 0
--eval-every-fraction 0.5
--generation-max-new-tokens 64
--checkpoint-policy best-and-periodic
--save-steps 100
```

不要同时保留旧的 --semantic-eval-steps，否则它仍优先控制间隔。
当前 40 个验证源固定选出 157 条问题，保留所选配对两端，所有源均覆盖；选取只依赖题 ID，
不看答案或模型表现。它用于开发期模型选择，不能当作完整验证集得分。完整 test/OOD 留到最终评估。
初始基线和每次语义评估均跳过 loss，训练结束也跳过重复 loss；训练 loss 照常记录。
8 卡下每次生成约 20 个 batch，取代原来的 160 个 loss batch 和 160 个验证生成 batch。
原始模型基线仍保留，避免把退化的 checkpoint 选为最佳。64-token 耗尽仍记为截断错误。

生成已强制 `use_model_defaults=False` 和调用参数 `do_sample=False`，防止 Transformers 4.57
把 Qwen 自带的采样配置覆盖回来。旧版本输出可能实际使用采样，即使旧报告写了 do_sample=false，
也不能作为新的贪心对照；新版本拒绝这类旧 baseline 和旧语义训练配置的 resume。
这次请新开 output-dir。生成日志输出批次进度；ZeRO trace cache invalidation 本身不代表训练步数或死锁。

本次本地测试 47 passed、2 个 CUDA 测试 skipped，包括模型自带采样默认值时仍强制贪心、
无验证 loss 的真实 Trainer early stopping/checkpoint 行为、以及配对抽样和最终 loss 跳过。
尚未用服务器真实多卡验证本次性能或 trace 切换。

## 本版实现

- train / validation / test 只含 3、4 玩家，ood_test 只含 5 玩家；按源和结构分组隔离。
- 每种玩家数均覆盖每人 2/3 commitments，binary、linear、mixed goals。
- 线性 goal 按已绑定 commitment 的比例计分；MCTS 内部用共同分母的整数收益表，避免截掉分数。
- 保留原来的有限公开偏好先验：6 个背景 × 两个独立查询 goal 的三值，共 54 个配置/玩家。
  没有改成完整逐 goal 独立先验，没有新增随机伙伴、二阶 ToM、概率或 reasoning 标签。
- 用原来的固定 1024-simulation MCTS 产生行为。选中的问题从 LM 可见字段重新构造 oracle、重放历史，
  核验时不读取伙伴真实偏好或存储的支持集证书。
- 较大的隐藏空间不再分配完整联合世界数组，按既有策略的因子化性质筛选。显式联合枚举只在小空间额外核验；
  报告会区分两者，不把因子化核验伪称为五玩家联合空间已显式枚举。
- 筛选单位是完整前后问题组，并保留初始形成题；维持和更新组交替选取，不拆端点。
- 结构分组使用无标签图的保守 refinement 指纹，忽略 goal 的 binary/linear 标志。
  同构图一定同组，少数非同构图也可能同组并被拒绝；不声称它是精确图同构算法。

默认规模与结构：

| Split | 源游戏数 | 玩家数 | 每人 commitments | goals | 每源问题上限 |
|---|---:|---|---|---|---:|
| train | 100 | 3 / 4 | 2 / 3 | 3 人 9/12；4 人 12/16 | 32 |
| validation | 40 | 3 / 4 | 2 / 3 | 同上 | 32 |
| test | 40 | 3 / 4 | 2 / 3 | 同上 | 32 |
| ood_test | 40 | 5 | 2 / 3 | 15 / 20 | 32 |

训练上限约 3,200 条，不为凑数复制样本。五玩家 OOD 同时增加 goals 和总历史长度，
应解释为规模迁移，不能仅归因于玩家数。每个配置按源轮换 learner 角色。
新数据 system 明确要求只输出工具调用；训练目标仍只有 possible_preferences 集合。

## 上传代码

在本机仓库根目录执行。数据生成需要 benac_p 源码，因此本版不再仅上传 training 目录。
命令不包含删除远程文件或安装依赖。

```bash
cd /Users/bruce/MARSHAL

ssh -i "$HOME/.ssh/id_rsa_dgx2" -p 2201 chenjiahao@36.102.215.18 \
  'mkdir -p /raid/chenjiahao/mas/training/b_sft /raid/chenjiahao/mas/third_party/negotiation_benchmark/src'

rsync -avzP --exclude='__pycache__/' --exclude='.pytest_cache/' \
  -e "ssh -i $HOME/.ssh/id_rsa_dgx2 -p 2201" \
  training/b_sft/ \
  chenjiahao@36.102.215.18:/raid/chenjiahao/mas/training/b_sft/

rsync -avzP --exclude='__pycache__/' \
  -e "ssh -i $HOME/.ssh/id_rsa_dgx2 -p 2201" \
  third_party/negotiation_benchmark/src/ \
  chenjiahao@36.102.215.18:/raid/chenjiahao/mas/third_party/negotiation_benchmark/src/
```

## 生成并核验正式数据

服务器上使用既有环境；生成器只使用 CPU，tokenizer 使用本地模型文件。
所需 NumPy、Jinja2、tokenizers 通常已在当前模型环境中；脚本不会自动安装依赖。

```bash
cd /raid/chenjiahao/mas
conda activate /raid/chenjiahao/conda_envs/mas

PYTHONPATH=third_party/negotiation_benchmark/src \
python -m benac_p.b_corpus \
  --output-dir new/local_data/b_corpus_n345_v2 \
  --tokenizer-dir /raid/chenjiahao/mas/models/Qwen3-4B-Instruct-2507 \
  --train-games 100 --validation-games 40 --test-games 40 --ood-games 40 \
  --samples-per-game 32 --backgrounds 6 --simulations 1024 \
  --max-length 8192 --generation-max-new-tokens 128
```

中断后，用完全相同的命令添加 `--resume`。每个源完成后都会写校验标记；恢复不重新生成已完成源。
配置、源码或 tokenizer 改变时拒绝混用旧生成进度。生成完成的目录不可覆盖。

CPU 并行：增加 `--workers 4`，每个进程负责一局生成及独立重放。本机先使用 4 个进程，
服务器按可用 CPU 和内存设置；每个进程持有独立搜索缓存。主进程先按固定顺序预留结构，
所以并行不改变 seed、划分和导出顺序。每局结束打印 SOURCE_DONE 耗时及 PROGRESS。

从上一版串行任务升级时，先 Ctrl-C 并等待旧进程退出，再用原命令加 `--resume --workers 4`。
本次仅允许已知上一版调度器源码哈希迁移，其他源码、配置和 tokenizer 仍严格检查。
已写 complete.json 的游戏直接复用；中断中的游戏重新生成。不能让两个生成命令同时写同一目录。
更改 workers 不影响 resume；更改各 split 游戏数量仍不允许直接 resume。

并行验收：4 局小预算真实生成中，串行与两进程导出的所有 JSONL 文件逐字节一致。
这是调度正确性检查，没有降低正式生成命令的搜索预算。

数据可用的标志是 `READY.json`；训练入口对 v2 数据检查 READY、校验清单和实际输入文件哈希。
源码/game 记录、原始问题、独立核验结果留在 sources/ 供审计。训练不读取这些内部文件。
完整导出包含：

```text
train.jsonl / validation.jsonl / test.jsonl / ood_test.jsonl
各 split 的 *_prompts.jsonl / *_gold.jsonl / *_pairs.jsonl
update_pairs.jsonl
summary.json / token_lengths.json / manifest.json / checksums.json / READY.json
sources/source-NNNN/{bundle.json,all_questions.jsonl,complete.json}
```

超出训练或生成 token 预算会使最终导出失败，写出 overlength.json，不截断历史、不悄悄删掉难题。
每源端点完整，不保证七类答案或形成/维持/更新恰好等量；实际数量看 summary.json。

也可以在本机生成，再将整个输出目录上传。此时 tokenizer-dir 指向本机官方 tokenizer，
可沿用之前的 `/tmp/benac-qwen-tokenizer`；需要的临时 Python 依赖路径也按本机现有配置设置。
本机已验证的解释器是 `/opt/anaconda3/bin/python`（Python 3.12.2）。不要直接使用
可能指向旧环境的 `python`；本项目的运行时联合类型别名要求 Python 3.10 或更新版本。

```bash
cd /Users/bruce/MARSHAL
PYTHONPATH=/tmp/benac-audit-tokenizer:third_party/negotiation_benchmark/src \
/opt/anaconda3/bin/python -m benac_p.b_corpus \
  --output-dir new/local_data/b_corpus_n345_v2_local \
  --tokenizer-dir /tmp/benac-qwen-tokenizer \
  --train-games 100 --validation-games 40 --test-games 40 --ood-games 40 \
  --samples-per-game 32 --backgrounds 6 --simulations 1024 \
  --max-length 8192 --generation-max-new-tokens 128
```

本机生成后的上传命令：

```bash
rsync -avzP -e "ssh -i $HOME/.ssh/id_rsa_dgx2 -p 2201" \
  new/local_data/b_corpus_n345_v2_local/ \
  chenjiahao@36.102.215.18:/raid/chenjiahao/mas/new/local_data/b_corpus_n345_v2/
```

## 正式训练命令

### 不等 OOD 生成完即可训练

当 train、validation、test 的所有计划游戏均完成时，可冻结三个划分，原生成任务继续写 OOD。
独立导出会核验源文件哈希、tokenizer 和长度，再写自己的 READY；不会修改原生成目录。

```bash
PYTHONPATH=/tmp/benac-audit-tokenizer:third_party/negotiation_benchmark/src \
/opt/anaconda3/bin/python -m benac_p.b_corpus_snapshot \
  --source-dir new/local_data/b_corpus_n345_v2_local \
  --output-dir new/local_data/b_corpus_n345_v2_train_ready

rsync -avzP -e "ssh -p 2201 -i $HOME/.ssh/id_rsa_dgx2" \
  new/local_data/b_corpus_n345_v2_train_ready/ \
  chenjiahao@36.102.215.18:/raid/chenjiahao/mas/new/local_data/b_corpus_n345_v2_train_ready/
```

已有该快照时直接上传，不重复导出到同一目录。下面训练命令的 train-file、eval-file、pairs-file
均改用 `new/local_data/b_corpus_n345_v2_train_ready/`，其余配置不变。快照不包含 OOD 文件；
OOD 完成后仍从原完整目录评估，不将后续生成结果写入训练快照。
本地生成与服务器训练可同时进行。若暂停生成，Ctrl-C 等待退出后用原生成命令加 --resume 续跑。

先确认 READY 已生成，并保留当前服务器测试通过的 CUDA_VISIBLE_DEVICES、TRITON_PTXAS_PATH、
TRITON_CACHE_DIR 设置。下例八卡时全局 batch 16，不自动选择或占用 GPU。

```bash
bash training/b_sft/run_shared.sh \
  --mode train --semantic-eval --epochs 2 \
  --model /raid/chenjiahao/mas/models/Qwen3-4B-Instruct-2507 \
  --train-file new/local_data/b_corpus_n345_v2_train_ready/train.jsonl \
  --eval-file new/local_data/b_corpus_n345_v2_train_ready/validation.jsonl \
  --pairs-file new/local_data/b_corpus_n345_v2_train_ready/validation_pairs.jsonl \
  --output-dir /raid/chenjiahao/mas/outputs/b_sft_round1_restart \
  --reuse-baseline-run /raid/chenjiahao/mas/outputs/b_sft_round1_lr5e6_v2 \
  --deepspeed training/b_sft/configs/zero3_shared_optimizer_offload.json \
  --loss-backend liger --max-length 8192 \
  --gradient-accumulation 2 --learning-rate 5e-6 \
  --skip-eval-loss \
  --validation-pairs-per-source 2 \
  --eval-every-fraction 0.5 --early-stopping-patience 3 \
  --checkpoint-policy best-and-periodic --save-steps 100 --keep-checkpoints 2 \
  --generation-max-new-tokens 64 --train-probe-size 0

python -m training.b_sft.report /raid/chenjiahao/mas/outputs/b_sft_round1_lr5e6_v2
```

max-length 是上限，不会把所有 train 样本 padding 到 8192；动态 padding 沿用旧实现。
但新数据更长，旧的 4K 工程验收不能证明实际较长输入一定放得下共享 GPU。
第二学习率组仅改成 2e-6 和新 output-dir，仍从原始模型起跑，不使用第一组的权重续训。

## 评估与保存间隔

- `--semantic-eval-steps N`：每 N optimizer steps 评估，优先于 epoch fraction。
- `--eval-every-fraction 0.25`：每约四分之一轮评估。原始模型和最后一步也评估。
- `--save-steps N`：常规恢复点保存间隔。
- `--checkpoint-policy best-and-periodic`：仅常规间隔、新的最佳点、最后一步、early-stop 时保存。
  因此每 10 步评估、每 50 步常规保存，不会在每个未提升的评估点强制保存。
  新最佳点仍额外保存，这是保留真正最佳权重所必需的，不承诺“严格只在 50 的倍数保存”。
- `--checkpoint-policy all-evals`：保持之前测试入口的每个评估点都保存；默认仍是此值，避免旧命令改变行为。
- `--keep-checkpoints`：至少 2；保留最佳和最新，较大的值允许额外留恢复点。

resume 会核对保存策略；新配置应新开实验，不接着旧 smoke/pilot checkpoint 改设置。

## 导出被选中的模型

```bash
python -m training.b_sft.export \
  --selection-file /raid/chenjiahao/mas/outputs/b_sft_round1_lr5e6_v2/selection.json \
  --output-dir /raid/chenjiahao/mas/outputs/b_sft_round1_lr5e6_v2/export_selected
```

若选中了原始模型，命令明确打印 `export_required=false`，不复制原始权重，后续继续用原模型路径。
否则 CPU 合并选中的 ZeRO checkpoint，输出普通 HF 权重。实际导出和生成加载仍需在服务器执行；
本地代码测试没有替代真实 4B checkpoint 合并验收。

## 设置冻结后的 test / OOD 评估

新增 `--eval-split test` 或 `--eval-split ood_test`，**只能**用于 `--mode eval --semantic-eval`。
训练模式不能把它们用于选择模型或 early stopping。评估用原始模型或已 CPU 导出的 HF 模型，
不读训练集、不更新参数、不保存 checkpoint。

以下是原始模型的 OOD 首答基线：

```bash
bash training/b_sft/run_shared.sh \
  --mode eval --semantic-eval --eval-split ood_test \
  --model /raid/chenjiahao/mas/models/Qwen3-4B-Instruct-2507 \
  --eval-file new/local_data/b_corpus_n345_v2/ood_test.jsonl \
  --pairs-file new/local_data/b_corpus_n345_v2/ood_test_pairs.jsonl \
  --output-dir /raid/chenjiahao/mas/outputs/b_sft_final_original_ood_v2 \
  --loss-backend liger --max-length 8192 --generation-max-new-tokens 128
```

然后对选中且已导出的模型运行相同命令，修改 model/output-dir，并增加：

```bash
--baseline-predictions /raid/chenjiahao/mas/outputs/b_sft_final_original_ood_v2/semantic/step-000000/ood_test/predictions.jsonl
```

这样逐题报告直接显示原始/训练后输出和错变对、对变错。比较前会核对题 ID、实际 prompt
（包括 system/tools）哈希和解码设置，拒绝把不同提示下的结果当成同条件对照。
同分布 test 将上述 ood_test 改为 test，换独立 output-dir；不要覆盖 OOD 结果。
如果选中了原始模型，无需再对同一权重做第二遍测试。

报告新增按玩家数和 goal 类型分组；维持和更新配对仍要求两端正确。

## 实现边界

本版实现的是数据生成、B 标签、训练/选择及生成式评分链。既有专门为 binary 场景编写的
其他 Diagnose/P planner 实验尚未整体扩展为线性环境；不能仅凭本次 B 支持就宣称 B→P 或迁移有效。
固定有限先验、伙伴策略和答案格式的研究边界不因增加玩家/goal 类型而消失。

## 本地验证记录

### Liger / ZeRO-3 的输出层除零修复

若堆栈在 `fused_linear_cross_entropy_forward` 的 `cdiv(BT, inc_factor)` 除零，
对应 Liger 0.6.4 中 `V = weight.shape[0]` 为 0；ZeRO-3 的未聚合权重可能是这样的空占位张量。
融合 loss 直接读取 `lm_head.weight`，没有调用输出层模块的 forward。
入口现已在 Liger patch 后、DeepSpeed engine 初始化前显式注册该 external parameter，
让 ZeRO 管理 enclosing model forward/backward 中的权重生命周期。
运行 manifest 的 `loss_patch.zero3_external_head.registered` 应为 true。

仅同步本次修复可在本地执行：

```bash
rsync -av -e "ssh -p 2201 -i $HOME/.ssh/id_rsa_dgx2" \
  training/b_sft/train.py training/b_sft/loss_backend.py \
  chenjiahao@36.102.215.18:/raid/chenjiahao/mas/training/b_sft/
```

退出报错的进程后，用原命令及一个新的 output-dir 重跑；已有完整 checkpoint 时也可按原配置 resume。
不要修改 Triton 分母或绕过空权重。此修复已有本地注册逻辑回归测试；
真实 ZeRO-3/CUDA 验收测试在 `test_liger_cuda.py` 中，必须显式通过多 rank torchrun 启动，
本地无 CUDA，尚未执行该项。无需为此运行 pilot。

- 相关完整回归测试：108 passed，1 个 CUDA 测试因本地环境跳过。随后修正嵌套评估对训练日志标志的影响，相关 18 个测试再次通过。
- 完整导出链检查：22 个独立游戏、352 条样本，覆盖 3/4/5 玩家及 binary/mixed/linear，完成 READY、文件哈希、训练加载和维持/更新配对评分检查。该检查使用 32 simulations、3 backgrounds，仅用于代码验收；最长 prompt 为 4391 tokens。
- 正式搜索预算检查：单个 5 玩家、每人 3 commitments、20 个 mixed goals 的游戏，使用 1024 simulations、6 backgrounds。32 条选中样本、15 个完整配对均通过独立公开信息重放；约 850 万个联合可能世界通过因子化支持处理，无需全部枚举。

上述检查没有启动 LM 训练，也没有修改正在运行的服务器测试。默认 220 个游戏的正式语料尚未批量生成；服务器长上下文显存、真实 ZeRO 权重导出及导出后加载仍需实际运行验证。
