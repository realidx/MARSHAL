# Checkpoint-100 训练池诊断

不启动新训练、不计算验证 loss、不改 checkpoint。已准备 48 道题、24 个完整配对，覆盖 24 个训练游戏。按玩家数、配对类型和答案集合大小分组抽样，这是有意挑选的诊断集，不代表完整训练集的平均准确率。

注意：100 步约半轮训练，尚未重建前 100 步的数据采样顺序。这里只能称训练池诊断，不能保证全部题目已被 checkpoint-100 见过。低分之后若要区分记忆失败与泛化失败，需要进一步核对样本曝光。

## 本地上传

```bash
cd /Users/bruce/MARSHAL
rsync -avz -e "ssh -p 2201 -i $HOME/.ssh/id_rsa_dgx2" \
  training/b_sft/ \
  chenjiahao@36.102.215.18:/raid/chenjiahao/mas/training/b_sft/
rsync -avz -e "ssh -p 2201 -i $HOME/.ssh/id_rsa_dgx2" \
  new/local_data/b_sft_train_probe_step100/ \
  chenjiahao@36.102.215.18:/raid/chenjiahao/mas/new/local_data/b_sft_train_probe_step100/
```

## 服务器：CPU 导出一次

在自己的 tmux 会话和 mas conda 环境内执行，先确认原训练已暂停。此路径必须仍有完整 checkpoint-100。

```bash
cd /raid/chenjiahao/mas
python -m training.b_sft.export \
  --checkpoint outputs/b_sft_round1_restart/checkpoint-100 \
  --output-dir outputs/b_sft_round1_restart/export_step100
```

已有成功导出的目录则跳过。CPU 导出涉及模型权重的磁盘 I/O 和主存，未在服务器验收过实际导出时间。

权重导出不要求 trainer_state.json：HF 保存被中断时，该文件可能尚未写入，但 ZeRO 权重分片已保存。
入口检查 latest/global_stepN 和非空分片，再由 DeepSpeed 读取分片、核对分区数并重建参数。
文件名齐全不保证内容完整；只有合并成功才会写 export_manifest.json。
缺 trainer_state.json 的源目录仍不能按现有训练入口执行 --resume；不要伪造该文件。

若旧导出报 embed_tokens.weight/lm_head.weight 共享内存，更新 export.py 后使用新的输出目录
（例如 export_step100_v2），后续 --model 也改成该目录。新版仅在每个 safetensors 分片写入时
复制共享存储的别名，保留所有键、权重数值和模型 config；不会删除输出层或把 tie_word_embeddings 改掉。
这会增加相应分片的 CPU 临时内存及可能的磁盘占用。旧失败目录不视为成功导出。

## 单卡生成

下面 GPU 0 仅为示例，替换为分配给你的 GPU。程序要求恰好可见一张卡。4B BF16 权重约 8GB，另需 KV cache 和运行临时空间，不能只根据权重大小判断显存足够。发生 OOM 时不要自动占用其他 GPU。

```bash
CUDA_VISIBLE_DEVICES=0 python -m training.b_sft.train_probe \
  --model outputs/b_sft_round1_restart/export_step100_v2 \
  --probe-dir new/local_data/b_sft_train_probe_step100 \
  --output-dir outputs/b_sft_train_probe_step100 \
  --max-new-tokens 128
```

使用显式贪心、KV cache、每题 batch 1、仅最后位置 logits；没有 ZeRO、optimizer 或反向传播。保留 128 上限以匹配此前展示的训练命令；若实际验证使用 64，应保持同一上限。每 5 题打印一次进度，不承诺具体运行分钟数。

主要检查 metrics.json 的 by_gold_size、pairs、shortcut_diagnostics，以及 questions.jsonl/pairs.jsonl 的具体回答。
- 单一偏好题仍全错、大量输出 want/avoid：训练池上也有同样问题；还需确认题目是否真正被见过，不能直接认定训练无法拟合。
- 训练池明显更好：与泛化不足相容，但此诊断集分布不同，不能把分数差直接当作严格的泛化差距。
- 如需测学习增益，再以原始 Qwen 跑同一 probe，使用另一 output-dir；不能假设验证集全回答全集合的行为也必然发生在这些训练题上。

输出目录不可覆盖，报告不会参与 best checkpoint 选择或 early stopping。
