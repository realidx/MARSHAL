# 48 题同题拟合检查

目的：检验答案监督是否能拟合固定题目。随后测小规模匹配的未见游戏；不证明一般 belief 或迁移能力；失败也不能直接证明必须监督 reasoning。

沿用已上传的 b_sft_train_probe_step100/questions.jsonl 和 pairs.jsonl，无需生成新数据。48 题来自 24 个游戏，24 对（15 maintain、9 update），覆盖 3/4 玩家及全部七种答案：全集17、neutral10、neutral/avoid9、want/neutral6、want3、avoid2、want/avoid1。并非均衡测试集。

从原始 Qwen 开始，沿用全参数 SFT 和 answer-only 目标（整个工具调用受监督）。24 optimizer steps，8 卡×每卡1×累积2 = batch16，每3步完整遍历48题，24步约8遍。其他卡数下遍历次数不同。不要从 checkpoint-100 权重起跑，否则混入旧训练影响。

## 本地更新代码

```bash
rsync -avz -e "ssh -p 2201 -i $HOME/.ssh/id_rsa_dgx2" \
  /Users/bruce/MARSHAL/training/b_sft/ \
  chenjiahao@36.102.215.18:/raid/chenjiahao/mas/training/b_sft/
```

另外上传已在本地准备好的泛化题：

```bash
rsync -avz -e "ssh -p 2201 -i $HOME/.ssh/id_rsa_dgx2" \
  /Users/bruce/MARSHAL/new/local_data/b_sft_fit48_generalization/ \
  chenjiahao@36.102.215.18:/raid/chenjiahao/mas/new/local_data/b_sft_fit48_generalization/
```

泛化题从 validation 中按配对匹配抽取，共48题24对，与拟合题的游戏来源独立，沿用原语料结构隔离。
每对匹配玩家数、goal类型、maintain/update和前后答案集合大小。没有严格匹配具体偏好值、历史长度、动作内容或commitment数量。
这是开发诊断，使用金标匹配但不看模型预测；没有动最终test/OOD，也不用于此轮自动选择checkpoint。
两组各48题，模型只加载一次，先同题再泛化。两组都低先查拟合，两组有明显差距则与泛化不足相容；
匹配减少了部分分布因素，不能单凭小样本确定根因是数据分布或reasoning缺失。
结果分别在 same_question_eval/ 和 same_question_eval/generalization/，汇总比较在 comparison.json。

## 服务器训练（自己的 tmux 会话、原 mas 环境）

沿用先前分配的 CUDA_VISIBLE_DEVICES 和有效的 Triton/CUDA 环境设置。先暂停大训练，不并发挤占同一批 GPU。

```bash
cd /raid/chenjiahao/mas
bash training/b_sft/run_shared.sh \
  --mode train --fit-check --max-steps 24 \
  --model /raid/chenjiahao/mas/models/Qwen3-4B-Instruct-2507 \
  --train-file new/local_data/b_sft_train_probe_step100/questions.jsonl \
  --eval-file new/local_data/b_sft_train_probe_step100/questions.jsonl \
  --output-dir outputs/b_sft_fit48_v1 \
  --deepspeed training/b_sft/configs/zero3_shared_optimizer_offload.json \
  --loss-backend liger --max-length 8192 \
  --gradient-accumulation 2 --learning-rate 5e-6 \
  --save-steps 12 --keep-checkpoints 2
```

特意不传 --semantic-eval，不做启动基线或中间生成，最后也不做 loss 评估。
fit-check 是唯一允许训练/评估文件完全相同的诊断入口，普通训练仍禁止跨 split 泄漏。
训练 loss 每步记录。等待进程正常结束及 CHECKPOINT SAVED，不在保存中途 Ctrl-C。

## CPU 导出与单卡同题测试

```bash
python -m training.b_sft.export \
  --checkpoint outputs/b_sft_fit48_v1/checkpoint-24 \
  --output-dir outputs/b_sft_fit48_v1/export_step24

CUDA_VISIBLE_DEVICES=0 python -m training.b_sft.train_probe \
  --model outputs/b_sft_fit48_v1/export_step24 \
  --probe-dir new/local_data/b_sft_train_probe_step100 \
  --output-dir outputs/b_sft_fit48_v1/same_question_eval \
  --generalization-dir new/local_data/b_sft_fit48_generalization \
  --max-new-tokens 128
```

GPU 0 为示例，选你已分配且有足够空闲显存的一张卡。保留同一批48题，不重新抽题。
train_probe 通用报告的 exposure_at_checkpoint_verified=false 表示脚本本身未重建 sampler；本次通过显式同题文件和至少一个完整 epoch 的训练确保题目已被训练。检查 checkpoint-24/trainer_state.json 的 epoch，8卡预期为8。

看 overall、by_gold_size、pairs、shortcut_diagnostics 和逐题输出。尤其检查15个单元素金标题，是否仍全部输出两个或三个值。
若同题高准确率且各类都能拟合，说明 answer-only 在这些题上可拟合，不能据此声称已学会一般推断。
若仍退化为固定输出，先检查实际参数/导出一致性和语义token损失，再做监督范围或reasoning对照，不直接把失败归因为缺少reasoning。

运行24步的上限是节省时间的诊断预算，不是声称24步必须收敛。可保留12/24步checkpoint；如要延长实验，保持配置并使用已有checkpoint续训，不先生成另一批题。
