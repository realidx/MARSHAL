# Oracle-consistent candidate pool v1 — 2026-10-05

**The current pre-D working target is complete:** 100 canonically distinct parent
Bayesian games, each with multiple candidate entrances/windows, independently audited.
This is a candidate pool, not a training-ready release and not the final 100 slices.
D was not run. The 30-parent multi-round floor was an operational target for this
attempt, not a quota previously fixed by the user.

## Contents and coverage

| Item | Verified count |
|---|---:|
| Parent games / structural families | 100 / 62 |
| Complete initial-state terminal references | 100 |
| Retained candidate windows | 1,596 |
| Distinct public entrance nodes, summed across parents | 1,268 |
| Candidate records per parent | 99 parents × 16; one parent × 12 |
| Two-player, two-round parents | 30 |
| Two-player, one-round parents | 20 |
| Three-player, one-round parents | 50 |
| k=1 / k=2 / k=3 windows | 988 / 448 / 160 |
| Proposal / response entrances | 695 / 901 |
| 3-world / 9-world / 27-world parents | 34 / 23 / 43 |
| Train / validation / test parents | 63 / 12 / 25 |

All 30 multi-round parents have retained k=2 and k=3 windows satisfying the existing
increment rule. k counts focal proposal **and response** decisions, and is a maximum,
not a promise every branch realizes k decisions. C/S are differences between complete
contingent-policy terminal values, not sums of decision-level scores.

Parents are distinct under the canonical game/type-catalogue/prior identity; merely
renaming players, actions or goals does not add a parent. Structural-family cap is 8.
Different preference supports/priors within a structural family remain different
Bayesian games; there are 62 public structural families, not 100 unique topologies.
Families do not cross dataset splits; calibration families stay in train.

## Oracle contract and checks

Each parent was fully expanded **from its initial state to native terminal** before
its selected numerical epsilon-Nash profile was certified. Every legal action and
full declared private-world support remains. No cutoff payoff, rollout value,
random-prefix belief reset, or independent entrance re-solve was used.

Each entrance has positive probability under its parent's one saved profile.
Its posterior is the initial prior times that same profile's prefix likelihood,
conditioned on own type and own private answers. All partners and the focal player
after k continue with the same saved profile. Every C exceeds .1; longer windows
must pass the existing .05 C/S increment rule. The .05 positive-S threshold is unchanged.

The acceptance contract is numerical own-utility epsilon-Nash (1e-8), local own-optimal
support and response-only social ties (tie tolerance 1e-9), including the declared
prior-based off-path convention. It is not a uniqueness proof or formal sequential
equilibrium claim. Generic bounded-wrapper certificate wording is supplemented by
explicit initial-root and native-terminal checks; all actual leaves are native terminal.

Independent readback audit completed:

- 100 saved references re-certified without candidate-search shortcuts.
- 1608 candidate members had C/V values recomputed and all prefix posteriors checked.
- 104 S records remeasured: first singleton per parent, every detectable-positive record,
  and every collective calibration record. This is not a claim that every S value was remeasured twice.
- Maximum retained-window best-response gain over saved reference: 1.6e-09.
- Native transitions, terminal payoffs, private information partitions, file hashes,
  canonical uniqueness, joint entrance/world masses, caps and family splits checked.
- 62 related regression tests passed, including candidate rejection, equilibrium
  acceptance, private-information handling, and nondefault-budget reference restoration.

## Limits that remain visible

**No retained window has measured S > .05.** Four collective calibration windows
have detectable entry-history information value; maximum S is about .015334.
Query-answer S was measured on 1,592 singleton rows and was zero. Future-history S
was measured on those rows and was at numerical-noise level (maximum about 8.24e-10).
Entry-plus-future-history S is stored on four collective rows; elsewhere it is null,
not zero. Additional collective scans of four recovered/new parents did not find
strong positive S, but this does not exhaust all possible entry-set contrasts.

The 30 multi-round parents are all **two-player, two-round** games. Three-player
multi-round and genuinely longer-horizon coverage remain unresolved. This pool
therefore supports a preliminary local-slice experiment, not a claim that long-horizon
coverage or information-mechanism coverage has been solved. Model learnability and
D-based usefulness are unmeasured.

## What changed after the checkpoint

The checkpoint contained 70 selectable parents and 1,116 candidate windows, with
only one multi-round parent. The original code and active corpus were archived at:
`../strategic_slices_checkpoint_20261004_before_optimization/`.
Its archive SHA-256 is `2f216d5c88d5bfac1d05a8c4ed5d6c2706e561a42e97669602f039ef167c7055`.

A vectorized local-support/tie screen now rejects clearly invalid search candidates
before costly complete certification. It batches computation, not histories or
information sets; passing it never grants acceptance. The original independent
scalar certification and tolerances remain unchanged.

Paired case 47: the original search failed after 90.62s. Screening alone reduced the
same two-sweep attempt to 20.73s, still failing. Allowing eight ordered best-response
sweeps per start then produced a fully certified profile in 20.18s including native
audit. Case 41 kept exactly the same policy hash in the two-sweep comparison.
These are individual diagnostic runs, not a hardware-controlled throughput estimate.

The first new 24-parent multi-round batch yielded 16 certified/measured cases and
8 uncertified cases under the new configuration; it is a different sample, not a
paired success-rate comparison with the earlier 12-parent batch. Further fixed-seed
batches filled coverage after canonical deduplication and family caps. Failed or
resource-limited attempts have no oracle labels; their ledger is preserved.

Search budgets for fresh multi-round jobs were 240s, up to 8 ordered sweeps per start
and 8,192 joint cells. These are search limits only, not relaxed acceptance. Nondefault
budgets are now saved/restored with certificates to preserve policy identity checks.
Known isomorphic copies of already verified earlier parents can skip duplicate solving.

A separate damped-BR diagnostic on a failed case did not pass certification and was
not adopted. The earlier Gambit dense LCP comparison also did not provide a usable
replacement. No MCTS/CFR approximation was substituted for the certified oracle.

## Files and reproduction

- `parents.jsonl`: complete native parent specifications and provenance.
- `references.jsonl`, `references/`: one saved complete reference per parent.
- `candidates.jsonl`: singleton/collective distributions, C/S channels, k and role metadata.
- `audit.json`, `audits/`: independent readback evidence.
- `generation_ledger.jsonl`: selected, failed, duplicated, capped and deferred cases.
- `provenance/jobs.json`, `provenance/config.json`: the attempted/queued generation plan.
- `provenance/environment.json`: Python/NumPy/SciPy versions; no model calls.
- `source/`: packaging/audit source snapshots. Archived checkpoint and optimization
  manifests preserve the earlier implementation stages as well.
- `manifest.json`, `CANDIDATES_VERIFIED.json`: file hashes and verified candidate-pool status.

From repository root, validate the packaged files and schema:

```python
from training.strategic_slices.terminal_candidates import TerminalCandidates
dataset = TerminalCandidates('new/local_data/strategic_slices_oracle_consistent_candidates_v1')
```

To independently recertify a particular parent without modifying the package:

```python
from examples.strategic_slices.package_oracle_consistent import audit_rows
parent_id = 'PARENT_ID'
rows = [r for r in dataset.candidates if r['parent_id'] == parent_id]
print(audit_rows(dataset.reference(rows[0]), rows, parent_id))
```

Future work is to decide whether the documented coverage is sufficient, expand it if
needed, then run D and select the final 100 strategic slices. **Those final 100 slices
have not been selected in this task.**
