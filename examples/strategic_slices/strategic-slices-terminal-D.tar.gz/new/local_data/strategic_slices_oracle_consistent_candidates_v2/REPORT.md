# Balanced candidate subset — 2026-10-05

100 unchanged parents, exactly 8 candidates each: **800 candidates**.
Source: `new/local_data/strategic_slices_oracle_consistent_candidates_v1` (1,596 candidates). No D evaluation or final 100-slice selection.

Selection exhaustively compares eight-row subsets within each parent. It retains
all available player, k and proposal/response categories, all four collective
controls, and at least two public histories. In order, it balances player counts,
k counts, and decision kinds by minimizing squared counts; then maximizes ego/k,
remaining-turn and entrance diversity. Cumulative distribution and stable hashes
break ties. This is coverage selection, not a ranking of training value.

| Distribution | Before | After |
| --- | --- | --- |
| k | {1: 988, 2: 448, 3: 160} | {2: 279, 3: 156, 1: 365} |
| proposal/response | {'proposal': 695, 'response': 901} | {'proposal': 396, 'response': 404} |
| seats by player count | {'2': {0: 435, 1: 361}, '3': {0: 317, 1: 253, 2: 230}} | {'2': {1: 200, 0: 200}, '3': {2: 134, 0: 136, 1: 130}} |

All 30 two-player/two-round parents retain k=2 and k=3. Parent composition remains
30 two-player/two-round, 20 two-player/one-round, 50 three-player/one-round.
No three-player multi-round parent or measured S>.05 candidate has been added.
Scarce categories cannot be made equally frequent without creating new candidates.

Every selected row is identical to its source record, including C/S, posterior,
reference and split. All 100 parent/reference records and reference files match.
Original independent audits are retained in `provenance/source_verification/`;
`audit.json` verifies subset inheritance, not a new solver/C/S run. Parent-level
`entrance_selection` fields describe original generation; current selection is in
`selection_ledger.jsonl`. Full counts and policy are in `balance.json`.

Reproduce into a new directory:

```sh
python -m examples.strategic_slices.rebalance_candidates --source new/local_data/strategic_slices_oracle_consistent_candidates_v1 --output NEW_DIRECTORY
```
