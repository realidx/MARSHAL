#!/usr/bin/env bash
set -euo pipefail
runtime_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$runtime_root"
export PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1
export PYTHONPATH="$runtime_root/third_party/negotiation_benchmark/src:$runtime_root"
exec "${OUTCOME_PYTHON:-/raid/chenjiahao/conda_envs/mas/bin/python}" runs/outcome_selfplay_screen/rollout.py "$@"
