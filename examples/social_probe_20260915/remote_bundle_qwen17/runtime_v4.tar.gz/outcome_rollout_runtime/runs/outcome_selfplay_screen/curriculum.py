"""Small outcome-only curriculum; reuses native rules, never B/P input builders.
Run --build to regenerate derived curriculum files from the existing read-only DB.
sample_group returns INTERNAL environment material, not an LM prompt.
"""
from pathlib import Path
import sys,json,sqlite3,copy,hashlib,argparse
from itertools import product
from collections import Counter
import numpy as np
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT),str(ROOT/'third_party/negotiation_benchmark/src')]
from training.b_sft.social_private_teacher import PrivateInvestigationRules,Investigate,GAME_VERSION
from outcome_rules import OutcomeRules, generation_rule
PrivateInvestigationRules = OutcomeRules
from benac_p.schema import OfferProposal,ResponseAction,PassProposal
from benac_p.endgame_diagnose import decode_action

SELECTION=[
 ('foundation','cooperate_a','161c7d'),('foundation','third_party_intro','11f110'),
 ('adaptation','partner_type_choice','c997f2'),('adaptation','third_party_uncertainty','11f110'),
 ('tradeoffs','interacting_commitments_a','9e12ed'),('tradeoffs','third_party_conflict','5abc5c')]
LEVELS=['foundation','adaptation','tradeoffs']
TRAINING_PROPOSAL={'status': 'proposal_only_no_training_authorization', 'algorithm': 'GRPO working assumption', 'gpus_per_experiment': 4, 'parallel_experiments': 2, 'global_seed': 42, 'reset_groups_per_update': 6, 'rollouts_per_group': 4, 'complete_games_per_update': 24, 'initial_sampling_updates': 60, 'total_training_games': 1440, 'optimization_epochs_per_rollout': 1, 'validation_updates': [0, 20, 40, 60], 'extension': 'Assess at 60; extend all comparison arms equally to 120 or 200 only if validation and learning-signal diagnostics justify it.', 'gpu_policy': 'Keep effective batch fixed between 4 and 8 GPUs; adjust concurrency, sharding and accumulation after measuring model/context memory.', 'step_definition': 'One logical collection-and-update iteration. Not proposal turns, generated responses, or low-level optimizer steps.', 'advantage_group': 'Same reset and same player seat across four complete rollouts; only that player terminal return. Never pool rewards from different players.', 'microbatch': 'Start with one packed trajectory/chunk per training device; exact accumulation depends on variable-length rollout packing and measured memory.', 'limitations': 'No production self-play runner integration or GPU throughput benchmark yet; model size and available VRAM must be confirmed before execution.'}

def dump(v):return json.dumps(v,ensure_ascii=False,sort_keys=True)
def sha(v):return hashlib.sha256(dump(v).encode()).hexdigest()
def safe_observation(rules,node,player,world):
 obs=rules.observation(node,player,world[player])
 bad={'type_catalogues','public_type_catalogues','worlds','private_preferences','teacher','certificate','action_values','metadata','supplied_belief','initial_support','partner_policy'}
 def check(v):
  if isinstance(v,dict):
   assert not bad.intersection(v)
   for x in v.values():check(x)
  elif isinstance(v,(tuple,list)):
   for x in v:check(x)
 check(obs);return obs

def payoff_envelope(raw):
 rules=PrivateInvestigationRules(raw);k=rules.spec.n_actions_per_player;off=np.cumsum([0]+list(k));states=[]
 for bits in product((0,1),repeat=sum(k)):
  sat=[(all(bits[off[a.player_id]+a.action_id] for a in g.required_actions) if g.binary else sum(bits[off[a.player_id]+a.action_id] for a in g.required_actions)/len(g.required_actions)) for g in rules.spec.goals]
  states.append(np.array(rules.worlds)@np.array(sat))
 u=np.array(states);maxima=u.max(axis=0)
 return dict(worlds=len(rules.worlds),all_types_have_positive_physical_opportunity=bool(np.all(maxima>0)),
  joint_gain_worlds=int(np.any(np.all(u>=0,axis=2)&(np.sum(u>0,axis=2)>=2),axis=0).sum()),
  conflicting_maxima_worlds=int((~np.any(np.all(u==maxima,axis=2),axis=0)).sum()),
  payoff_min=float(u.min()),payoff_max=float(u.max()),
  scope='Bit-pattern utility envelope; not proof of strategic reachability or guaranteed gain')

def sensitivity_witness(raw):
 """Reachable final ordinary proposal after legal PASS prefix, not a training prefix.
 Responder takes its own best terminal utility, ACCEPT on exact ties.
 Tests exact hidden-type-conditioned action optima, not acquisition value.
 """
 rules=PrivateInvestigationRules(raw);node=rules.initial();prefix=[]
 while node.state.turn_index<len(rules.spec.round_robin)-1:
  a=PassProposal();prefix.append(a.to_dict());node=rules.step(node,a)
 actor=rules.actor(node);actions=[a for a in rules.actions(node) if not isinstance(a,Investigate)]
 q=[];flips=[]
 selected=sorted(np.random.default_rng(42).choice(len(rules.worlds),min(64,len(rules.worlds)),replace=False).tolist())
 worlds=[rules.worlds[i] for i in selected]
 for wi,w in enumerate(worlds):
  scores=[]
  for ai,a in enumerate(actions):
   child=rules.step(node,a)
   if isinstance(a,OfferProposal):
    yes=rules.step(child,ResponseAction(ResponseAction.ACCEPT));no=rules.step(child,ResponseAction(ResponseAction.REJECT))
    y=np.array(w)@yes.state.goal_satisfaction();n=np.array(w)@no.state.goal_satisfaction();p=a.offer.partner_id
    child=yes if y[p]>=n[p] else no
    flips.append((ai,wi,p,float(y[p]-n[p])))
   scores.append(float((np.array(w)@child.state.goal_satisfaction())[actor]))
  q.append(scores)
 witnesses=[]
 for i,w in enumerate(worlds):
  for j in range(i+1,len(q)):
   if w[actor]!=worlds[j][actor]:continue
   left=set(np.flatnonzero(np.array(q[i])==max(q[i])));right=set(np.flatnonzero(np.array(q[j])==max(q[j])))
   if not left&right:
    witnesses.append(dict(world_indices=[i,j],actor=actor,optimal_indices=[sorted(map(int,left)),sorted(map(int,right))],q=[q[i],q[j]]))
 strict=[]
 for ai,a in enumerate(actions):
  rows=[x for x in flips if x[0]==ai]
  positive=[x for x in rows if x[3]>0];negative=[x for x in rows if x[3]<0]
  if positive and negative:strict.append(dict(action_index=ai,accept_world=positive[0][1],reject_world=negative[0][1],responder=positive[0][2]))
 return dict(diagnostic_world_indices=selected,full_support_worlds=len(rules.worlds),exhaustive=len(worlds)==len(rules.worlds),prefix=prefix,actions=[a.to_dict() for a in actions],conditional_choice_switches=witnesses[:2],strict_response_switches=strict[:2],
  scope='Legal branch from zero commitments. Same proposer private row for choice switches; reference assumes type-informed response. Does not prove this history occurs under learned play, or optimal investigation; never supplied to players.')

def build():
 c=sqlite3.connect(HERE/'games.sqlite')
 sources={r[0]:json.loads(r[1]) for r in c.execute('select id,internal_json from games')}
 templates=[];instances=[];checks=[];resets=[]
 # 20 realized resets per level; global 40:20 players, 24/18/12/6 rounds.
 bank_counts={('foundation',2):[6,4,3,1],('foundation',3):[2,2,1,1],
  ('adaptation',2):[4,4,3,1],('adaptation',3):[4,2,1,1],
  ('tradeoffs',2):[6,4,3,1],('tradeoffs',3):[2,2,1,1]}
 for index,(level,name,suffix) in enumerate(SELECTION):
  source=next(gid for gid in sources if gid.endswith(suffix))
  raw=dict(game=copy.deepcopy(sources[source]['game']),history=[],preference_generation=generation_rule(level))
  for key in ('private_preferences','metadata','seed'):raw['game'].pop(key,None)
  raw['game']['menu_enabled']=False
  # No all-combination expansion: linear introduction, mixed adaptation, binary tradeoffs.
  for gi,g in enumerate(raw['game']['goals']):g['binary']=level=='tradeoffs' or level=='adaptation' and gi%2==1
  n=raw['game']['n_players'];local=np.random.default_rng(np.random.SeedSequence([42,index,83]))
  schedule=[int(p) for _ in range(5) for p in local.permutation(n)]
  raw['game']['round_robin']=schedule
  templates.append(dict(id=name,level=level,source_id=source,raw=raw,physical=payoff_envelope(raw),
   admission='legal geometry; no solver or utility threshold',completion='linear' if level=='foundation' else 'mixed' if level=='adaptation' else 'binary'))
  for ri,rounds in enumerate((2,3,4,5)):
   r=copy.deepcopy(raw);r['game']['round_robin']=schedule[:n*rounds];iid=f'{name}-r{rounds}'
   rules=OutcomeRules(r)
   instances.append(dict(id=iid,template=name,level=level,players=n,rounds=rounds,raw=r,screen=sensitivity_witness(r),
    solver_diagnostic=dict(status='not_run',admission_effect='none'),full_prior_worlds=len(rules.worlds)))
   rng=np.random.default_rng(np.random.SeedSequence([42,index,rounds,907]))
   for j,chosen_wi in enumerate(rng.choice(len(rules.worlds),bank_counts[(level,n)][ri],replace=False)):
    wi=int(chosen_wi);world=rules.worlds[wi]
    reset=dict(id=f'{iid}-s{j}',instance_id=iid,level=level,players=n,rounds=rounds,world_index=wi,realized_world=world)
    resets.append(reset)
    node=rules.initial();actor=rules.actor(node);query=Investigate((actor+1)%n,0)
    child=rules.step(node,query,realized_world=world)
    assert child.state.turn_index==1 and child.state.snapshot_commitments()==node.state.snapshot_commitments()
    for p in range(n):assert bool(safe_observation(rules,child,p,world)['private_results'])==(p==actor)
    trajectory=[]
    while not node.state.is_terminal:
     p=rules.actor(node);obs=safe_observation(rules,node,p,world);acts=rules.actions(node)
     action=acts[int(rng.integers(len(acts)))];trajectory.append((p,obs,action));node=rules.step(node,action,realized_world=world)
    replay=rules.initial()
    for p,obs,action in trajectory:
     assert safe_observation(rules,replay,p,world)==obs
     replay=rules.step(replay,action,realized_world=world)
    assert replay.state.public_state()==node.state.public_state() and replay.state.private_results==node.state.private_results
    # Independent completion/reward recomputation, including fractional negative payoffs.
    bits=node.state.snapshot_commitments()
    satisfaction=[float(all(bits[a.player_id][a.action_id] for a in g.required_actions)) if g.binary else sum(bits[a.player_id][a.action_id] for a in g.required_actions)/len(g.required_actions) for g in rules.spec.goals]
    assert np.allclose(rules.terminal_payoffs(node,world),np.array(world)@satisfaction)
    checks.append(dict(id=reset['id'],decisions=len(trajectory),terminal_rewards=rules.terminal_payoffs(node,world),replayed=True))
 tickets={level:[x['id'] for x in instances if x['level']==level for _ in range({2:4,3:3,4:2,5:1}[x['rounds']]*(2 if x['players']==2 else 1))] for level in LEVELS}
 assert Counter(x['players'] for x in resets)=={2:40,3:20}
 assert Counter(x['rounds'] for x in resets)=={2:24,3:18,4:12,5:6}
 ablations=[]
 for t in templates:
  for mode in ('binary','linear','mixed'):
   raw=copy.deepcopy(t['raw']);raw['game']['round_robin']=raw['game']['round_robin'][:2*raw['game']['n_players']]
   for gi,g in enumerate(raw['game']['goals']):g['binary']=mode=='binary' or mode=='mixed' and gi%2==1
   ablations.append(dict(template=t['id'],completion=mode,rounds=2,physical=payoff_envelope(raw),screen=sensitivity_witness(raw),training_reset=False))
 paths=['runs/outcome_selfplay_screen/'+p+'.py' for p in ('curriculum','outcome_rules','audit_solver_cycles')]+['training/b_sft/'+p+'.py' for p in ('social_private_teacher','social_terminal_teacher','shared_teacher')]+['third_party/negotiation_benchmark/src/benac_p/'+p+'.py' for p in ('state','schema','endgame')]
 manifest=dict(training_proposal=TRAINING_PROPOSAL,evaluation_manifest='eval_splits.json',version='outcome-curriculum-v3',game_version=GAME_VERSION,global_seed=42,group_size=4,templates=templates,instances=instances,resets=resets,tickets=tickets,completion_ablation=ablations,
  phases=[dict(progress=[0,.2],level_weights=[1,0,0]),dict(progress=[.2,.5],level_weights=[1,3,0]),dict(progress=[.5,1],level_weights=[1,2,7])],
  phases_status='Proposed curriculum, not validated difficulty ordering or authorized training hyperparameters.',
  information_contract='Public IID slot generation conditioned on stated validity rules. Full compatible joint support in solver. Finite realized reset bank is NOT a restriction on hidden preferences. Player receives safe_observation only.',
  reward='own terminal outcome only; solver is an optional screening aid, never a reward or admission gate',
  admission='Legal games admitted independently of solver success/cycle/timeout. Structural witnesses are annotations, not gates.',
  split='training_development_only; not heldout evaluation',source_hashes={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in paths},
  counts=dict(templates=len(templates),instances=len(instances),realized_resets=len(resets),distinct_resets=len({(x['instance_id'],dump(x['realized_world'])) for x in resets}),validation_episodes=len(checks),conditional_switch_instances=sum(bool(x['screen']['conditional_choice_switches']) for x in instances),strict_response_switch_instances=sum(bool(x['screen']['strict_response_switches']) for x in instances)))
 (HERE/'curriculum.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
 (HERE/'curriculum_validation.json').write_text(json.dumps(dict(episodes=checks,counts=manifest['counts'],ratios_verified=True,all_player_views_reconstructed=True,training_started=False),ensure_ascii=False,indent=2)+'\n')
 c.execute('CREATE TABLE IF NOT EXISTS curriculum_resets(id TEXT PRIMARY KEY, instance_id TEXT, internal_json TEXT)')
 c.execute('DELETE FROM curriculum_templates');c.execute('DELETE FROM curriculum_instances');c.execute('DELETE FROM curriculum_resets')
 c.executemany('INSERT INTO curriculum_templates VALUES (?,?,?,?)',[(t['id'],t['level'],t['source_id'],dump(t)) for t in templates])
 c.executemany('INSERT INTO curriculum_instances VALUES (?,?,?,?,?,?)',[(x['id'],x['template'],x['level'],x['players'],x['rounds'],dump(x)) for x in instances])
 c.executemany('INSERT INTO curriculum_resets VALUES (?,?,?)',[(x['id'],x['instance_id'],dump(x)) for x in resets])
 c.execute('INSERT OR REPLACE INTO metadata VALUES (?,?)',('active_curriculum',dump(dict(version=manifest['version'],counts=manifest['counts'],legacy='games/trajectories/player_steps and old solver audits are historical; their hidden priors must not be used as the active prior'))))
 c.commit();c.close();print(dump(manifest['counts']),flush=True)
 return manifest

def sample_group(group_index,progress,manifest=None):
 """One internal GRPO reset package: same world/schedule for 4 rollouts.
 30 consecutive groups with block-constant progress give exact quotas.
 Player IDs permute together with goals, private rows, action sizes, schedule.
 """
 assert group_index>=0 and 0<=progress<=1
 m=manifest or json.loads((HERE/'curriculum.json').read_text())
 block,offset=divmod(group_index,30);rng=np.random.default_rng(np.random.SeedSequence([m['global_seed'],block,101]))
 phase=next(p for p in m['phases'] if p['progress'][0]<=progress<p['progress'][1] or progress==1 and p['progress'][1]==1)
 weights=np.array(phase['level_weights'],float);level=LEVELS[int(rng.choice(3,p=weights/weights.sum()))]
 ids=list(m['tickets'][level]);rng.shuffle(ids);inst=next(i for i in m['instances'] if i['id']==ids[offset])
 rng=np.random.default_rng(np.random.SeedSequence([m['global_seed'],group_index,103]));raw=copy.deepcopy(inst['raw']);n=raw['game']['n_players'];perm=list(map(int,rng.permutation(n)));old=copy.deepcopy(raw)
 raw['game']['n_actions_per_player']=[old['game']['n_actions_per_player'][perm.index(p)] for p in range(n)]
 for g in raw['game']['goals']:
  for a in g['required_actions']:a['player_id']=perm[a['player_id']]
 raw['game']['round_robin']=[perm[p] for p in old['game']['round_robin']]
 bank=[x for x in m['resets'] if x['instance_id']==inst['id']]
 chosen=bank[int(rng.integers(len(bank)))];world=tuple(tuple(chosen['realized_world'][perm.index(p)]) for p in range(n))
 rules=OutcomeRules(raw);assert world in rules.worlds
 return dict(instance_id=inst['id'],reset_id=chosen['id'],level=level,raw=raw,realized_world=world,rollout_seeds=[int(x) for x in rng.integers(0,2**31-1,size=m['group_size'])],player_permutation=perm)

def structural_key(raw):
 """Invariant to player, commitment and goal names; excludes rounds/completion.
 Splits keep whole dependency structures together, including binary/linear pairs.
 """
 from itertools import permutations
 g=raw['game'];n=g['n_players'];width=g['n_actions_per_player'];keys=[]
 for perm in permutations(range(n)):
  for maps in product(*(tuple(permutations(range(k))) for k in width)):
   sizes=tuple(width[perm.index(p)] for p in range(n))
   goals=tuple(sorted(tuple(sorted((perm[a['player_id']],maps[a['player_id']][a['action_id']]) for a in goal['required_actions'])) for goal in g['goals']))
   keys.append((sizes,goals,g['max_changes']))
 return sha(min(keys))

def build_eval():
 """Small structural holdouts. No solver screening or model-based selection."""
 from benac_p.generator import GeneratorConfig,generate_game
 m=json.loads((HERE/'curriculum.json').read_text());db=sqlite3.connect(HERE/'games.sqlite')
 excluded={structural_key(t['raw']) for t in m['templates']}
 excluded.update(structural_key(json.loads(row[0])) for row in db.execute('select internal_json from games'))
 records=[];checks=[];families={}
 for si,split in enumerate(('validation','test')):
  for n in (2,3):
   goals=2 if split=='validation' else 3
   cfg=GeneratorConfig(n_players=n,actions_per_player=(2 if split=='validation' else 3) if n==2 else 1,n_goals=goals,n_rounds=5,goal_arities=(2,),preference_probs=(1/3,1/3,1/3))
   for attempt in range(2000):
    seed=int(np.random.SeedSequence([42,701,si,n,attempt]).generate_state(1)[0]);g=generate_game(seed,cfg).to_dict()
    # Trim unused commitments so extra irrelevant action names do not create a fake holdout.
    used=[sorted({a['action_id'] for goal in g['goals'] for a in goal['required_actions'] if a['player_id']==p}) for p in range(n)]
    widths=[len(x) for x in used]
    desired=([2,2] if split=='validation' else [1,3]) if n==2 else [1,1,1]
    if sorted(widths)!=sorted(desired):continue
    for goal in g['goals']:
     for a in goal['required_actions']:a['action_id']=used[a['player_id']].index(a['action_id'])
    g['n_actions_per_player']=widths
    for k in ('private_preferences','seed','metadata'):g.pop(k,None)
    raw=dict(game=g,history=[],preference_generation=generation_rule('adaptation'));key=structural_key(raw)
    if key not in excluded:break
   else:raise RuntimeError('Cannot find the predeclared structural holdout')
   excluded.add(key);families[f'{split}-{n}p']=dict(structural_key=key,generator_seed=seed,commitments=widths,goals=goals)
   rounds_list=[2,2,2,3,3,3,4,5] if n==2 else [2,2,3,4]
   modes=['linear','mixed','binary']*3 if n==2 else ['binary','linear','mixed','binary']
   for j,rounds in enumerate(rounds_list):
    r=copy.deepcopy(raw);r['game']['round_robin']=g['round_robin'][:n*rounds];mode=modes[j]
    r['preference_generation']=generation_rule('foundation' if mode=='linear' else 'adaptation')
    for gi,goal in enumerate(r['game']['goals']):goal['binary']=mode=='binary' or mode=='mixed' and gi%2==1
    rng=np.random.default_rng(np.random.SeedSequence([42,709,si,n,j]));rules=OutcomeRules(r)
    wi=int(rng.integers(len(rules.worlds)));world=rules.worlds[wi];rid=f'{split}-{n}p-{j}'
    records.append(dict(id=rid,split=split,players=n,rounds=rounds,completion=mode,structural_key=key,raw=r,realized_world=world,rollout_seeds=list(map(int,rng.integers(0,2**31-1,size=2)))))
    node=rules.initial();trace=[]
    while not node.state.is_terminal:
     p=rules.actor(node);obs=safe_observation(rules,node,p,world);actions=rules.actions(node);action=actions[int(rng.integers(len(actions)))];trace.append((p,obs,action));node=rules.step(node,action,realized_world=world)
    replay=rules.initial()
    for p,obs,action in trace:
     assert obs==safe_observation(rules,replay,p,world);replay=rules.step(replay,action,realized_world=world)
    assert node.state.public_state()==replay.state.public_state() and node.state.private_results==replay.state.private_results
    bits=node.state.snapshot_commitments();sat=[float(all(bits[a.player_id][a.action_id] for a in goal.required_actions)) if goal.binary else sum(bits[a.player_id][a.action_id] for a in goal.required_actions)/len(goal.required_actions) for goal in rules.spec.goals]
    assert np.allclose(rules.terminal_payoffs(node,world),np.array(world)@sat)
    checks.append(dict(id=rid,complete_replay=True,decisions=len(trace)))
 for split in ('validation','test'):
  rows=[x for x in records if x['split']==split]
  assert Counter(x['players'] for x in rows)=={2:8,3:4}
  assert Counter(x['rounds'] for x in rows)=={2:5,3:4,4:2,5:1}
  assert Counter(x['completion'] for x in rows)=={'linear':4,'mixed':4,'binary':4}
 package=dict(version='outcome-eval-v1',global_seed=42,train_manifest_version=m['version'],families=families,records=records,
  counts=dict(train=60,validation=12,test=12),
  separation='Goal dependency structures disjoint under player/action/goal relabeling, ignoring completion and rounds; excludes historical source candidates too.',
  selection='Predeclared structural configurations, legality only; no solver or learned-policy scores used.',
  limitations='Only two structural families per split. Validation uses two goals; test uses three. This is a small structural-generalization probe, not IID performance or a precise population estimate.',
  evaluation=dict(opponent='Frozen initial checkpoint, identical across training arms; use same inference settings and seeds',metric='Primary: each evaluated player own terminal payoff, stratified by players and completion. Secondary: change from that training arm pre-selfplay checkpoint on identical resets/seats and common frozen opponents.',seats='Evaluate one learning-policy seat at a time against frozen opponents; rotate through every seat',repeats=2,validation_steps=[0,20,40,60],test_use='Only after validation-based checkpoint selection: evaluate the saved pre-selfplay checkpoint and selected checkpoint. Never tune on test.',episodes_per_full_evaluation=56),
  validation=dict(replays=checks,structural_disjointness=True,training_or_inference_started=False),
  source_hashes={path:hashlib.sha256((ROOT/path).read_bytes()).hexdigest() for path in ('runs/outcome_selfplay_screen/curriculum.py','runs/outcome_selfplay_screen/outcome_rules.py','third_party/negotiation_benchmark/src/benac_p/generator.py')})
 (HERE/'eval_splits.json').write_text(json.dumps(package,ensure_ascii=False,indent=2)+'\n')
 db.execute('CREATE TABLE IF NOT EXISTS curriculum_eval_resets(id TEXT PRIMARY KEY,split TEXT,structural_key TEXT,internal_json TEXT)')
 db.execute('DELETE FROM curriculum_eval_resets')
 db.executemany('INSERT INTO curriculum_eval_resets VALUES (?,?,?,?)',[(x['id'],x['split'],x['structural_key'],dump(x)) for x in records])
 db.execute('INSERT OR REPLACE INTO metadata VALUES (?,?)',('evaluation_split',dump({k:v for k,v in package.items() if k!='records'})))
 db.commit();db.close();print(dump(package['counts']))
 return package

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--build',action='store_true');p.add_argument('--build-eval',action='store_true');a=p.parse_args()
 if a.build:build()
 elif a.build_eval:build_eval()
 else:print('Use --build, or import sample_group and safe_observation. No training or LM calls.')


def search_strategic_levels():
 """Bounded full-game private-solver search; records actual positive-reach witnesses.
 No prefixes, no alternative solver initialization, no changes to solver files.
 """
 from training.b_sft.debug.audit_minimal_teaching import fixture
 from training.b_sft.social_private_teacher import PrivateEpisode
 from training.b_sft.shared_teacher import SearchLimit
 from benac_p.private_game_pilot import deadline,ProbeTimeout
 import time
 db=sqlite3.connect(HERE/'games.sqlite')
 db.execute('CREATE TABLE IF NOT EXISTS curriculum_search(id TEXT PRIMARY KEY,internal_json TEXT,result_json TEXT)')
 profiles=[(1,1),(1,0),(1,-1),(0,1),(-1,1)]
 proposals=[((1,-1),((1,1),(-1,1))),((1,0),((1,1),(-1,1))),((1,1),((1,0),(-1,1))),((1,-1),((1,1),(0,1))),((0,1),((1,1),(1,-1))),((1,1),((1,-1),(0,1))),((1,0),((0,1),(-1,1))),((1,-1),((1,0),(-1,1)))]
 for j,(own,types) in enumerate(proposals):
  for order in (0,1):
   raw=fixture(own=own,types=types,schedule=tuple([order,1-order]*2),layout=(2,1));raw['history']=[]
   gid='strategic-'+sha(raw)[:20]
   if db.execute('SELECT 1 FROM curriculum_search WHERE id=?',(gid,)).fetchone():continue
   start=time.monotonic();r=dict(status='unavailable',game_version=GAME_VERSION,from_zero=True,max_nodes=120000,seconds_budget=5)
   try:
    with deadline(7):e=PrivateEpisode(raw,max_nodes=120000,seconds=5,max_sweeps=32)
    tree=e.tree;r.update(status='solved',certificate=tree.certificate)
    reach=[None]*len(tree.entries);reach[0]=tree.world_weights.copy();witness=[];sacrifices=[]
    for i,entry in enumerate(tree.entries):
     if entry.actor is None:continue
     p=entry.actor;av=np.stack([tree.values[c] for c in entry.children]);current=np.asarray(tree.worlds)@entry.node.state.goal_satisfaction()
     for ai,c in enumerate(entry.children):reach[c]=reach[i]*tree.policy[i][ai]
     # Visible histories reached with positive probability; actual own/info groups.
     groups=[]
     for ids in tree.information_groups[i]:
      weights=reach[i][ids]
      if weights.sum()<=1e-12:continue
      vals=np.average(av[:,ids,p],axis=1,weights=weights)
      best=np.flatnonzero(vals>=vals.max()-1e-9)
      groups.append((ids,vals,set(map(int,best))))
      for ai in best:
       if tree.policy[i][ai,ids].max()<=0:continue
       if entry.node.pending is not None and entry.actions[ai].to_dict().get('response')=='ACCEPT':
        nxt=tree.entries[entry.children[ai]].node
        immediate=np.asarray(tree.worlds)@nxt.state.goal_satisfaction()
        delta=float(np.average(immediate[ids,p]-current[ids,p],weights=weights))
        # Costly current acceptance, future return improves over current utility.
        if delta<0 and vals[ai]>np.average(current[ids,p],weights=weights)+1e-9:
         sacrifices.append(dict(node=i,player=p,immediate_delta=delta,terminal_value=float(vals[ai])))
     for a in range(len(groups)):
      for b in range(a+1,len(groups)):
       ids,va,oa=groups[a];jds,vb,ob=groups[b]
       if tree.worlds[ids[0]][p]==tree.worlds[jds[0]][p] and not oa&ob:
        witness.append(dict(node=i,player=p,world_indices=[list(map(int,ids)),list(map(int,jds))],q=[va.tolist(),vb.tolist()],actions=[a.to_dict() for a in entry.actions],public_state=entry.node.state.public_state(),reach=[float(reach[i][ids].sum()),float(reach[i][jds].sum())]))
    r.update(private_information_action_switches=witness[:3],costly_acceptance=sacrifices[:3],expected_payoffs=np.average(tree.values[0],axis=0,weights=tree.world_weights).tolist())
   except (SearchLimit,ProbeTimeout) as exc:r['reason']=str(exc)
   r['seconds']=round(time.monotonic()-start,3)
   db.execute('INSERT INTO curriculum_search VALUES (?,?,?)',(gid,dump(raw),dump(r)));db.commit()
   print(dump(dict(id=gid,status=r['status'],seconds=r['seconds'],switches=len(r.get('private_information_action_switches',[])),costly=len(r.get('costly_acceptance',[])),reason=r.get('reason'))),flush=True)
 db.close()
