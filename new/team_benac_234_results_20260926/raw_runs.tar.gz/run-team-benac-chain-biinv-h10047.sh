#!/usr/bin/env bash
set -euo pipefail
export TEAM_CHAIN=1
exec bash /home/e/e1300530/tmp/run-team-benac-biinv-h10047.sh
