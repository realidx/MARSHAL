#!/usr/bin/env bash
set -euo pipefail
cd "${SLURM_SUBMIT_DIR:?}"
[[ "$(git rev-parse HEAD)" == "${DIAG_SOURCE_COMMIT:?}" ]]
[[ -z "$(git status --porcelain)" ]] || exit 42
: "${DIAG_MODEL_DIR:?}" "${DIAG_LABEL:?}" "${DIAG_CHECKPOINT_HASH:?}"
[[ -f "$DIAG_MODEL_DIR/config.json" ]]
[[ "$DIAG_LABEL" =~ ^[a-zA-Z0-9_-]+$ ]]
: "${CUDA_VISIBLE_DEVICES:?}"
[[ "$CUDA_VISIBLE_DEVICES" != *,* ]]
source /home/e/e1300530/miniconda3/etc/profile.d/conda.sh
conda activate /home/e/e1300530/tmp/marshal-vllm09
export PYTHONPATH="$PWD:$PWD/third_party/negotiation_benchmark/src:$PWD/mcore_adapter/src:${PYTHONPATH:-}"
export TOKENIZERS_PARALLELISM=false OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=1
export VLLM_BATCH_INVARIANT=1 TEAM_PARALLEL_GAMES=4
unset VLLM_USE_V1 VLLM_ATTENTION_BACKEND TRITON_PTXAS_PATH OPENAI_API_KEY
nvcc_path="$(readlink -f "$(command -v nvcc)")"
export CUDA_HOME="$(dirname "$(dirname "$nvcc_path")")"
site_dir="$(python -c 'import sysconfig; print(sysconfig.get_paths()["purelib"])')"
export PATH="$CUDA_HOME/bin:$PATH"
export LD_LIBRARY_PATH="$CONDA_PREFIX/lib:$CONDA_PREFIX/targets/x86_64-linux/lib:$site_dir/nvidia/cuda_runtime/lib:$site_dir/nvidia/cudnn/lib:${LD_LIBRARY_PATH:-}"
export CUDNN_FRONTEND_CUDART_LIB_NAME=libcudart.so.13
python -c 'from examples.final_evaluation.team_benac import load; m,c=load(); assert len(c)==16; print(m,flush=True)'
run_family=team_benac
if [[ "${TEAM_CHAIN:-0}" == 1 ]]; then
  run_family=team_benac_chain
  python -c 'from pathlib import Path; from examples.final_evaluation.team_benac import load; [load(Path(f"examples/final_evaluation/team_benac_{n}p_v1")) for n in (2,4)]'
fi
out="$PWD/runs/${run_family}/${DIAG_LABEL}-${SLURM_JOB_ID}"
mkdir -p "$out"
port=$((23000 + SLURM_JOB_ID % 7000))
served_model="team-benac-${DIAG_LABEL}"
printf '%s\n' "source_commit=$DIAG_SOURCE_COMMIT" "model=$DIAG_MODEL_DIR" \
  "checkpoint_hash=$DIAG_CHECKPOINT_HASH" 'VLLM_BATCH_INVARIANT=1' \
  'tensor_parallel_size=1' 'max_num_seqs=32' 'max_model_len=32768' \
  'parallel_games=4' 'temperature=0' 'repeats=1' 'max_tokens=4096' \
  'prefix_caching=true' 'chunked_prefill=false' 'cascade_attention=false' \
  'enforce_eager=true' 'homogeneous_team=true' > "$out/SERVING_PROFILE.txt"
setsid python -u -m vllm.entrypoints.openai.api_server \
  --model "$DIAG_MODEL_DIR" --served-model-name "$served_model" \
  --host 127.0.0.1 --port "$port" --tensor-parallel-size 1 \
  --dtype bfloat16 --max-model-len 32768 --max-num-seqs 32 \
  --gpu-memory-utilization 0.65 --enable-prefix-caching \
  --no-enable-chunked-prefill --disable-cascade-attn --enforce-eager \
  --generation-config vllm --enable-auto-tool-choice --tool-call-parser hermes \
  > "$out/server.log" 2>&1 &
server_pid=$!
cleanup() {
  if kill -0 "$server_pid" 2>/dev/null; then
    kill -TERM -- "-$server_pid" 2>/dev/null || true
    wait "$server_pid" 2>/dev/null || true
  fi
}
trap cleanup EXIT TERM INT
python - "$port" "$server_pid" <<'PY'
import json,os,sys,time
from urllib.request import urlopen
assert os.environ['VLLM_BATCH_INVARIANT']=='1'
port,pid=int(sys.argv[1]),int(sys.argv[2]); start=time.monotonic()
while True:
    try:
        with urlopen(f'http://127.0.0.1:{port}/v1/models',timeout=2) as r:json.load(r)
        break
    except OSError:
        try:os.kill(pid,0)
        except OSError:raise RuntimeError('vLLM exited during startup')
        if time.monotonic()-start>600:raise TimeoutError('vLLM startup exceeded 600 seconds')
        time.sleep(2)
PY
grep -F 'enable_prefix_caching=True' "$out/server.log"
grep -F 'enable_chunked_prefill=False' "$out/server.log"
if [[ "${TEAM_CHAIN:-0}" == 1 ]]; then
  printf '%s\n' 'conditions=team2,team4,bounded2' 'team2_parallel_games=4' \
    'team4_parallel_games=1' 'bounded2_parallel_games=1' 'reference_kind=bounded' \
    > "$out/CHAIN_PROFILE.txt"
  TEAM_SUITE=examples/final_evaluation/team_benac_2p_v1 TEAM_PARALLEL_GAMES=4 \
    bash examples/final_evaluation/run_team_benac.sh \
    "http://127.0.0.1:$port/v1" "$served_model" "$DIAG_CHECKPOINT_HASH" "$out/team2"
  TEAM_SUITE=examples/final_evaluation/team_benac_4p_v1 TEAM_PARALLEL_GAMES=1 \
    bash examples/final_evaluation/run_team_benac.sh \
    "http://127.0.0.1:$port/v1" "$served_model" "$DIAG_CHECKPOINT_HASH" "$out/team4"
  python -u -m examples.final_evaluation.run_team_oracle \
    --reference bounded --suite examples/final_evaluation/team_benac_2p_v1 \
    --base-url "http://127.0.0.1:$port/v1" --model "$served_model" \
    --checkpoint-hash "$DIAG_CHECKPOINT_HASH" --output "$out/bounded2" \
    --batch-invariant-confirmed
else
  bash examples/final_evaluation/run_team_benac.sh \
    "http://127.0.0.1:$port/v1" "$served_model" "$DIAG_CHECKPOINT_HASH" "$out/evaluation"
fi
printf '0\n' > "$out/EXIT_CODE"
