#!/usr/bin/env bash
#SBATCH --job-name=cb-qwen3-4b-think
#SBATCH --partition=gpu
#SBATCH --gres=gpu:h100-47:1
#SBATCH --time=02:00:00
#SBATCH --cpus-per-task=8
#SBATCH --mem=64G
#SBATCH --output=/home/e/e1300530/tmp/calbench-qwen3-4b-thinking-%j.out
#SBATCH --error=/home/e/e1300530/tmp/calbench-qwen3-4b-thinking-%j.err
set -euo pipefail

repo=/home/e/e1300530/tmp/MARSHAL-calbench-stream-20260920
model=/home/e/e1300530/models/Qwen3-4B
env_dir=/home/e/e1300530/tmp/marshal-vllm09
runner=/home/e/e1300530/tmp/MARSHAL-calbench-20260918/.venv-calbench/bin/python
[[ -f "$model/config.json" && -f "$model/model.safetensors.index.json" && -f "$model/tokenizer.json" ]]
[[ -x "$runner" ]]
cd "$repo"
source /home/e/e1300530/miniconda3/etc/profile.d/conda.sh
conda activate "$env_dir"
export PYTHONPATH="$repo:${PYTHONPATH:-}"
export TOKENIZERS_PARALLELISM=false OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=1
export VLLM_BATCH_INVARIANT=1
unset VLLM_USE_V1 VLLM_ATTENTION_BACKEND TRITON_PTXAS_PATH
nvcc_path="$(readlink -f "$(command -v nvcc)")"
export CUDA_HOME="$(dirname "$(dirname "$nvcc_path")")"
site_dir="$(python -c 'import sysconfig; print(sysconfig.get_paths()["purelib"])')"
export PATH="$CUDA_HOME/bin:$PATH"
export LD_LIBRARY_PATH="$CONDA_PREFIX/lib:$CONDA_PREFIX/targets/x86_64-linux/lib:$site_dir/nvidia/cuda_runtime/lib:$site_dir/nvidia/cudnn/lib:${LD_LIBRARY_PATH:-}"
export CUDNN_FRONTEND_CUDART_LIB_NAME=libcudart.so.13
: "${CUDA_VISIBLE_DEVICES:?Slurm must expose an assigned GPU}"
[[ "$CUDA_VISIBLE_DEVICES" != *,* ]]
"$runner" -c 'from examples.final_evaluation.calbench_local import verify_source; verify_source()'
python - <<'PY'
import os,torch
from transformers import AutoTokenizer
model='/home/e/e1300530/models/Qwen3-4B'
t=AutoTokenizer.from_pretrained(model,local_files_only=True)
m=[dict(role='user',content='Hello')]
default=t.apply_chat_template(m,tokenize=False,add_generation_prompt=True)
on=t.apply_chat_template(m,tokenize=False,add_generation_prompt=True,enable_thinking=True)
off=t.apply_chat_template(m,tokenize=False,add_generation_prompt=True,enable_thinking=False)
assert default==on and on!=off and '<think>\n\n</think>' in off
assert os.environ.get('VLLM_BATCH_INVARIANT')=='1'
assert torch.cuda.is_available() and torch.cuda.device_count()==1
print('THINKING_TEMPLATE_DEFAULT_EQUALS_ENABLED=1')
print('VLLM_BATCH_INVARIANT=1')
print('GPU=',torch.cuda.get_device_name(0),flush=True)
PY

port=$((20000 + SLURM_JOB_ID % 10000))
out="$repo/runs/calbench_soc/qwen3-4b-thinking-biinv-v1-stream-${SLURM_JOB_ID}"
python -u -m examples.final_evaluation.launch_calbench_local \
  --runtime soc --suite stream --model "$model" \
  --max-tokens 4096 --runner-python "$runner" \
  --ports "$port" --parallel-games 8 --max-num-seqs 32 \
  --disable-chunked-prefill --disable-cascade-attn \
  --output "$out"
