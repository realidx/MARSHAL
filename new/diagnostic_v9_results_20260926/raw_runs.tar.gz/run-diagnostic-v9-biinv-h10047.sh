#!/usr/bin/env bash
set -euo pipefail
export DIAG_SUITE=diagnostic_v9
export DIAG_EXPECTED_CASES=22
exec bash /home/e/e1300530/tmp/run-diagnostic-v8-biinv-h10047.sh
