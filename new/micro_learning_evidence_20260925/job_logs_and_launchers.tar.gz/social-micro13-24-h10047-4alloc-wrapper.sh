#!/usr/bin/env bash
set -euo pipefail
cd "${SLURM_SUBMIT_DIR:?Submit from the clean micro training checkout}"

[[ "$(git rev-parse HEAD)" == "${SOCIAL_SOURCE_COMMIT:?Pin the submitted commit}" ]]
[[ -z "$(git status --porcelain)" ]] || { echo 'Training checkout is dirty' >&2; exit 42; }

topology_log="runs/social_mixed/micro13-24-${SLURM_JOB_ID}-topology.log"
mkdir -p "$(dirname "$topology_log")"
{
  echo "SLURM_JOB_ID=$SLURM_JOB_ID"
  echo "SLURM_NODELIST=${SLURM_NODELIST:-}"
  echo "CUDA_VISIBLE_DEVICES(before)=${CUDA_VISIBLE_DEVICES:-}"
  nvidia-smi -L
} | tee "$topology_log"

# The four allocated 47-GiB slices must form two pairs from distinct parents.
mapfile -t parent_rows < <(
  nvidia-smi -L | awk '
    /^GPU [0-9]+:/ { parent=$0; next }
    /MIG .*UUID: MIG-/ {
      uuid=$0
      sub(/^.*UUID: /, "", uuid)
      sub(/\).*/, "", uuid)
      if (parent != "") print parent "\t" uuid
    }
  '
)
parent0=""; parent1=""
parent0_uuids=(); parent1_uuids=()
for row in "${parent_rows[@]}"; do
  parent="${row%%$'\t'*}"
  uuid="${row##*$'\t'}"
  if [[ -z "$parent0" || "$parent" == "$parent0" ]]; then
    parent0="$parent"; parent0_uuids+=("$uuid")
  elif [[ -z "$parent1" || "$parent" == "$parent1" ]]; then
    parent1="$parent"; parent1_uuids+=("$uuid")
  else
    echo "Unexpected third physical parent: $parent" >&2; exit 43
  fi
done
if [[ -z "$parent0" || -z "$parent1" || "$parent0" == "$parent1" ||
      ${#parent0_uuids[@]} -ne 2 || ${#parent1_uuids[@]} -ne 2 ]]; then
  echo 'FOUR_SLICE_CROSS_PARENT_SELECTION_FAILED' >&2
  printf 'PARENT_ROW=%s\n' "${parent_rows[@]}" >&2
  exit 43
fi
devices13="${parent0_uuids[0]},${parent1_uuids[0]}"
devices24="${parent0_uuids[1]},${parent1_uuids[1]}"
printf 'MICRO13_CUDA_VISIBLE_DEVICES=%s\nMICRO24_CUDA_VISIBLE_DEVICES=%s\n' "$devices13" "$devices24" | tee -a "$topology_log"

launch_variant() {
  local variant="$1" devices="$2" total_tokens="$3"
  local resume="$PWD/runs/social_mixed/decomposed-micro${variant}-seed42-878813/checkpoints/checkpoint-9"
  [[ -f "$resume/COMPLETE.json" ]] || { echo "Missing complete resume checkpoint: $resume" >&2; exit 44; }
  local ray_root="/tmp/social-${SLURM_JOB_ID}-micro${variant}"
  mkdir -p "$ray_root"
  setsid env -u SOCIAL_PAUSE_AFTER_UPDATES -u MASTER_PORT \
    SOCIAL_ARM=decomposed SOCIAL_GPU_PROFILE=h100-47 \
    SOCIAL_MICRO_BANK=1 SOCIAL_INTERACTION_BANK=0 SOCIAL_RECIPE=reasoning \
    SOCIAL_MICRO_VARIANT="$variant" SOCIAL_RUN_TAG="micro${variant}" \
    SOCIAL_NORMALIZATION=standard_sequence SOCIAL_KEEP_CHECKPOINTS=1 \
    SOCIAL_TOTAL_TOKENS="$total_tokens" SOCIAL_TOKENS_PER_UPDATE=65536 \
    SOCIAL_RESUME="$resume" \
    SOCIAL_SEED=42 SOCIAL_PROTOCOL_COEFFICIENT=0.2 \
    SOCIAL_RAY_ROOT="$ray_root" SLURM_CPUS_PER_TASK=24 \
    CUDA_VISIBLE_DEVICES="$devices" ROLL_ASSIGNED_CUDA_DEVICES="$devices" \
    bash examples/social_mixed/sbatch_train.sh &
  launched_pid=$!
}

launch_variant 13 "$devices13" 4259840
pid13=$launched_pid
launch_variant 24 "$devices24" 3932160
pid24=$launched_pid

forward_signal() {
  for pgid in "$pid13" "$pid24"; do
    kill -USR1 -- "-$pgid" 2>/dev/null || true
  done
}
trap forward_signal USR1 TERM

wait_for_child() {
  local pid="$1" result_name="$2" status
  while true; do
    set +e
    wait "$pid"
    status=$?
    set -e
    if (( status > 128 )) && kill -0 "$pid" 2>/dev/null; then
      continue
    fi
    printf -v "$result_name" '%s' "$status"
    return 0
  done
}
wait_for_child "$pid13" status13
wait_for_child "$pid24" status24
printf 'MICRO13_EXIT_CODE=%s\nMICRO24_EXIT_CODE=%s\n' "$status13" "$status24" | tee -a "$topology_log"
(( status13 == 0 && status24 == 0 ))
