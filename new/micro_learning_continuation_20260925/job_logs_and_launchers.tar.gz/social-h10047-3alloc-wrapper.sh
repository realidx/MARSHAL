#!/usr/bin/env bash
set -euo pipefail

cd "${SLURM_SUBMIT_DIR:?Submit from the social training checkout}"
export SOCIAL_GPU_PROFILE="${SOCIAL_GPU_PROFILE:-h100-47}"
export SOCIAL_ARM="${SOCIAL_ARM:-mixed}"

allocation_log="runs/social_mixed/${SOCIAL_ARM}-seed${SOCIAL_SEED:-42}-${SLURM_JOB_ID}/allocation_topology.log"
mkdir -p "$(dirname "$allocation_log")"
{
  echo "SLURM_JOB_ID=${SLURM_JOB_ID}"
  echo "SLURM_NODELIST=${SLURM_NODELIST:-}"
  echo "CUDA_VISIBLE_DEVICES(before)=${CUDA_VISIBLE_DEVICES:-}"
  nvidia-smi -L
} | tee "$allocation_log"

# A H100-47 node has two parent H100s with two MIG slices each.  Select one
# allocated MIG UUID from each parent, then run the existing two-GPU profile.
mapfile -t parent_rows < <(
  nvidia-smi -L | awk '
    /^GPU [0-9]+:/ { parent=$0; next }
    /MIG .*UUID: MIG-/ {
      uuid=$0
      sub(/^.*UUID: /, "", uuid)
      sub(/\).*/, "", uuid)
      if (parent != "" && !seen[parent]++) print parent "\t" uuid
    }
  '
)

if (( ${#parent_rows[@]} < 2 )); then
  echo "ALLOCATED_H10047_PARENT_SELECTION_FAILED: fewer than two parent GPUs visible" >&2
  exit 43
fi

selected=()
for row in "${parent_rows[0]}" "${parent_rows[1]}"; do
  selected+=("${row##*$'\t'}")
done
export CUDA_VISIBLE_DEVICES="${selected[0]},${selected[1]}"
{
  echo "SELECTED_CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES}"
  printf 'SELECTED_PARENT_ROW=%s\n' "${parent_rows[0]}" "${parent_rows[1]}"
} | tee -a "$allocation_log"

exec bash examples/social_mixed/sbatch_train.sh
