# Native800 D

800 entries; 6400 independent trajectories; 541 entries with complete terminal D.

Own terminal D and entry protocol/social diagnostics are separate. No final100 selection or training. Incomplete entries have D=null and explicit missing-outcome bounds. Later decisions have native validity records, not newly computed oracle scores.
