#!/usr/bin/env bash
set -euo pipefail
cd "${SLURM_SUBMIT_DIR:?Submit from the clean training checkout}"

[[ "$(git rev-parse HEAD)" == "${SOCIAL_SOURCE_COMMIT:?Pin the submitted commit}" ]]
[[ -z "$(git status --porcelain)" ]] || { echo 'Training checkout is dirty' >&2; exit 42; }

mkdir -p runs/social_mixed
topology_log="runs/social_mixed/partner-oc-${SLURM_JOB_ID}-topology.log"
{
  echo "SLURM_JOB_ID=$SLURM_JOB_ID"
  echo "SLURM_NODELIST=${SLURM_NODELIST:-}"
  echo "CUDA_VISIBLE_DEVICES(before)=${CUDA_VISIBLE_DEVICES:-}"
  nvidia-smi -L
} | tee "$topology_log"

mapfile -t parent_rows < <(
  nvidia-smi -L | awk '
    /^GPU [0-9]+:/ { parent=$0; next }
    /MIG .*UUID: MIG-/ {
      uuid=$0
      sub(/^.*UUID: /, "", uuid)
      sub(/\).*/, "", uuid)
      if (parent != "") print parent "\t" uuid
    }
  '
)
parent0=""; parent1=""
parent0_uuids=(); parent1_uuids=()
for row in "${parent_rows[@]}"; do
  parent="${row%%$'\t'*}"
  uuid="${row##*$'\t'}"
  if [[ -z "$parent0" || "$parent" == "$parent0" ]]; then
    parent0="$parent"; parent0_uuids+=("$uuid")
  elif [[ -z "$parent1" || "$parent" == "$parent1" ]]; then
    parent1="$parent"; parent1_uuids+=("$uuid")
  else
    echo "Unexpected third physical parent: $parent" >&2; exit 43
  fi
done
if [[ -z "$parent0" || -z "$parent1" || "$parent0" == "$parent1" ||
      ${#parent0_uuids[@]} -ne 2 || ${#parent1_uuids[@]} -ne 2 ]]; then
  echo 'FOUR_SLICE_CROSS_PARENT_SELECTION_FAILED' >&2
  printf 'PARENT_ROW=%s\n' "${parent_rows[@]}" >&2
  exit 43
fi
devices_o="${parent0_uuids[0]},${parent1_uuids[0]}"
devices_c="${parent0_uuids[1]},${parent1_uuids[1]}"
printf 'O_DEVICES=%s\nC_DEVICES=%s\n' "$devices_o" "$devices_c" | tee -a "$topology_log"

launch_variant() {
  local variant="$1" tag="$2" devices="$3" total_tokens="$4"
  local ray_root="/tmp/social-${SLURM_JOB_ID}-${tag}"
  mkdir -p "$ray_root"
  setsid env -u SOCIAL_PAUSE_AFTER_UPDATES -u SOCIAL_RESUME -u MASTER_PORT \
    SOCIAL_ARM=decomposed SOCIAL_GPU_PROFILE=h100-47 \
    SOCIAL_MICRO_BANK=1 SOCIAL_INTERACTION_BANK=0 SOCIAL_RECIPE=reasoning \
    SOCIAL_MICRO_VARIANT="$variant" SOCIAL_RUN_TAG="$tag" \
    SOCIAL_NORMALIZATION=standard_sequence SOCIAL_KEEP_CHECKPOINTS=1 \
    SOCIAL_TOTAL_TOKENS="$total_tokens" SOCIAL_TOKENS_PER_UPDATE=65536 \
    SOCIAL_SEED=42 SOCIAL_PROTOCOL_COEFFICIENT=0.2 \
    SOCIAL_RAY_ROOT="$ray_root" SLURM_CPUS_PER_TASK=24 \
    CUDA_VISIBLE_DEVICES="$devices" ROLL_ASSIGNED_CUDA_DEVICES="$devices" \
    bash examples/social_mixed/sbatch_train.sh &
  launched_pid=$!
}

launch_variant 24v1_partner_o partner_o "$devices_o" 1966080
pid_o=$launched_pid
launch_variant 24v1_partner_c partner_c "$devices_c" 3932160
pid_c=$launched_pid

forward_signal() {
  for pgid in "$pid_o" "$pid_c"; do
    kill -USR1 -- "-$pgid" 2>/dev/null || true
  done
}
trap forward_signal USR1 TERM

wait_for_child() {
  local pid="$1" result_name="$2" status
  while true; do
    set +e
    wait "$pid"
    status=$?
    set -e
    if (( status > 128 )) && kill -0 "$pid" 2>/dev/null; then
      continue
    fi
    printf -v "$result_name" '%s' "$status"
    return 0
  done
}
wait_for_child "$pid_o" status_o
wait_for_child "$pid_c" status_c
printf 'O_EXIT_CODE=%s\nC_EXIT_CODE=%s\n' "$status_o" "$status_c" | tee -a "$topology_log"
(( status_o == 0 && status_c == 0 ))
